let e;var t=Object.defineProperty,r=Object.getOwnPropertyDescriptor,i=Object.getOwnPropertyNames,a=Object.prototype.hasOwnProperty,n,s,o,u,l,d,p,c,h,f,m,g,y,_,b,$,v,w,x,k,S,T,I,E,C,z,A,O,R,B,N,D=(e=function(e){if("u">typeof require)return require.apply(this,arguments);throw Error('Dynamic require of "'+e+'" is not supported')},"u">typeof require?require:"u">typeof Proxy?new Proxy(e,{get:(e,t)=>("u">typeof require?require:e)[t]}):e),M=(e,t)=>()=>(e&&(t=e(e=0)),t),P=(e,r)=>{for(var i in r)t(e,i,{get:r[i],enumerable:!0})},U=e=>((e,n,s)=>{if(n&&"object"==typeof n||"function"==typeof n)for(let o of i(n))a.call(e,o)||void 0===o||t(e,o,{get:()=>n[o],enumerable:!(s=r(n,o))||s.enumerable});return e})(t({},"__esModule",{value:!0}),e),q=M(()=>{"use strict";n=new Map,s=[],o=(e,t,r)=>{if(t&&"function"==typeof t.init&&"function"==typeof t.createInferenceSessionHandler){let i=n.get(e);if(void 0===i)n.set(e,{backend:t,priority:r});else{if(i.priority>r)return;if(i.priority===r&&i.backend!==t)throw Error(`cannot register backend "${e}" using priority ${r}`)}if(r>=0){let t=s.indexOf(e);-1!==t&&s.splice(t,1);for(let t=0;t<s.length;t++)if(n.get(s[t]).priority<=r)return void s.splice(t,0,e);s.push(e)}return}throw TypeError("not a valid backend")},u=async e=>{let t=n.get(e);if(!t)return"backend not found.";if(t.initialized)return t.backend;if(t.aborted)return t.error;{let r=!!t.initPromise;try{return r||(t.initPromise=t.backend.init(e)),await t.initPromise,t.initialized=!0,t.backend}catch(e){return r||(t.error=`${e}`,t.aborted=!0),t.error}finally{delete t.initPromise}}},l=async e=>{let t=e.executionProviders||[],r=t.map(e=>"string"==typeof e?e:e.name),i=0===r.length?s:r,a,n=[],o=new Set;for(let e of i){let t=await u(e);"string"==typeof t?n.push({name:e,err:t}):(a||(a=t),a===t&&o.add(e))}if(!a)throw Error(`no available backend found. ERR: ${n.map(e=>`[${e.name}] ${e.err}`).join(", ")}`);for(let{name:e,err:t}of n)r.includes(e)&&console.warn(`removing requested execution provider "${e}" from session options because it is not available: ${t}`);let l=t.filter(e=>o.has("string"==typeof e?e:e.name));return[a,new Proxy(e,{get:(e,t)=>"executionProviders"===t?l:Reflect.get(e,t)})]}}),W=M(()=>{"use strict";q()}),L=M(()=>{"use strict";d="1.22.0"}),V=M(()=>{"use strict";L(),p="warning",Object.defineProperty(c={wasm:{},webgl:{},webgpu:{},versions:{common:d},set logLevel(e){if(void 0!==e){if("string"!=typeof e||-1===["verbose","info","warning","error","fatal"].indexOf(e))throw Error(`Unsupported logging level: ${e}`);p=e}},get logLevel(){return p}},"logLevel",{enumerable:!0})}),G=M(()=>{"use strict";V(),h=c}),H=M(()=>{"use strict";f=(e,t)=>{let r="u">typeof document?document.createElement("canvas"):new OffscreenCanvas(1,1);r.width=e.dims[3],r.height=e.dims[2];let i=r.getContext("2d");if(null!=i){let a,n;t?.tensorLayout!==void 0&&"NHWC"===t.tensorLayout?(a=e.dims[2],n=e.dims[3]):(a=e.dims[3],n=e.dims[2]);let s=t?.format!==void 0?t.format:"RGB",o=t?.norm,u,l;void 0===o||void 0===o.mean?u=[255,255,255,255]:"number"==typeof o.mean?u=[o.mean,o.mean,o.mean,o.mean]:(u=[o.mean[0],o.mean[1],o.mean[2],0],void 0!==o.mean[3]&&(u[3]=o.mean[3])),void 0===o||void 0===o.bias?l=[0,0,0,0]:"number"==typeof o.bias?l=[o.bias,o.bias,o.bias,o.bias]:(l=[o.bias[0],o.bias[1],o.bias[2],0],void 0!==o.bias[3]&&(l[3]=o.bias[3]));let d=n*a,p=0,c=d,h=2*d,f=-1;"RGBA"===s?(p=0,c=d,h=2*d,f=3*d):"RGB"===s?(p=0,c=d,h=2*d):"RBG"===s&&(p=0,h=d,c=2*d);for(let t=0;t<n;t++)for(let r=0;r<a;r++)i.fillStyle="rgba("+(e.data[p++]-l[0])*u[0]+","+(e.data[c++]-l[1])*u[1]+","+(e.data[h++]-l[2])*u[2]+","+(-1===f?255:(e.data[f++]-l[3])*u[3])+")",i.fillRect(r,t,1,1);if("toDataURL"in r)return r.toDataURL();throw Error("toDataURL is not supported")}throw Error("Can not access image data")},m=(e,t)=>{let r="u">typeof document?document.createElement("canvas").getContext("2d"):new OffscreenCanvas(1,1).getContext("2d"),i;if(null!=r){let a,n,s;t?.tensorLayout!==void 0&&"NHWC"===t.tensorLayout?(a=e.dims[2],n=e.dims[1],s=e.dims[3]):(a=e.dims[3],n=e.dims[2],s=e.dims[1]);let o=void 0!==t&&void 0!==t.format?t.format:"RGB",u=t?.norm,l,d;void 0===u||void 0===u.mean?l=[255,255,255,255]:"number"==typeof u.mean?l=[u.mean,u.mean,u.mean,u.mean]:(l=[u.mean[0],u.mean[1],u.mean[2],255],void 0!==u.mean[3]&&(l[3]=u.mean[3])),void 0===u||void 0===u.bias?d=[0,0,0,0]:"number"==typeof u.bias?d=[u.bias,u.bias,u.bias,u.bias]:(d=[u.bias[0],u.bias[1],u.bias[2],0],void 0!==u.bias[3]&&(d[3]=u.bias[3]));let p=n*a;if(void 0!==t&&(void 0!==t.format&&4===s&&"RGBA"!==t.format||3===s&&"RGB"!==t.format&&"BGR"!==t.format))throw Error("Tensor format doesn't match input tensor dims");let c=0,h=1,f=2,m=3,g=0,y=p,_=2*p,b=-1;"RGBA"===o?(g=0,y=p,_=2*p,b=3*p):"RGB"===o?(g=0,y=p,_=2*p):"RBG"===o&&(g=0,_=p,y=2*p),i=r.createImageData(a,n);for(let t=0;t<n*a;c+=4,h+=4,f+=4,m+=4,t++)i.data[c]=(e.data[g++]-d[0])*l[0],i.data[h]=(e.data[y++]-d[1])*l[1],i.data[f]=(e.data[_++]-d[2])*l[2],i.data[m]=-1===b?255:(e.data[b++]-d[3])*l[3]}else throw Error("Can not access image data");return i}}),F=M(()=>{"use strict";Z(),g=(e,t)=>{if(void 0===e)throw Error("Image buffer must be defined");if(void 0===t.height||void 0===t.width)throw Error("Image height and width must be defined");if("NHWC"===t.tensorLayout)throw Error("NHWC Tensor layout is not supported yet");let{height:r,width:i}=t,a=t.norm??{mean:255,bias:0},n,s;n="number"==typeof a.mean?[a.mean,a.mean,a.mean,a.mean]:[a.mean[0],a.mean[1],a.mean[2],a.mean[3]??255],s="number"==typeof a.bias?[a.bias,a.bias,a.bias,a.bias]:[a.bias[0],a.bias[1],a.bias[2],a.bias[3]??0];let o=void 0!==t.format?t.format:"RGBA",u=void 0!==t.tensorFormat&&void 0!==t.tensorFormat?t.tensorFormat:"RGB",l=r*i,d=new Float32Array("RGBA"===u?4*l:3*l),p=4,c=0,h=1,f=2,m=3,g=0,y=l,_=2*l,b=-1;"RGB"===o&&(p=3,c=0,h=1,f=2,m=-1),"RGBA"===u?b=3*l:"RBG"===u?(g=0,_=l,y=2*l):"BGR"===u&&(_=0,y=l,g=2*l);for(let t=0;t<l;t++,c+=p,f+=p,h+=p,m+=p)d[g++]=(e[c]+s[0])/n[0],d[y++]=(e[h]+s[1])/n[1],d[_++]=(e[f]+s[2])/n[2],-1!==b&&-1!==m&&(d[b++]=(e[m]+s[3])/n[3]);return"RGBA"===u?new E("float32",d,[1,4,r,i]):new E("float32",d,[1,3,r,i])},y=async(e,t)=>{let r="u">typeof HTMLImageElement&&e instanceof HTMLImageElement,i="u">typeof ImageData&&e instanceof ImageData,a="u">typeof ImageBitmap&&e instanceof ImageBitmap,n="string"==typeof e,s,o=t??{},u=()=>{if("u">typeof document)return document.createElement("canvas");if("u">typeof OffscreenCanvas)return new OffscreenCanvas(1,1);throw Error("Canvas is not supported")},l=e=>"u">typeof HTMLCanvasElement&&e instanceof HTMLCanvasElement||e instanceof OffscreenCanvas?e.getContext("2d"):null;if(r){let r=u();r.width=e.width,r.height=e.height;let i=l(r);if(null!=i){let r=e.height,a=e.width;if(void 0!==t&&void 0!==t.resizedHeight&&void 0!==t.resizedWidth&&(r=t.resizedHeight,a=t.resizedWidth),void 0!==t){if(o=t,void 0!==t.tensorFormat)throw Error("Image input config format must be RGBA for HTMLImageElement");o.tensorFormat="RGBA",o.height=r,o.width=a}else o.tensorFormat="RGBA",o.height=r,o.width=a;i.drawImage(e,0,0),s=i.getImageData(0,0,a,r).data}else throw Error("Can not access image data")}else if(i){let r,i;if(void 0!==t&&void 0!==t.resizedWidth&&void 0!==t.resizedHeight?(r=t.resizedHeight,i=t.resizedWidth):(r=e.height,i=e.width),void 0!==t&&(o=t),o.format="RGBA",o.height=r,o.width=i,void 0!==t){let t=u();t.width=i,t.height=r;let a=l(t);if(null!=a)a.putImageData(e,0,0),s=a.getImageData(0,0,i,r).data;else throw Error("Can not access image data")}else s=e.data}else if(a){if(void 0===t)throw Error("Please provide image config with format for Imagebitmap");let r=u();r.width=e.width,r.height=e.height;let i=l(r);if(null!=i){let t=e.height,r=e.width;return i.drawImage(e,0,0,r,t),s=i.getImageData(0,0,r,t).data,o.height=t,o.width=r,g(s,o)}throw Error("Can not access image data")}else{if(n)return new Promise((t,r)=>{let i=u(),a=l(i);if(!e||!a)return r();let n=new Image;n.crossOrigin="Anonymous",n.src=e,n.onload=()=>{i.width=n.width,i.height=n.height,a.drawImage(n,0,0,i.width,i.height);let e=a.getImageData(0,0,i.width,i.height);o.height=i.height,o.width=i.width,t(g(e.data,o))}});throw Error("Input data provided is not supported - aborted tensor creation")}if(void 0!==s)return g(s,o);throw Error("Input data provided is not supported - aborted tensor creation")},_=(e,t)=>{let{width:r,height:i,download:a,dispose:n}=t;return new E({location:"texture",type:"float32",texture:e,dims:[1,i,r,4],download:a,dispose:n})},b=(e,t)=>{let{dataType:r,dims:i,download:a,dispose:n}=t;return new E({location:"gpu-buffer",type:r??"float32",gpuBuffer:e,dims:i,download:a,dispose:n})},$=(e,t)=>{let{dataType:r,dims:i,download:a,dispose:n}=t;return new E({location:"ml-tensor",type:r??"float32",mlTensor:e,dims:i,download:a,dispose:n})},v=(e,t,r)=>new E({location:"cpu-pinned",type:e,data:t,dims:r??[t.length]})}),j=M(()=>{"use strict";w=new Map([["float32",Float32Array],["uint8",Uint8Array],["int8",Int8Array],["uint16",Uint16Array],["int16",Int16Array],["int32",Int32Array],["bool",Uint8Array],["float64",Float64Array],["uint32",Uint32Array],["int4",Uint8Array],["uint4",Uint8Array]]),x=new Map([[Float32Array,"float32"],[Uint8Array,"uint8"],[Int8Array,"int8"],[Uint16Array,"uint16"],[Int16Array,"int16"],[Int32Array,"int32"],[Float64Array,"float64"],[Uint32Array,"uint32"]]),k=!1,S=()=>{if(!k){k=!0;let e="u">typeof BigInt64Array&&BigInt64Array.from,t="u">typeof BigUint64Array&&BigUint64Array.from,r=globalThis.Float16Array,i="u">typeof r&&r.from;e&&(w.set("int64",BigInt64Array),x.set(BigInt64Array,"int64")),t&&(w.set("uint64",BigUint64Array),x.set(BigUint64Array,"uint64")),i?(w.set("float16",r),x.set(r,"float16")):w.set("float16",Uint16Array)}}}),K=M(()=>{"use strict";Z(),T=e=>{let t=1;for(let r=0;r<e.length;r++){let i=e[r];if("number"!=typeof i||!Number.isSafeInteger(i))throw TypeError(`dims[${r}] must be an integer, got: ${i}`);if(i<0)throw RangeError(`dims[${r}] must be a non-negative integer, got: ${i}`);t*=i}return t},I=(e,t)=>{switch(e.location){case"cpu":return new E(e.type,e.data,t);case"cpu-pinned":return new E({location:"cpu-pinned",data:e.data,type:e.type,dims:t});case"texture":return new E({location:"texture",texture:e.texture,type:e.type,dims:t});case"gpu-buffer":return new E({location:"gpu-buffer",gpuBuffer:e.gpuBuffer,type:e.type,dims:t});case"ml-tensor":return new E({location:"ml-tensor",mlTensor:e.mlTensor,type:e.type,dims:t});default:throw Error(`tensorReshape: tensor location ${e.location} is not supported`)}}}),Z=M(()=>{"use strict";H(),F(),j(),K(),E=class{constructor(e,t,r){let i,a;if(S(),"object"==typeof e&&"location"in e)switch(this.dataLocation=e.location,i=e.type,a=e.dims,e.location){case"cpu-pinned":{let t=w.get(i);if(!t)throw TypeError(`unsupported type "${i}" to create tensor from pinned buffer`);if(!(e.data instanceof t))throw TypeError(`buffer should be of type ${t.name}`);this.cpuData=e.data;break}case"texture":if("float32"!==i)throw TypeError(`unsupported type "${i}" to create tensor from texture`);this.gpuTextureData=e.texture,this.downloader=e.download,this.disposer=e.dispose;break;case"gpu-buffer":if("float32"!==i&&"float16"!==i&&"int32"!==i&&"int64"!==i&&"uint32"!==i&&"uint8"!==i&&"bool"!==i&&"uint4"!==i&&"int4"!==i)throw TypeError(`unsupported type "${i}" to create tensor from gpu buffer`);this.gpuBufferData=e.gpuBuffer,this.downloader=e.download,this.disposer=e.dispose;break;case"ml-tensor":if("float32"!==i&&"float16"!==i&&"int32"!==i&&"int64"!==i&&"uint32"!==i&&"uint64"!==i&&"int8"!==i&&"uint8"!==i&&"bool"!==i&&"uint4"!==i&&"int4"!==i)throw TypeError(`unsupported type "${i}" to create tensor from MLTensor`);this.mlTensorData=e.mlTensor,this.downloader=e.download,this.disposer=e.dispose;break;default:throw Error(`Tensor constructor: unsupported location '${this.dataLocation}'`)}else{let n,s;if("string"==typeof e)if(i=e,s=r,"string"===e){if(!Array.isArray(t))throw TypeError("A string tensor's data must be a string array.");n=t}else{let r=w.get(e);if(void 0===r)throw TypeError(`Unsupported tensor type: ${e}.`);if(Array.isArray(t)){if("float16"===e&&r===Uint16Array||"uint4"===e||"int4"===e)throw TypeError(`Creating a ${e} tensor from number array is not supported. Please use ${r.name} as data.`);n="uint64"===e||"int64"===e?r.from(t,BigInt):r.from(t)}else if(t instanceof r)n=t;else if(t instanceof Uint8ClampedArray)if("uint8"===e)n=Uint8Array.from(t);else throw TypeError("A Uint8ClampedArray tensor's data must be type of uint8");else if("float16"===e&&t instanceof Uint16Array&&r!==Uint16Array)n=new globalThis.Float16Array(t.buffer,t.byteOffset,t.length);else throw TypeError(`A ${i} tensor's data must be type of ${r}`)}else if(s=t,Array.isArray(e)){if(0===e.length)throw TypeError("Tensor type cannot be inferred from an empty array.");let t=typeof e[0];if("string"===t)i="string",n=e;else if("boolean"===t)i="bool",n=Uint8Array.from(e);else throw TypeError(`Invalid element type of data array: ${t}.`)}else if(e instanceof Uint8ClampedArray)i="uint8",n=Uint8Array.from(e);else{let t=x.get(e.constructor);if(void 0===t)throw TypeError(`Unsupported type for tensor data: ${e.constructor}.`);i=t,n=e}if(void 0===s)s=[n.length];else if(!Array.isArray(s))throw TypeError("A tensor's dims must be a number array");a=s,this.cpuData=n,this.dataLocation="cpu"}let n=T(a);if(this.cpuData&&n!==this.cpuData.length&&("uint4"!==i&&"int4"!==i||Math.ceil(n/2)!==this.cpuData.length))throw Error(`Tensor's size(${n}) does not match data length(${this.cpuData.length}).`);this.type=i,this.dims=a,this.size=n}static async fromImage(e,t){return y(e,t)}static fromTexture(e,t){return _(e,t)}static fromGpuBuffer(e,t){return b(e,t)}static fromMLTensor(e,t){return $(e,t)}static fromPinnedBuffer(e,t,r){return v(e,t,r)}toDataURL(e){return f(this,e)}toImageData(e){return m(this,e)}get data(){if(this.ensureValid(),!this.cpuData)throw Error("The data is not on CPU. Use `getData()` to download GPU data to CPU, or use `texture` or `gpuBuffer` property to access the GPU data directly.");return this.cpuData}get location(){return this.dataLocation}get texture(){if(this.ensureValid(),!this.gpuTextureData)throw Error("The data is not stored as a WebGL texture.");return this.gpuTextureData}get gpuBuffer(){if(this.ensureValid(),!this.gpuBufferData)throw Error("The data is not stored as a WebGPU buffer.");return this.gpuBufferData}get mlTensor(){if(this.ensureValid(),!this.mlTensorData)throw Error("The data is not stored as a WebNN MLTensor.");return this.mlTensorData}async getData(e){switch(this.ensureValid(),this.dataLocation){case"cpu":case"cpu-pinned":return this.data;case"texture":case"gpu-buffer":case"ml-tensor":if(!this.downloader)throw Error("The current tensor is not created with a specified data downloader.");if(this.isDownloading)throw Error("The current tensor is being downloaded.");try{this.isDownloading=!0;let t=await this.downloader();return this.downloader=void 0,this.dataLocation="cpu",this.cpuData=t,e&&this.disposer&&(this.disposer(),this.disposer=void 0),t}finally{this.isDownloading=!1}default:throw Error(`cannot get data from location: ${this.dataLocation}`)}}dispose(){if(this.isDownloading)throw Error("The current tensor is being downloaded.");this.disposer&&(this.disposer(),this.disposer=void 0),this.cpuData=void 0,this.gpuTextureData=void 0,this.gpuBufferData=void 0,this.mlTensorData=void 0,this.downloader=void 0,this.isDownloading=void 0,this.dataLocation="none"}ensureValid(){if("none"===this.dataLocation)throw Error("The tensor is disposed.")}reshape(e){if(this.ensureValid(),this.downloader||this.disposer)throw Error("Cannot reshape a tensor that owns GPU resource.");return I(this,e)}}}),Q=M(()=>{"use strict";Z(),C=E}),X=M(()=>{"use strict";V(),z=(e,t)=>{(typeof c.trace>"u"?c.wasm.trace:c.trace)&&console.timeStamp(`${e}::ORT::${t}`)},A=(e,t)=>{let r=Error().stack?.split(/\r\n|\r|\n/g)||[],i=!1;for(let a=0;a<r.length;a++){if(i&&!r[a].includes("TRACE_FUNC")){let i=`FUNC_${e}::${r[a].trim().split(" ")[1]}`;t&&(i+=`::${t}`),z("CPU",i);return}r[a].includes("TRACE_FUNC")&&(i=!0)}},O=e=>{(typeof c.trace>"u"?c.wasm.trace:c.trace)&&A("BEGIN",e)},R=e=>{(typeof c.trace>"u"?c.wasm.trace:c.trace)&&A("END",e)}}),Y=M(()=>{"use strict";q(),Q(),X(),B=class e{constructor(e){this.handler=e}async run(e,t,r){O();let i={},a={};if("object"!=typeof e||null===e||e instanceof C||Array.isArray(e))throw TypeError("'feeds' must be an object that use input names as keys and OnnxValue as corresponding values.");let n=!0;if("object"==typeof t){if(null===t)throw TypeError("Unexpected argument[1]: cannot be null.");if(t instanceof C)throw TypeError("'fetches' cannot be a Tensor");if(Array.isArray(t)){if(0===t.length)throw TypeError("'fetches' cannot be an empty array.");for(let e of(n=!1,t)){if("string"!=typeof e)throw TypeError("'fetches' must be a string array or an object.");if(-1===this.outputNames.indexOf(e))throw RangeError(`'fetches' contains invalid output name: ${e}.`);i[e]=null}if("object"==typeof r&&null!==r)a=r;else if("u">typeof r)throw TypeError("'options' must be an object.")}else{let e=!1,s=Object.getOwnPropertyNames(t);for(let r of this.outputNames)if(-1!==s.indexOf(r)){let a=t[r];(null===a||a instanceof C)&&(e=!0,n=!1,i[r]=a)}if(e){if("object"==typeof r&&null!==r)a=r;else if("u">typeof r)throw TypeError("'options' must be an object.")}else a=t}}else if("u">typeof t)throw TypeError("Unexpected argument[1]: must be 'fetches' or 'options'.");for(let t of this.inputNames)if(typeof e[t]>"u")throw Error(`input '${t}' is missing in 'feeds'.`);if(n)for(let e of this.outputNames)i[e]=null;let s=await this.handler.run(e,i,a),o={};for(let e in s)if(Object.hasOwnProperty.call(s,e)){let t=s[e];t instanceof C?o[e]=t:o[e]=new C(t.type,t.data,t.dims)}return R(),o}async release(){return this.handler.dispose()}static async create(t,r,i,a){O();let n,s={};if("string"==typeof t){if(n=t,"object"==typeof r&&null!==r)s=r;else if("u">typeof r)throw TypeError("'options' must be an object.")}else if(t instanceof Uint8Array){if(n=t,"object"==typeof r&&null!==r)s=r;else if("u">typeof r)throw TypeError("'options' must be an object.")}else if(t instanceof ArrayBuffer||"u">typeof SharedArrayBuffer&&t instanceof SharedArrayBuffer){let e=0,o=t.byteLength;if("object"==typeof r&&null!==r)s=r;else if("number"==typeof r){if(!Number.isSafeInteger(e=r))throw RangeError("'byteOffset' must be an integer.");if(e<0||e>=t.byteLength)throw RangeError(`'byteOffset' is out of range [0, ${t.byteLength}).`);if(o=t.byteLength-e,"number"==typeof i){if(!Number.isSafeInteger(o=i))throw RangeError("'byteLength' must be an integer.");if(o<=0||e+o>t.byteLength)throw RangeError(`'byteLength' is out of range (0, ${t.byteLength-e}].`);if("object"==typeof a&&null!==a)s=a;else if("u">typeof a)throw TypeError("'options' must be an object.")}else if("u">typeof i)throw TypeError("'byteLength' must be a number.")}else if("u">typeof r)throw TypeError("'options' must be an object.");n=new Uint8Array(t,e,o)}else throw TypeError("Unexpected argument[0]: must be 'path' or 'buffer'.");let[o,u]=await l(s),d=await o.createInferenceSessionHandler(n,u);return R(),new e(d)}startProfiling(){this.handler.startProfiling()}endProfiling(){this.handler.endProfiling()}get inputNames(){return this.handler.inputNames}get outputNames(){return this.handler.outputNames}get inputMetadata(){return this.handler.inputMetadata}get outputMetadata(){return this.handler.outputMetadata}}}),J=M(()=>{"use strict";Y(),N=B}),ee=M(()=>{}),et=M(()=>{}),er=M(()=>{}),ei=M(()=>{}),ea={};P(ea,{InferenceSession:()=>N,TRACE:()=>z,TRACE_FUNC_BEGIN:()=>O,TRACE_FUNC_END:()=>R,Tensor:()=>C,env:()=>h,registerBackend:()=>o});var en=M(()=>{"use strict";W(),G(),J(),Q(),ee(),et(),X(),er(),ei()}),es=M(()=>{}),eo={};P(eo,{default:()=>el});var eu,el,ed=M(()=>{"use strict";s1(),nd(),nl(),(eu=globalThis.self?.name==="ort-wasm-proxy-worker")&&(self.onmessage=e=>{let{type:t,in:r}=e.data;try{switch(t){case"init-wasm":ez(r.wasm).then(()=>{sx(r).then(()=>{postMessage({type:t})},e=>{postMessage({type:t,err:e})})},e=>{postMessage({type:t,err:e})});break;case"init-ep":{let{epName:e,env:i}=r;sk(i,e).then(()=>{postMessage({type:t})},e=>{postMessage({type:t,err:e})});break}case"copy-from":{let{buffer:e}=r,i=sI(e);postMessage({type:t,out:i});break}case"create":{let{model:e,options:i}=r;sE(e,i).then(e=>{postMessage({type:t,out:e})},e=>{postMessage({type:t,err:e})});break}case"release":sC(r),postMessage({type:t});break;case"run":{let{sessionId:e,inputIndices:i,inputs:a,outputIndices:n,options:s}=r;sA(e,i,a,n,Array(n.length).fill(null),s).then(e=>{e.some(e=>"cpu"!==e[3])?postMessage({type:t,err:"Proxy does not support non-cpu tensor location."}):postMessage({type:t,out:e},sR([...a,...e]))},e=>{postMessage({type:t,err:e})});break}case"end-profiling":sO(r),postMessage({type:t})}}catch(e){postMessage({type:t,err:e})}}),el=eu?null:e=>new Worker(e??ey,{type:"module",name:"ort-wasm-proxy-worker"})}),ep={};P(ep,{default:()=>ef});var ec,eh,ef,em,eg,ey,e_,eb,e$,ev,ew,ex,ek,eS,eT,eI,eE,eC,ez,eA,eO,eR,eB,eN,eD,eM,eP,eU,eq,eW,eL,eV,eG,eH,eF,ej,eK,eZ,eQ,eX,eY,eJ,e0,e2,e1,e3,e4,e6,e8,e5,e7,e9,te,tt,tr,ti,ta,tn,ts,to,tu,tl,td,tp,tc,th,tf,tm,tg,ty,t_,tb,t$,tv,tw,tx,tk,tS,tT,tI,tE,tC,tz,tA,tO,tR,tB,tN,tD,tM,tP,tU,tq,tW,tL,tV,tG,tH,tF,tj,tK,tZ,tQ,tX,tY,tJ,t0,t2,t1,t3,t4,t6,t8,t5,t7,t9,re,rt,rr,ri,ra,rn,rs,ro,ru,rl,rd,rp,rc,rh,rf,rm,rg,ry,r_,rb,r$,rv,rw,rx,rk,rS,rT,rI,rE,rC,rz,rA,rO,rR,rB,rN,rD,rM,rP,rU,rq,rW,rL,rV,rG,rH,rF,rj,rK,rZ,rQ,rX,rY,rJ,r0,r2,r1,r3,r4,r6,r8,r5,r7,r9,ie,it,ir,ii,ia,is,io,iu,il,id,ip,ic,ih,im,ig,iy,i_,ib,i$,iv,iw,ix,ik,iS,iT,iI,iE,iC,iz,iA,iO,iR,iB,iN,iD,iM,iP,iU,iq,iW,iL,iV,iG,iH,iF,ij,iK,iZ,iQ,iX,iY,iJ,i0,i2,i1,i3,i4,i6,i8,i5,i7,i9,ae,at,ar,ai,aa,an,as,ao,au,al,ad,ap,ac,ah,af,am,ag,ay,a_,ab,a$,av,aw,ax,ak,aS,aT,aI,aE,aC,az,aA,aO,aR,aB,aN,aD,aM,aP,aU,aq,aW,aL,aV,aG,aH,aF,aj,aK,aZ,aQ,aX,aY,aJ,a0,a2,a1,a3,a4,a6,a8,a5,a7,a9,ne,nt,nr,ni,na,nn,ns,no,nu=M(()=>{"use strict";ec=import.meta.url,ef=eh=async function(e={}){var t,r,i=new Promise((e,i)=>{t=e,r=i}),a="object"==typeof window,n="u">typeof WorkerGlobalScope,s=n&&self.name?.startsWith("em-pthread");e.mountExternalData=(t,r)=>{t.startsWith("./")&&(t=t.substring(2)),(e.Fb||(e.Fb=new Map)).set(t,r)},e.unmountExternalData=()=>{delete e.Fb};var o=globalThis.SharedArrayBuffer??new WebAssembly.Memory({initial:0,maximum:0,qc:!0}).buffer.constructor;let u=t=>async(...r)=>{try{if(e.Gb)throw Error("Session already started");let i=e.Gb={ec:r[0],errors:[]},a=await t(...r);if(e.Gb!==i)throw Error("Session mismatch");e.Kb?.flush();let n=i.errors;if(0<n.length){let e=await Promise.all(n);if(e=e.filter(e=>e),0<e.length)throw Error(e.join(`
`))}return a}finally{e.Gb=null}};e.jsepInit=(t,r)=>{if("webgpu"===t){[e.Kb,e.Vb,e.Zb,e.Lb,e.Yb,e.kb,e.$b,e.bc,e.Wb,e.Xb,e.ac]=r;let t=e.Kb;e.jsepRegisterBuffer=(e,r,i,a)=>t.registerBuffer(e,r,i,a),e.jsepGetBuffer=e=>t.getBuffer(e),e.jsepCreateDownloader=(e,r,i)=>t.createDownloader(e,r,i),e.jsepOnCreateSession=e=>{t.onCreateSession(e)},e.jsepOnReleaseSession=e=>{t.onReleaseSession(e)},e.jsepOnRunStart=e=>t.onRunStart(e),e.cc=(e,r)=>{t.upload(e,r)}}else if("webnn"===t){let t=r[0];[e.oc,e.Ob,e.webnnEnsureTensor,e.Pb,e.webnnDownloadTensor]=r.slice(1),e.webnnReleaseTensorId=e.Ob,e.webnnUploadTensor=e.Pb,e.webnnOnRunStart=e=>t.onRunStart(e),e.webnnOnRunEnd=t.onRunEnd.bind(t),e.webnnRegisterMLContext=(e,r)=>{t.registerMLContext(e,r)},e.webnnOnReleaseSession=e=>{t.onReleaseSession(e)},e.webnnCreateMLTensorDownloader=(e,r)=>t.createMLTensorDownloader(e,r),e.webnnRegisterMLTensor=(e,r,i,a)=>t.registerMLTensor(e,r,i,a),e.webnnCreateMLContext=e=>t.createMLContext(e),e.webnnRegisterMLConstant=(r,i,a,n,s,o)=>t.registerMLConstant(r,i,a,n,s,e.Fb,o),e.webnnRegisterGraphInput=t.registerGraphInput.bind(t),e.webnnIsGraphInput=t.isGraphInput.bind(t),e.webnnRegisterGraphOutput=t.registerGraphOutput.bind(t),e.webnnIsGraphOutput=t.isGraphOutput.bind(t),e.webnnCreateTemporaryTensor=t.createTemporaryTensor.bind(t),e.webnnIsGraphInputOutputTypeSupported=t.isGraphInputOutputTypeSupported.bind(t)}};let l=()=>{let t=(e,t,r)=>(...i)=>{let a=tC,n=t?.();i=e(...i);let s=t?.();return n!==s&&(e=s,r(n),t=r=null),tC!=a?new Promise((e,t)=>{tN={resolve:e,reject:t}}):i};(()=>{for(let r of["_OrtAppendExecutionProvider","_OrtCreateSession","_OrtRun","_OrtRunWithBinding","_OrtBindInput"])e[r]=t(e[r],()=>e[r],t=>e[r]=t)})(),void 0!==u&&(e._OrtRun=u(e._OrtRun),e._OrtRunWithBinding=u(e._OrtRunWithBinding)),l=void 0};e.asyncInit=()=>{l?.()};var d,p,c=Object.assign({},e),h=(e,t)=>{throw t},f="";(a||n)&&(n?f=self.location.href:"u">typeof document&&document.currentScript&&(f=document.currentScript.src),ec&&(f=ec),f=f.startsWith("blob:")?"":f.slice(0,f.replace(/[?#].*/,"").lastIndexOf("/")+1),n&&(p=e=>{var t=new XMLHttpRequest;return t.open("GET",e,!1),t.responseType="arraybuffer",t.send(null),new Uint8Array(t.response)}),d=async e=>{if(B(e))return new Promise((t,r)=>{var i=new XMLHttpRequest;i.open("GET",e,!0),i.responseType="arraybuffer",i.onload=()=>{200==i.status||0==i.status&&i.response?t(i.response):r(i.status)},i.onerror=r,i.send(null)});var t=await fetch(e,{credentials:"same-origin"});if(t.ok)return t.arrayBuffer();throw Error(t.status+" : "+t.url)});var m=console.log.bind(console),g=console.error.bind(console),y=m,_=g;Object.assign(e,c),c=null;var b,$,v,w,x,k,S,T,I,E,C,z,A,O=e.wasmBinary,R=!1,B=e=>e.startsWith("file://");function N(){return b.buffer!=w.buffer&&H(),w}function D(){return b.buffer!=w.buffer&&H(),x}function M(){return b.buffer!=w.buffer&&H(),k}function P(){return b.buffer!=w.buffer&&H(),S}function U(){return b.buffer!=w.buffer&&H(),T}function q(){return b.buffer!=w.buffer&&H(),I}function W(){return b.buffer!=w.buffer&&H(),E}function L(){return b.buffer!=w.buffer&&H(),A}if(s){let t=function(r){try{var i=r.data,a=i.Cb;if("load"===a){let r=[];for(let a of(self.onmessage=e=>r.push(e),self.startWorker=()=>{for(let e of(postMessage({Cb:"loaded"}),r))t(e);self.onmessage=t},i.Sb))e[a]&&!e[a].proxy||(e[a]=(...e)=>{postMessage({Cb:"callHandler",Rb:a,args:e})},"print"==a&&(y=e[a]),"printErr"==a&&(_=e[a]));b=i.lc,H(),V(i.mc)}else if("run"===a){e$(i.Bb),rG(i.Bb,0,0,1,0,0),ey(),tm(i.Bb),G||(rq(),G=!0);try{ev(i.hc,i.Ib)}catch(e){if("unwind"!=e)throw e}}else"setimmediate"!==i.target&&("checkMailbox"===a?G&&tg():a&&(_(`worker: received unknown command ${a}`),_(i)))}catch(e){throw rH(),e}};var V,G=!1;_=function(...e){console.error(e=e.join(" "))},self.alert=function(...e){postMessage({Cb:"alert",text:e.join(" "),jc:rW()})},self.onunhandledrejection=e=>{throw e.reason||e},self.onmessage=t}function H(){var t=b.buffer;e.HEAP8=w=new Int8Array(t),e.HEAP16=k=new Int16Array(t),e.HEAPU8=x=new Uint8Array(t),e.HEAPU16=S=new Uint16Array(t),e.HEAP32=T=new Int32Array(t),e.HEAPU32=I=new Uint32Array(t),e.HEAPF32=E=new Float32Array(t),e.HEAPF64=A=new Float64Array(t),e.HEAP64=C=new BigInt64Array(t),e.HEAPU64=z=new BigUint64Array(t)}function F(){s?startWorker(e):rM.Da()}s||(b=new WebAssembly.Memory({initial:256,maximum:65536,shared:!0}),H());var j,K=0,Z=null;function Q(){if(0==--K&&Z){var e=Z;Z=null,e()}}function X(e){throw _(e="Aborted("+e+")"),R=!0,e=new WebAssembly.RuntimeError(e+". Build with -sASSERTIONS for more info."),r(e),e}function Y(){return{a:{L:et,Aa:ee,b:ex,$:eS,A:eC,pa:ez,X:eR,Z:eB,qa:eN,na:eD,ga:eM,ma:eP,J:eU,Y:eq,V:eW,oa:eL,W:eV,va:eF,E:eJ,Q:e2,O:e9,D:te,v:tt,r:tr,P:ti,z:tp,R:tc,ja:th,T:ty,aa:tb,M:t$,F:tv,ia:tm,sa:tw,t:tS,Ca:tT,w:tP,o:tq,m:tV,c:e4,Ba:tG,n:tF,j:tK,u:tZ,p:tQ,f:tX,s:tY,l:tJ,e:t0,k:t2,h:t1,g:t3,d:t4,da:t6,ea:t9,fa:re,ba:rt,ca:rr,N:rn,xa:rs,ua:ru,i:rp,C:rc,G:rh,ta:ro,x:rf,ra:rm,U:rg,q:ra,y:ry,K:r_,S:rb,za:rx,ya:rk,ka:rE,la:rC,_:ed,B:rz,I:rA,ha:rO,H:rB,a:b,wa:eu}}}var J={840156:(t,r,i,a,n)=>{if(void 0===e||!e.Fb)return 1;if((t=eE(Number(t>>>0))).startsWith("./")&&(t=t.substring(2)),!(t=e.Fb.get(t)))return 2;if(r=Number(r>>>0),i=Number(i>>>0),a=Number(a>>>0),r+i>t.byteLength)return 3;try{let s=t.subarray(r,r+i);switch(n){case 0:D().set(s,a>>>0);break;case 1:e.nc?e.nc(a,s):e.cc(a,s);break;default:return 4}return 0}catch{return 4}},840980:(t,r,i)=>{e.Pb(t,D().subarray(r>>>0,r+i>>>0))},841044:()=>e.oc(),841086:t=>{e.Ob(t)},841123:()=>{e.Wb()},841154:()=>{e.Xb()},841183:()=>{e.ac()},841208:t=>e.Vb(t),841241:t=>e.Zb(t),841273:(t,r,i)=>{e.Lb(Number(t),Number(r),Number(i),!0)},841336:(t,r,i)=>{e.Lb(Number(t),Number(r),Number(i))},841393:()=>"u">typeof wasmOffsetConverter,841450:t=>{e.kb("Abs",t,void 0)},841501:t=>{e.kb("Neg",t,void 0)},841552:t=>{e.kb("Floor",t,void 0)},841605:t=>{e.kb("Ceil",t,void 0)},841657:t=>{e.kb("Reciprocal",t,void 0)},841715:t=>{e.kb("Sqrt",t,void 0)},841767:t=>{e.kb("Exp",t,void 0)},841818:t=>{e.kb("Erf",t,void 0)},841869:t=>{e.kb("Sigmoid",t,void 0)},841924:(t,r,i)=>{e.kb("HardSigmoid",t,{alpha:r,beta:i})},842003:t=>{e.kb("Log",t,void 0)},842054:t=>{e.kb("Sin",t,void 0)},842105:t=>{e.kb("Cos",t,void 0)},842156:t=>{e.kb("Tan",t,void 0)},842207:t=>{e.kb("Asin",t,void 0)},842259:t=>{e.kb("Acos",t,void 0)},842311:t=>{e.kb("Atan",t,void 0)},842363:t=>{e.kb("Sinh",t,void 0)},842415:t=>{e.kb("Cosh",t,void 0)},842467:t=>{e.kb("Asinh",t,void 0)},842520:t=>{e.kb("Acosh",t,void 0)},842573:t=>{e.kb("Atanh",t,void 0)},842626:t=>{e.kb("Tanh",t,void 0)},842678:t=>{e.kb("Not",t,void 0)},842729:(t,r,i)=>{e.kb("Clip",t,{min:r,max:i})},842798:t=>{e.kb("Clip",t,void 0)},842850:(t,r)=>{e.kb("Elu",t,{alpha:r})},842908:t=>{e.kb("Gelu",t,void 0)},842960:t=>{e.kb("Relu",t,void 0)},843012:(t,r)=>{e.kb("LeakyRelu",t,{alpha:r})},843076:(t,r)=>{e.kb("ThresholdedRelu",t,{alpha:r})},843146:(t,r)=>{e.kb("Cast",t,{to:r})},843204:t=>{e.kb("Add",t,void 0)},843255:t=>{e.kb("Sub",t,void 0)},843306:t=>{e.kb("Mul",t,void 0)},843357:t=>{e.kb("Div",t,void 0)},843408:t=>{e.kb("Pow",t,void 0)},843459:t=>{e.kb("Equal",t,void 0)},843512:t=>{e.kb("Greater",t,void 0)},843567:t=>{e.kb("GreaterOrEqual",t,void 0)},843629:t=>{e.kb("Less",t,void 0)},843681:t=>{e.kb("LessOrEqual",t,void 0)},843740:(t,r,i,a,n)=>{e.kb("ReduceMean",t,{keepDims:!!r,noopWithEmptyAxes:!!i,axes:a?Array.from(U().subarray(Number(a)>>>0,Number(n)>>>0)):[]})},843915:(t,r,i,a,n)=>{e.kb("ReduceMax",t,{keepDims:!!r,noopWithEmptyAxes:!!i,axes:a?Array.from(U().subarray(Number(a)>>>0,Number(n)>>>0)):[]})},844089:(t,r,i,a,n)=>{e.kb("ReduceMin",t,{keepDims:!!r,noopWithEmptyAxes:!!i,axes:a?Array.from(U().subarray(Number(a)>>>0,Number(n)>>>0)):[]})},844263:(t,r,i,a,n)=>{e.kb("ReduceProd",t,{keepDims:!!r,noopWithEmptyAxes:!!i,axes:a?Array.from(U().subarray(Number(a)>>>0,Number(n)>>>0)):[]})},844438:(t,r,i,a,n)=>{e.kb("ReduceSum",t,{keepDims:!!r,noopWithEmptyAxes:!!i,axes:a?Array.from(U().subarray(Number(a)>>>0,Number(n)>>>0)):[]})},844612:(t,r,i,a,n)=>{e.kb("ReduceL1",t,{keepDims:!!r,noopWithEmptyAxes:!!i,axes:a?Array.from(U().subarray(Number(a)>>>0,Number(n)>>>0)):[]})},844785:(t,r,i,a,n)=>{e.kb("ReduceL2",t,{keepDims:!!r,noopWithEmptyAxes:!!i,axes:a?Array.from(U().subarray(Number(a)>>>0,Number(n)>>>0)):[]})},844958:(t,r,i,a,n)=>{e.kb("ReduceLogSum",t,{keepDims:!!r,noopWithEmptyAxes:!!i,axes:a?Array.from(U().subarray(Number(a)>>>0,Number(n)>>>0)):[]})},845135:(t,r,i,a,n)=>{e.kb("ReduceSumSquare",t,{keepDims:!!r,noopWithEmptyAxes:!!i,axes:a?Array.from(U().subarray(Number(a)>>>0,Number(n)>>>0)):[]})},845315:(t,r,i,a,n)=>{e.kb("ReduceLogSumExp",t,{keepDims:!!r,noopWithEmptyAxes:!!i,axes:a?Array.from(U().subarray(Number(a)>>>0,Number(n)>>>0)):[]})},845495:t=>{e.kb("Where",t,void 0)},845548:(t,r,i)=>{e.kb("Transpose",t,{perm:r?Array.from(U().subarray(Number(r)>>>0,Number(i)>>>0)):[]})},845672:(t,r,i,a)=>{e.kb("DepthToSpace",t,{blocksize:r,mode:eE(i),format:a?"NHWC":"NCHW"})},845805:(t,r,i,a)=>{e.kb("DepthToSpace",t,{blocksize:r,mode:eE(i),format:a?"NHWC":"NCHW"})},845938:(t,r,i,a,n,s,o,u,l,d,p,c,h,f,m)=>{e.kb("ConvTranspose",t,{format:l?"NHWC":"NCHW",autoPad:r,dilations:[i],group:a,kernelShape:[n],pads:[s,o],strides:[u],wIsConst:()=>!!N()[d>>>0],outputPadding:p?Array.from(U().subarray(Number(p)>>>0,Number(c)>>>0)):[],outputShape:h?Array.from(U().subarray(Number(h)>>>0,Number(f)>>>0)):[],activation:eE(m)})},846371:(t,r,i,a,n,s,o,u,l,d,p,c,h,f)=>{e.kb("ConvTranspose",t,{format:u?"NHWC":"NCHW",autoPad:r,dilations:Array.from(U().subarray(Number(i)>>>0,2+(Number(i)>>>0)>>>0)),group:a,kernelShape:Array.from(U().subarray(Number(n)>>>0,2+(Number(n)>>>0)>>>0)),pads:Array.from(U().subarray(Number(s)>>>0,4+(Number(s)>>>0)>>>0)),strides:Array.from(U().subarray(Number(o)>>>0,2+(Number(o)>>>0)>>>0)),wIsConst:()=>!!N()[l>>>0],outputPadding:d?Array.from(U().subarray(Number(d)>>>0,Number(p)>>>0)):[],outputShape:c?Array.from(U().subarray(Number(c)>>>0,Number(h)>>>0)):[],activation:eE(f)})},847032:(t,r,i,a,n,s,o,u,l,d,p,c,h,f,m)=>{e.kb("ConvTranspose",t,{format:l?"NHWC":"NCHW",autoPad:r,dilations:[i],group:a,kernelShape:[n],pads:[s,o],strides:[u],wIsConst:()=>!!N()[d>>>0],outputPadding:p?Array.from(U().subarray(Number(p)>>>0,Number(c)>>>0)):[],outputShape:h?Array.from(U().subarray(Number(h)>>>0,Number(f)>>>0)):[],activation:eE(m)})},847465:(t,r,i,a,n,s,o,u,l,d,p,c,h,f)=>{e.kb("ConvTranspose",t,{format:u?"NHWC":"NCHW",autoPad:r,dilations:Array.from(U().subarray(Number(i)>>>0,2+(Number(i)>>>0)>>>0)),group:a,kernelShape:Array.from(U().subarray(Number(n)>>>0,2+(Number(n)>>>0)>>>0)),pads:Array.from(U().subarray(Number(s)>>>0,4+(Number(s)>>>0)>>>0)),strides:Array.from(U().subarray(Number(o)>>>0,2+(Number(o)>>>0)>>>0)),wIsConst:()=>!!N()[l>>>0],outputPadding:d?Array.from(U().subarray(Number(d)>>>0,Number(p)>>>0)):[],outputShape:c?Array.from(U().subarray(Number(c)>>>0,Number(h)>>>0)):[],activation:eE(f)})},848126:(t,r)=>{e.kb("GlobalAveragePool",t,{format:r?"NHWC":"NCHW"})},848217:(t,r,i,a,n,s,o,u,l,d,p,c,h,f)=>{e.kb("AveragePool",t,{format:f?"NHWC":"NCHW",auto_pad:r,ceil_mode:i,count_include_pad:a,storage_order:n,dilations:s?Array.from(U().subarray(Number(s)>>>0,Number(o)>>>0)):[],kernel_shape:u?Array.from(U().subarray(Number(u)>>>0,Number(l)>>>0)):[],pads:d?Array.from(U().subarray(Number(d)>>>0,Number(p)>>>0)):[],strides:c?Array.from(U().subarray(Number(c)>>>0,Number(h)>>>0)):[]})},848696:(t,r)=>{e.kb("GlobalAveragePool",t,{format:r?"NHWC":"NCHW"})},848787:(t,r,i,a,n,s,o,u,l,d,p,c,h,f)=>{e.kb("AveragePool",t,{format:f?"NHWC":"NCHW",auto_pad:r,ceil_mode:i,count_include_pad:a,storage_order:n,dilations:s?Array.from(U().subarray(Number(s)>>>0,Number(o)>>>0)):[],kernel_shape:u?Array.from(U().subarray(Number(u)>>>0,Number(l)>>>0)):[],pads:d?Array.from(U().subarray(Number(d)>>>0,Number(p)>>>0)):[],strides:c?Array.from(U().subarray(Number(c)>>>0,Number(h)>>>0)):[]})},849266:(t,r)=>{e.kb("GlobalMaxPool",t,{format:r?"NHWC":"NCHW"})},849353:(t,r,i,a,n,s,o,u,l,d,p,c,h,f)=>{e.kb("MaxPool",t,{format:f?"NHWC":"NCHW",auto_pad:r,ceil_mode:i,count_include_pad:a,storage_order:n,dilations:s?Array.from(U().subarray(Number(s)>>>0,Number(o)>>>0)):[],kernel_shape:u?Array.from(U().subarray(Number(u)>>>0,Number(l)>>>0)):[],pads:d?Array.from(U().subarray(Number(d)>>>0,Number(p)>>>0)):[],strides:c?Array.from(U().subarray(Number(c)>>>0,Number(h)>>>0)):[]})},849828:(t,r)=>{e.kb("GlobalMaxPool",t,{format:r?"NHWC":"NCHW"})},849915:(t,r,i,a,n,s,o,u,l,d,p,c,h,f)=>{e.kb("MaxPool",t,{format:f?"NHWC":"NCHW",auto_pad:r,ceil_mode:i,count_include_pad:a,storage_order:n,dilations:s?Array.from(U().subarray(Number(s)>>>0,Number(o)>>>0)):[],kernel_shape:u?Array.from(U().subarray(Number(u)>>>0,Number(l)>>>0)):[],pads:d?Array.from(U().subarray(Number(d)>>>0,Number(p)>>>0)):[],strides:c?Array.from(U().subarray(Number(c)>>>0,Number(h)>>>0)):[]})},850390:(t,r,i,a,n)=>{e.kb("Gemm",t,{alpha:r,beta:i,transA:a,transB:n})},850494:t=>{e.kb("MatMul",t,void 0)},850548:(t,r,i,a)=>{e.kb("ArgMax",t,{keepDims:!!r,selectLastIndex:!!i,axis:a})},850656:(t,r,i,a)=>{e.kb("ArgMin",t,{keepDims:!!r,selectLastIndex:!!i,axis:a})},850764:(t,r)=>{e.kb("Softmax",t,{axis:r})},850827:(t,r)=>{e.kb("Concat",t,{axis:r})},850887:(t,r,i,a,n)=>{e.kb("Split",t,{axis:r,numOutputs:i,splitSizes:a?Array.from(U().subarray(Number(a)>>>0,Number(n)>>>0)):[]})},851043:t=>{e.kb("Expand",t,void 0)},851097:(t,r)=>{e.kb("Gather",t,{axis:Number(r)})},851168:(t,r)=>{e.kb("GatherElements",t,{axis:Number(r)})},851247:(t,r)=>{e.kb("GatherND",t,{batch_dims:Number(r)})},851326:(t,r,i,a,n,s,o,u,l,d,p)=>{e.kb("Resize",t,{antialias:r,axes:i?Array.from(U().subarray(Number(i)>>>0,Number(a)>>>0)):[],coordinateTransformMode:eE(n),cubicCoeffA:s,excludeOutside:o,extrapolationValue:u,keepAspectRatioPolicy:eE(l),mode:eE(d),nearestMode:eE(p)})},851688:(t,r,i,a,n,s,o)=>{e.kb("Slice",t,{starts:r?Array.from(U().subarray(Number(r)>>>0,Number(i)>>>0)):[],ends:a?Array.from(U().subarray(Number(a)>>>0,Number(n)>>>0)):[],axes:s?Array.from(U().subarray(Number(s)>>>0,Number(o)>>>0)):[]})},851952:t=>{e.kb("Tile",t,void 0)},852004:(t,r,i)=>{e.kb("InstanceNormalization",t,{epsilon:r,format:i?"NHWC":"NCHW"})},852118:(t,r,i)=>{e.kb("InstanceNormalization",t,{epsilon:r,format:i?"NHWC":"NCHW"})},852232:t=>{e.kb("Range",t,void 0)},852285:(t,r)=>{e.kb("Einsum",t,{equation:eE(r)})},852366:(t,r,i,a,n)=>{e.kb("Pad",t,{mode:r,value:i,pads:a?Array.from(U().subarray(Number(a)>>>0,Number(n)>>>0)):[]})},852509:(t,r,i,a,n,s)=>{e.kb("BatchNormalization",t,{epsilon:r,momentum:i,spatial:!!n,trainingMode:!!a,format:s?"NHWC":"NCHW"})},852678:(t,r,i,a,n,s)=>{e.kb("BatchNormalization",t,{epsilon:r,momentum:i,spatial:!!n,trainingMode:!!a,format:s?"NHWC":"NCHW"})},852847:(t,r,i)=>{e.kb("CumSum",t,{exclusive:Number(r),reverse:Number(i)})},852944:(t,r,i)=>{e.kb("DequantizeLinear",t,{axis:r,blockSize:i})},853034:(t,r,i,a,n)=>{e.kb("GridSample",t,{align_corners:r,mode:eE(i),padding_mode:eE(a),format:n?"NHWC":"NCHW"})},853204:(t,r,i,a,n)=>{e.kb("GridSample",t,{align_corners:r,mode:eE(i),padding_mode:eE(a),format:n?"NHWC":"NCHW"})},853374:(t,r)=>{e.kb("ScatterND",t,{reduction:eE(r)})},853459:(t,r,i,a,n,s,o,u,l)=>{e.kb("Attention",t,{numHeads:r,isUnidirectional:i,maskFilterValue:a,scale:n,doRotary:s,qkvHiddenSizes:o?Array.from(U().subarray(Number(u)>>>0,Number(u)+o>>>0)):[],pastPresentShareBuffer:!!l})},853731:t=>{e.kb("BiasAdd",t,void 0)},853786:t=>{e.kb("BiasSplitGelu",t,void 0)},853847:t=>{e.kb("FastGelu",t,void 0)},853903:(t,r,i,a,n,s,o,u,l,d,p,c,h,f,m,g)=>{e.kb("Conv",t,{format:c?"NHWC":"NCHW",auto_pad:r,dilations:i?Array.from(U().subarray(Number(i)>>>0,Number(a)>>>0)):[],group:n,kernel_shape:s?Array.from(U().subarray(Number(s)>>>0,Number(o)>>>0)):[],pads:u?Array.from(U().subarray(Number(u)>>>0,Number(l)>>>0)):[],strides:d?Array.from(U().subarray(Number(d)>>>0,Number(p)>>>0)):[],w_is_const:()=>!!N()[Number(h)>>>0],activation:eE(f),activation_params:m?Array.from(W().subarray(Number(m)>>>0,Number(g)>>>0)):[]})},854487:t=>{e.kb("Gelu",t,void 0)},854539:(t,r,i,a,n,s,o,u,l)=>{e.kb("GroupQueryAttention",t,{numHeads:r,kvNumHeads:i,scale:a,softcap:n,doRotary:s,rotaryInterleaved:o,smoothSoftmax:u,localWindowSize:l})},854756:(t,r,i,a)=>{e.kb("LayerNormalization",t,{axis:r,epsilon:i,simplified:!!a})},854867:(t,r,i,a)=>{e.kb("LayerNormalization",t,{axis:r,epsilon:i,simplified:!!a})},854978:(t,r,i,a,n,s)=>{e.kb("MatMulNBits",t,{k:r,n:i,accuracyLevel:a,bits:n,blockSize:s})},855105:(t,r,i,a,n,s)=>{e.kb("MultiHeadAttention",t,{numHeads:r,isUnidirectional:i,maskFilterValue:a,scale:n,doRotary:s})},855264:(t,r)=>{e.kb("QuickGelu",t,{alpha:r})},855328:(t,r,i,a,n)=>{e.kb("RotaryEmbedding",t,{interleaved:!!r,numHeads:i,rotaryEmbeddingDim:a,scale:n})},855467:(t,r,i)=>{e.kb("SkipLayerNormalization",t,{epsilon:r,simplified:!!i})},855569:(t,r,i)=>{e.kb("SkipLayerNormalization",t,{epsilon:r,simplified:!!i})},855671:(t,r,i,a)=>{e.kb("GatherBlockQuantized",t,{gatherAxis:r,quantizeAxis:i,blockSize:a})},855792:t=>{e.$b(t)},855826:(t,r)=>e.bc(Number(t),Number(r),e.Gb.ec,e.Gb.errors)};function ee(t,r,i){return tM(async()=>{await e.Yb(Number(t),Number(r),Number(i))})}function et(){return"u">typeof wasmOffsetConverter}class er{name="ExitStatus";constructor(e){this.message=`Program terminated with exit(${e})`,this.status=e}}var ei=e=>{e.terminate(),e.onmessage=()=>{}},ea=[],en=e=>{0==ep.length&&(eb(),e_(ep[0]));var t=ep.pop();if(!t)return 6;eh.push(t),em[e.Bb]=t,t.Bb=e.Bb;var r={Cb:"run",hc:e.fc,Ib:e.Ib,Bb:e.Bb};return t.postMessage(r,e.Nb),0},es=0,eo=(e,t,...r)=>{for(var i=2*r.length,a=r0(),n=rJ(8*i),s=n>>>3,o=0;o<r.length;o++){var u=r[o];"bigint"==typeof u?(C[s+2*o]=1n,C[s+2*o+1]=u):(C[s+2*o]=0n,L()[s+2*o+1>>>0]=u)}return e=rF(e,0,i,n,t),rY(a),e};function eu(e){if(s)return eo(0,1,e);if(v=e,!(0<es)){for(var t of eh)ei(t);for(t of ep)ei(t);ep=[],eh=[],em={},R=!0}h(0,new er(e))}function el(e){if(s)return eo(1,0,e);ed(e)}var ed=e=>{if(v=e,s)throw el(e),"unwind";eu(e)},ep=[],eh=[],ef=[],em={},eg=e=>{var t=e.Bb;delete em[t],ep.push(e),eh.splice(eh.indexOf(e),1),e.Bb=0,rj(t)};function ey(){ef.forEach(e=>e())}var e_=t=>new Promise(r=>{t.onmessage=i=>{var a=(i=i.data).Cb;if(i.Hb&&i.Hb!=rW()){var n=em[i.Hb];n?n.postMessage(i,i.Nb):_(`Internal error! Worker sent a message "${a}" to target pthread ${i.Hb}, but that thread no longer exists!`)}else"checkMailbox"===a?tg():"spawnThread"===a?en(i):"cleanupThread"===a?eg(em[i.ic]):"loaded"===a?(t.loaded=!0,r(t)):"alert"===a?alert(`Thread ${i.jc}: ${i.text}`):"setimmediate"===i.target?t.postMessage(i):"callHandler"===a?e[i.Rb](...i.args):a&&_(`worker sent an unknown command ${a}`)},t.onerror=e=>{throw _(`worker sent an error! ${e.filename}:${e.lineno}: ${e.message}`),e};var i,a=[];for(i of[])e.propertyIsEnumerable(i)&&a.push(i);t.postMessage({Cb:"load",Sb:a,lc:b,mc:$})});function eb(){let e;var t=new Worker((e=URL,import.meta.url>"file:"&&import.meta.url<"file;"?new e("ort.bundle.min.mjs",import.meta.url):new URL(import.meta.url)),{type:"module",workerData:"em-pthread",name:"em-pthread"});ep.push(t)}var e$=e=>{H();var t=q()[e+52>>>2>>>0];e=q()[e+56>>>2>>>0],rX(t,t-e),rY(t)},ev=(e,t)=>{es=0,e=r2(e,t),0<es?v=e:rK(e)};class ew{constructor(e){this.Jb=e-24}}function ex(e,t,r){var i=new ew(e>>>=0);throw t>>>=0,r>>>=0,q()[i.Jb+16>>>2>>>0]=0,q()[i.Jb+4>>>2>>>0]=t,q()[i.Jb+8>>>2>>>0]=r,e}function ek(e,t,r,i){return s?eo(2,1,e,t,r,i):eS(e,t,r,i)}function eS(e,t,r,i){if(e>>>=0,r>>>=0,i>>>=0,void 0===o)return 6;var a=[];return s&&0===a.length?ek(e,t>>>=0,r,i):(e={fc:r,Bb:e,Ib:i,Nb:a},s?(e.Cb="spawnThread",postMessage(e,a),0):en(e))}var eT="u">typeof TextDecoder?new TextDecoder:void 0,eI=(e,t=0,r=0/0)=>{var i=(t>>>=0)+r;for(r=t;e[r]&&!(r>=i);)++r;if(16<r-t&&e.buffer&&eT)return eT.decode(e.buffer instanceof ArrayBuffer?e.subarray(t,r):e.slice(t,r));for(i="";t<r;){var a=e[t++];if(128&a){var n=63&e[t++];if((224&a)==192)i+=String.fromCharCode((31&a)<<6|n);else{var s=63&e[t++];65536>(a=(240&a)==224?(15&a)<<12|n<<6|s:(7&a)<<18|n<<12|s<<6|63&e[t++])?i+=String.fromCharCode(a):(a-=65536,i+=String.fromCharCode(55296|a>>10,56320|1023&a))}}else i+=String.fromCharCode(a)}return i},eE=(e,t)=>(e>>>=0)?eI(D(),e,t):"";function eC(e,t,r){return s?eo(3,1,e,t,r):0}function ez(e,t){if(s)return eo(4,1,e,t)}var eA=e=>{for(var t=0,r=0;r<e.length;++r){var i=e.charCodeAt(r);127>=i?t++:2047>=i?t+=2:55296<=i&&57343>=i?(t+=4,++r):t+=3}return t},eO=(e,t,r)=>{var i=D();if(t>>>=0,0<r){var a=t;r=t+r-1;for(var n=0;n<e.length;++n){var s=e.charCodeAt(n);if(55296<=s&&57343>=s&&(s=65536+((1023&s)<<10)|1023&e.charCodeAt(++n)),127>=s){if(t>=r)break;i[t++>>>0]=s}else{if(2047>=s){if(t+1>=r)break;i[t++>>>0]=192|s>>6}else{if(65535>=s){if(t+2>=r)break;i[t++>>>0]=224|s>>12}else{if(t+3>=r)break;i[t++>>>0]=240|s>>18,i[t++>>>0]=128|s>>12&63}i[t++>>>0]=128|s>>6&63}i[t++>>>0]=128|63&s}}i[t>>>0]=0,e=t-a}else e=0;return e};function eR(e,t){if(s)return eo(5,1,e,t)}function eB(e,t,r){if(s)return eo(6,1,e,t,r)}function eN(e,t,r){return s?eo(7,1,e,t,r):0}function eD(e,t){if(s)return eo(8,1,e,t)}function eM(e,t,r){if(s)return eo(9,1,e,t,r)}function eP(e,t,r,i){if(s)return eo(10,1,e,t,r,i)}function eU(e,t,r,i){if(s)return eo(11,1,e,t,r,i)}function eq(e,t,r,i){if(s)return eo(12,1,e,t,r,i)}function eW(e){if(s)return eo(13,1,e)}function eL(e,t){if(s)return eo(14,1,e,t)}function eV(e,t,r){if(s)return eo(15,1,e,t,r)}var eG,eH,eF=()=>X(""),ej=e=>{for(var t="";D()[e>>>0];)t+=eG[D()[e++>>>0]];return t},eK={},eZ={},eQ={};function eX(e,t,r={}){return function(e,t,r={}){var i=t.name;if(!e)throw new eH(`type "${i}" must have a positive integer typeid pointer`);if(eZ.hasOwnProperty(e)){if(r.Tb)return;throw new eH(`Cannot register type '${i}' twice`)}eZ[e]=t,delete eQ[e],eK.hasOwnProperty(e)&&(t=eK[e],delete eK[e],t.forEach(e=>e()))}(e,t,r)}var eY=(e,t,r)=>{switch(t){case 1:return r?e=>N()[e>>>0]:e=>D()[e>>>0];case 2:return r?e=>M()[e>>>1>>>0]:e=>P()[e>>>1>>>0];case 4:return r?e=>U()[e>>>2>>>0]:e=>q()[e>>>2>>>0];case 8:return r?e=>C[e>>>3]:e=>z[e>>>3];default:throw TypeError(`invalid integer width (${t}): ${e}`)}};function eJ(e,t,r){r>>>=0,eX(e>>>=0,{name:t=ej(t>>>0),fromWireType:e=>e,toWireType:function(e,t){if("bigint"!=typeof t&&"number"!=typeof t)throw t=null===t?"null":"object"==(e=typeof t)||"array"===e||"function"===e?t.toString():""+t,TypeError(`Cannot convert "${t}" to ${this.name}`);return"number"==typeof t&&(t=BigInt(t)),t},Db:e0,readValueFromPointer:eY(t,r,-1==t.indexOf("u")),Eb:null})}var e0=8;function e2(e,t,r,i){eX(e>>>=0,{name:t=ej(t>>>0),fromWireType:function(e){return!!e},toWireType:function(e,t){return t?r:i},Db:e0,readValueFromPointer:function(e){return this.fromWireType(D()[e>>>0])},Eb:null})}var e1=[],e3=[];function e4(e){9<(e>>>=0)&&0==--e3[e+1]&&(e3[e]=void 0,e1.push(e))}var e6=e=>{if(!e)throw new eH("Cannot use deleted val. handle = "+e);return e3[e]},e8=e=>{switch(e){case void 0:return 2;case null:return 4;case!0:return 6;case!1:return 8;default:let t=e1.pop()||e3.length;return e3[t]=e,e3[t+1]=1,t}};function e5(e){return this.fromWireType(q()[e>>>2>>>0])}var e7={name:"emscripten::val",fromWireType:e=>{var t=e6(e);return e4(e),t},toWireType:(e,t)=>e8(t),Db:8,readValueFromPointer:e5,Eb:null};function e9(e){return eX(e>>>0,e7)}function te(e,t,r){r>>>=0,eX(e>>>=0,{name:t=ej(t>>>0),fromWireType:e=>e,toWireType:(e,t)=>t,Db:e0,readValueFromPointer:((e,t)=>{switch(t){case 4:return function(e){return this.fromWireType(W()[e>>>2>>>0])};case 8:return function(e){return this.fromWireType(L()[e>>>3>>>0])};default:throw TypeError(`invalid float width (${t}): ${e}`)}})(t,r),Eb:null})}function tt(e,t,r,i,a){if(e>>>=0,r>>>=0,t=ej(t>>>0),-1===a&&(a=0xffffffff),a=e=>e,0===i){var n=32-8*r;a=e=>e<<n>>>n}var s=t.includes("unsigned")?function(e,t){return t>>>0}:function(e,t){return t};eX(e,{name:t,fromWireType:a,toWireType:s,Db:e0,readValueFromPointer:eY(t,r,0!==i),Eb:null})}function tr(e,t,r){function i(e){var t=q()[e>>>2>>>0];return e=q()[e+4>>>2>>>0],new a(N().buffer,e,t)}var a=[Int8Array,Uint8Array,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array,BigInt64Array,BigUint64Array][t];eX(e>>>=0,{name:r=ej(r>>>0),fromWireType:i,Db:e0,readValueFromPointer:i},{Tb:!0})}function ti(e,t){eX(e>>>=0,{name:t=ej(t>>>0),fromWireType:function(e){for(var t,r=q()[e>>>2>>>0],i=e+4,a=i,n=0;n<=r;++n){var s=i+n;n!=r&&0!=D()[s>>>0]||(a=eE(a,s-a),void 0===t?t=a:(t+="\0",t+=a),a=s+1)}return rL(e),t},toWireType:function(e,t){t instanceof ArrayBuffer&&(t=new Uint8Array(t));var r="string"==typeof t;if(!(r||t instanceof Uint8Array||t instanceof Uint8ClampedArray||t instanceof Int8Array))throw new eH("Cannot pass non-string to std::string");var i=r?eA(t):t.length,a=rV(4+i+1),n=a+4;if(q()[a>>>2>>>0]=i,r)eO(t,n,i+1);else if(r)for(r=0;r<i;++r){var s=t.charCodeAt(r);if(255<s)throw rL(a),new eH("String has UTF-16 code units that do not fit in 8 bits");D()[n+r>>>0]=s}else for(r=0;r<i;++r)D()[n+r>>>0]=t[r];return null!==e&&e.push(rL,a),a},Db:e0,readValueFromPointer:e5,Eb(e){rL(e)}})}var ta="u">typeof TextDecoder?new TextDecoder("utf-16le"):void 0,tn=(e,t)=>{for(var r=e>>1,i=r+t/2;!(r>=i)&&P()[r>>>0];)++r;if(32<(r<<=1)-e&&ta)return ta.decode(D().slice(e,r));for(r="",i=0;!(i>=t/2);++i){var a=M()[e+2*i>>>1>>>0];if(0==a)break;r+=String.fromCharCode(a)}return r},ts=(e,t,r)=>{if(2>(r??=0x7fffffff))return 0;var i=t;r=(r-=2)<2*e.length?r/2:e.length;for(var a=0;a<r;++a){var n=e.charCodeAt(a);M()[t>>>1>>>0]=n,t+=2}return M()[t>>>1>>>0]=0,t-i},to=e=>2*e.length,tu=(e,t)=>{for(var r=0,i="";!(r>=t/4);){var a=U()[e+4*r>>>2>>>0];if(0==a)break;++r,65536<=a?(a-=65536,i+=String.fromCharCode(55296|a>>10,56320|1023&a)):i+=String.fromCharCode(a)}return i},tl=(e,t,r)=>{if(t>>>=0,4>(r??=0x7fffffff))return 0;var i=t;r=i+r-4;for(var a=0;a<e.length;++a){var n=e.charCodeAt(a);if(55296<=n&&57343>=n&&(n=65536+((1023&n)<<10)|1023&e.charCodeAt(++a)),U()[t>>>2>>>0]=n,(t+=4)+4>r)break}return U()[t>>>2>>>0]=0,t-i},td=e=>{for(var t=0,r=0;r<e.length;++r){var i=e.charCodeAt(r);55296<=i&&57343>=i&&++r,t+=4}return t};function tp(e,t,r){if(e>>>=0,t>>>=0,r=ej(r>>>=0),2===t)var i=tn,a=ts,n=to,s=e=>P()[e>>>1>>>0];else 4===t&&(i=tu,a=tl,n=td,s=e=>q()[e>>>2>>>0]);eX(e,{name:r,fromWireType:e=>{for(var r,a=q()[e>>>2>>>0],n=e+4,o=0;o<=a;++o){var u=e+4+o*t;o!=a&&0!=s(u)||(n=i(n,u-n),void 0===r?r=n:(r+="\0",r+=n),n=u+t)}return rL(e),r},toWireType:(e,i)=>{if("string"!=typeof i)throw new eH(`Cannot pass non-string to C++ string type ${r}`);var s=n(i),o=rV(4+s+t);return q()[o>>>2>>>0]=s/t,a(i,o+4,s+t),null!==e&&e.push(rL,o),o},Db:e0,readValueFromPointer:e5,Eb(e){rL(e)}})}function tc(e,t){eX(e>>>=0,{Ub:!0,name:t=ej(t>>>0),Db:0,fromWireType:()=>{},toWireType:()=>{}})}function th(e){rG(e>>>0,!n,1,!a,131072,!1),ey()}var tf=e=>{if(!R)try{if(e(),!(0<es))try{s?rK(v):ed(v)}catch(e){e instanceof er||"unwind"==e||h(0,e)}}catch(e){e instanceof er||"unwind"==e||h(0,e)}};function tm(e){e>>>=0,"function"==typeof Atomics.kc&&(Atomics.kc(U(),e>>>2,e).value.then(tg),e+=128,Atomics.store(U(),e>>>2,1))}var tg=()=>{var e=rW();e&&(tm(e),tf(rQ))};function ty(e,t){(e>>>=0)==t>>>0?setTimeout(tg):s?postMessage({Hb:e,Cb:"checkMailbox"}):(e=em[e])&&e.postMessage({Cb:"checkMailbox"})}var t_=[];function tb(e,t,r,i,a){for(t>>>=0,t_.length=i/=2,r=a>>>0>>>3,a=0;a<i;a++)t_[a]=C[r+2*a]?C[r+2*a+1]:L()[r+2*a+1>>>0];return(t?J[t]:rP[e])(...t_)}var t$=()=>{es=0};function tv(e){e>>>=0,s?postMessage({Cb:"cleanupThread",ic:e}):eg(em[e])}function tw(e){}var tx=(e,t)=>{var r=eZ[e];if(void 0===r)throw r=ej(e=rU(e)),rL(e),new eH(`${t} has unknown type ${r}`);return r},tk=(e,t,r)=>{var i=[];return e=e.toWireType(i,r),i.length&&(q()[t>>>2>>>0]=e8(i)),e};function tS(e,t,r){return t>>>=0,r>>>=0,e=e6(e>>>0),tk(t=tx(t,"emval::as"),r,e)}function tT(e,t){return t>>>=0,e=e6(e>>>0),(t=tx(t,"emval::as")).toWireType(null,e)}var tI=e=>{try{e()}catch(e){X(e)}},tE=0,tC=null,tz=0,tA=[],tO={},tR={},tB=0,tN=null,tD=[];function tM(e){return function(e){if(!R){if(0===tE){var t,r,i,a=!1,n=!1;e((e=0)=>{if(!R&&(tz=e,a=!0,n)){tE=2,tI(()=>r4(tC)),"u">typeof MainLoop&&MainLoop.Qb&&MainLoop.resume(),e=!1;try{var t,r=(t=rM[tR[t=U()[tC+8>>>2>>>0]]],--es,t())}catch(t){r=t,e=!0}var i=!1;if(!tC){var s=tN;s&&(tN=null,(e?s.reject:s.resolve)(r),i=!0)}if(e&&!i)throw r}}),n=!0,a||(tE=1,r=(t=rV(65548))+12,q()[t>>>2>>>0]=r,q()[t+4>>>2>>>0]=r+65536,void 0===(i=tO[r=tA[0]])&&(i=tB++,tO[r]=i,tR[i]=r),r=i,U()[t+8>>>2>>>0]=r,tC=t,"u">typeof MainLoop&&MainLoop.Qb&&MainLoop.pause(),tI(()=>r1(tC)))}else 2===tE?(tE=0,tI(r6),rL(tC),tC=null,tD.forEach(tf)):X(`invalid state: ${tE}`);return tz}}(t=>{e().then(t)})}function tP(e){return e>>>=0,tM(async()=>e8(await e6(e)))}var tU=[];function tq(e,t,r,i){return r>>>=0,i>>>=0,(e=tU[e>>>0])(null,t=e6(t>>>0),r,i)}var tW={},tL=e=>{var t=tW[e];return void 0===t?ej(e):t};function tV(e,t,r,i,a){return r>>>=0,i>>>=0,a>>>=0,(e=tU[e>>>0])(t=e6(t>>>0),t[r=tL(r)],i,a)}function tG(e,t){return t>>>=0,(e=e6(e>>>0))==e6(t)}var tH=()=>"object"==typeof globalThis?globalThis:Function("return this")();function tF(e){return 0==(e>>>=0)?e8(tH()):(e=tL(e),e8(tH()[e]))}var tj=(e,t)=>Object.defineProperty(t,"name",{value:e});function tK(e,t,r){var i,a,n=(t=((e,t)=>{for(var r=Array(e),i=0;i<e;++i)r[i]=tx(q()[t+4*i>>>2>>>0],"parameter "+i);return r})(e,t>>>0)).shift();e--;var s=`return function (obj, func, destructorsRef, args) {
`,o=0,u=[];0===r&&u.push("obj");for(var l=["retType"],d=[n],p=0;p<e;++p)u.push("arg"+p),l.push("argType"+p),d.push(t[p]),s+=`  var arg${p} = argType${p}.readValueFromPointer(args${o?"+"+o:""});
`,o+=t[p].Db;return s+=`  var rv = ${1===r?"new func":"func.call"}(${u.join(", ")});
`,n.Ub||(l.push("emval_returnValue"),d.push(tk),s+=`  return emval_returnValue(retType, destructorsRef, rv);
`),l.push(s+`};
`),e=(function(e){var t=Function;if(!(t instanceof Function))throw TypeError(`new_ called with constructor type ${typeof t} which is not a function`);var r=tj(t.name||"unknownFunctionName",function(){});return r.prototype=t.prototype,r=new r,(e=t.apply(r,e))instanceof Object?e:r})(l)(...d),i=tj(r=`methodCaller<(${t.map(e=>e.name).join(", ")}) => ${n.name}>`,e),a=tU.length,tU.push(i),a}function tZ(t){return e8(e[t=tL(t>>>0)])}function tQ(e,t){return t>>>=0,e8((e=e6(e>>>0))[t=e6(t)])}function tX(e){9<(e>>>=0)&&(e3[e+1]+=1)}function tY(){return e8([])}function tJ(e){e=e6(e>>>0);for(var t=Array(e.length),r=0;r<e.length;r++)t[r]=e[r];return e8(t)}function t0(e){return e8(tL(e>>>0))}function t2(){return e8({})}function t1(e){for(var t=e6(e>>>=0);t.length;){var r=t.pop();t.pop()(r)}e4(e)}function t3(e,t,r){t>>>=0,r>>>=0,e=e6(e>>>0),t=e6(t),r=e6(r),e[t]=r}function t4(e,t){return t>>>=0,e8(e=(e=tx(e>>>0,"_emval_take_value")).readValueFromPointer(t))}function t6(e,t){e=-0x20000000000000>e||0x20000000000000<e?0/0:Number(e),t>>>=0,e=new Date(1e3*e),U()[t>>>2>>>0]=e.getUTCSeconds(),U()[t+4>>>2>>>0]=e.getUTCMinutes(),U()[t+8>>>2>>>0]=e.getUTCHours(),U()[t+12>>>2>>>0]=e.getUTCDate(),U()[t+16>>>2>>>0]=e.getUTCMonth(),U()[t+20>>>2>>>0]=e.getUTCFullYear()-1900,U()[t+24>>>2>>>0]=e.getUTCDay(),e=(e.getTime()-Date.UTC(e.getUTCFullYear(),0,1,0,0,0,0))/864e5|0,U()[t+28>>>2>>>0]=e}var t8=e=>e%4==0&&(e%100!=0||e%400==0),t5=[0,31,60,91,121,152,182,213,244,274,305,335],t7=[0,31,59,90,120,151,181,212,243,273,304,334];function t9(e,t){e=-0x20000000000000>e||0x20000000000000<e?0/0:Number(e),t>>>=0,e=new Date(1e3*e),U()[t>>>2>>>0]=e.getSeconds(),U()[t+4>>>2>>>0]=e.getMinutes(),U()[t+8>>>2>>>0]=e.getHours(),U()[t+12>>>2>>>0]=e.getDate(),U()[t+16>>>2>>>0]=e.getMonth(),U()[t+20>>>2>>>0]=e.getFullYear()-1900,U()[t+24>>>2>>>0]=e.getDay();var r=(t8(e.getFullYear())?t5:t7)[e.getMonth()]+e.getDate()-1|0;U()[t+28>>>2>>>0]=r,U()[t+36>>>2>>>0]=-60*e.getTimezoneOffset(),r=new Date(e.getFullYear(),6,1).getTimezoneOffset();var i=new Date(e.getFullYear(),0,1).getTimezoneOffset();e=0|(r!=i&&e.getTimezoneOffset()==Math.min(i,r)),U()[t+32>>>2>>>0]=e}function re(e){e>>>=0;var t=new Date(U()[e+20>>>2>>>0]+1900,U()[e+16>>>2>>>0],U()[e+12>>>2>>>0],U()[e+8>>>2>>>0],U()[e+4>>>2>>>0],U()[e>>>2>>>0],0),r=U()[e+32>>>2>>>0],i=t.getTimezoneOffset(),a=new Date(t.getFullYear(),6,1).getTimezoneOffset(),n=new Date(t.getFullYear(),0,1).getTimezoneOffset(),s=Math.min(n,a);return 0>r?U()[e+32>>>2>>>0]=+(a!=n&&s==i):0<r!=(s==i)&&(a=Math.max(n,a),t.setTime(t.getTime()+6e4*((0<r?s:a)-i))),U()[e+24>>>2>>>0]=t.getDay(),r=(t8(t.getFullYear())?t5:t7)[t.getMonth()]+t.getDate()-1|0,U()[e+28>>>2>>>0]=r,U()[e>>>2>>>0]=t.getSeconds(),U()[e+4>>>2>>>0]=t.getMinutes(),U()[e+8>>>2>>>0]=t.getHours(),U()[e+12>>>2>>>0]=t.getDate(),U()[e+16>>>2>>>0]=t.getMonth(),U()[e+20>>>2>>>0]=t.getYear(),BigInt(isNaN(e=t.getTime())?-1:e/1e3)}function rt(e,t,r,i,a,n,o){return s?eo(16,1,e,t,r,i,a,n,o):-52}function rr(e,t,r,i,a,n){if(s)return eo(17,1,e,t,r,i,a,n)}var ri={},ra=()=>performance.timeOrigin+performance.now();function rn(e,t){if(s)return eo(18,1,e,t);if(ri[e]&&(clearTimeout(ri[e].id),delete ri[e]),!t)return 0;var r=setTimeout(()=>{delete ri[e],tf(()=>rZ(e,performance.timeOrigin+performance.now()))},t);return ri[e]={id:r,rc:t},0}function rs(e,t,r,i){e>>>=0,t>>>=0,r>>>=0,i>>>=0;var a=new Date().getFullYear(),n=new Date(a,0,1).getTimezoneOffset(),s=Math.max(n,a=new Date(a,6,1).getTimezoneOffset());q()[e>>>2>>>0]=60*s,U()[t>>>2>>>0]=+(n!=a),e=(t=e=>{var t=Math.abs(e);return`UTC${0<=e?"-":"+"}${String(Math.floor(t/60)).padStart(2,"0")}${String(t%60).padStart(2,"0")}`})(n),t=t(a),a<n?(eO(e,r,17),eO(t,i,17)):(eO(e,i,17),eO(t,r,17))}var ro=()=>Date.now();function ru(e,t,r){return 0<=e&&3>=e?(e=0===e?Date.now():performance.timeOrigin+performance.now(),C[r>>>0>>>3]=BigInt(Math.round(1e6*e)),0):28}var rl=[],rd=(e,t)=>{rl.length=0;for(var r;r=D()[e++>>>0];){var i=105!=r;t+=(i&=112!=r)&&t%8?4:0,rl.push(112==r?q()[t>>>2>>>0]:106==r?C[t>>>3]:105==r?U()[t>>>2>>>0]:L()[t>>>3>>>0]),t+=i?8:4}return rl};function rp(e,t,r){return e>>>=0,t=rd(t>>>0,r>>>0),J[e](...t)}function rc(e,t,r){return e>>>=0,t=rd(t>>>0,r>>>0),J[e](...t)}var rh=()=>{};function rf(e,t){return _(eE(e>>>0,t>>>0))}var rm=()=>{throw es+=1,"unwind"};function rg(){return 0xffff0000}var ry=()=>navigator.hardwareConcurrency;function r_(){return X("Cannot use emscripten_pc_get_function without -sUSE_OFFSET_CONVERTER"),0}function rb(e){e>>>=0;var t=D().length;if(e<=t||0xffff0000<e)return!1;for(var r=1;4>=r;r*=2){var i=t*(1+.2/r);i=Math.min(i,e+0x6000000);e:{i=(Math.min(0xffff0000,65536*Math.ceil(Math.max(e,i)/65536))-b.buffer.byteLength+65535)/65536|0;try{b.grow(i),H();var a=1;break e}catch{}a=void 0}if(a)return!0}return!1}var r$=()=>(X("Cannot use convertFrameToPC (needed by __builtin_return_address) without -sUSE_OFFSET_CONVERTER"),0),rv={},rw=e=>{e.forEach(e=>{var t=r$();t&&(rv[t]=e)})};function rx(){var e=Error().stack.toString().split(`
`);return"Error"==e[0]&&e.shift(),rw(e),rv.Mb=r$(),rv.dc=e,rv.Mb}function rk(e,t,r){if(e>>>=0,t>>>=0,rv.Mb==e)var i=rv.dc;else"Error"==(i=Error().stack.toString().split(`
`))[0]&&i.shift(),rw(i);for(var a=3;i[a]&&r$()!=e;)++a;for(e=0;e<r&&i[e+a];++e)U()[t+4*e>>>2>>>0]=r$();return e}var rS,rT={},rI=()=>{if(!rS){var e,t={USER:"web_user",LOGNAME:"web_user",PATH:"/",PWD:"/",HOME:"/home/web_user",LANG:("object"==typeof navigator&&navigator.languages&&navigator.languages[0]||"C").replace("-","_")+".UTF-8",_:"./this.program"};for(e in rT)void 0===rT[e]?delete t[e]:t[e]=rT[e];var r=[];for(e in t)r.push(`${e}=${t[e]}`);rS=r}return rS};function rE(e,t){if(s)return eo(19,1,e,t);e>>>=0,t>>>=0;var r=0;return rI().forEach((i,a)=>{var n=t+r;for(a=q()[e+4*a>>>2>>>0]=n,n=0;n<i.length;++n)N()[a++>>>0]=i.charCodeAt(n);N()[a>>>0]=0,r+=i.length+1}),0}function rC(e,t){if(s)return eo(20,1,e,t);e>>>=0,t>>>=0;var r=rI();q()[e>>>2>>>0]=r.length;var i=0;return r.forEach(e=>i+=e.length+1),q()[t>>>2>>>0]=i,0}function rz(e){return s?eo(21,1,e):52}function rA(e,t,r,i){return s?eo(22,1,e,t,r,i):52}function rO(e,t,r,i){return s?eo(23,1,e,t,r,i):70}var rR=[null,[],[]];function rB(e,t,r,i){if(s)return eo(24,1,e,t,r,i);t>>>=0,r>>>=0,i>>>=0;for(var a=0,n=0;n<r;n++){var o=q()[t>>>2>>>0],u=q()[t+4>>>2>>>0];t+=8;for(var l=0;l<u;l++){var d=D()[o+l>>>0],p=rR[e];0===d||10===d?((1===e?y:_)(eI(p)),p.length=0):p.push(d)}a+=u}return q()[i>>>2>>>0]=a,0}s||function(){for(var t=e.numThreads-1;t--;)eb();ea.unshift(()=>{var e;K++,e=()=>Q(),s?e():Promise.all(ep.map(e_)).then(e)})}();for(var rN=Array(256),rD=0;256>rD;++rD)rN[rD]=String.fromCharCode(rD);eG=rN,eH=e.BindingError=class extends Error{constructor(e){super(e),this.name="BindingError"}},e.InternalError=class extends Error{constructor(e){super(e),this.name="InternalError"}},e3.push(0,1,void 0,1,null,1,!0,1,!1,1),e.count_emval_handles=()=>e3.length/2-5-e1.length;var rM,rP=[eu,el,ek,eC,ez,eR,eB,eN,eD,eM,eP,eU,eq,eW,eL,eV,rt,rr,rn,rE,rC,rz,rA,rO,rB];!async function(){function t(e,t){var r,i,a;return rM=e.exports,r=rM=function(){var e={};for(let[t,r]of Object.entries(rM))e[t]="function"==typeof r?(...e)=>{tA.push(t);try{return r(...e)}finally{R||(tA.pop(),tC&&1===tE&&0===tA.length&&(tE=0,es+=1,tI(r3),"u">typeof Fibers&&Fibers.sc()))}}:r;return e}(),i=e=>t=>e(t)>>>0,a=e=>()=>e()>>>0,(r=Object.assign({},r)).Ea=i(r.Ea),r.gb=a(r.gb),r.ib=i(r.ib),r.ub=i(r.ub),r.vb=a(r.vb),r.__cxa_get_exception_ptr=i(r.__cxa_get_exception_ptr),rM=r,ef.push(rM.jb),$=t,Q(),rM}K++;var i=Y();if(e.instantiateWasm)return new Promise(r=>{e.instantiateWasm(i,(e,i)=>{t(e,i),r(e.exports)})});if(s)return new Promise(e=>{V=r=>{e(t(new WebAssembly.Instance(r,Y()),r))}});j??=e.locateFile?e.locateFile?e.locateFile("ort-wasm-simd-threaded.jsep.wasm",f):f+"ort-wasm-simd-threaded.jsep.wasm":new URL("ort-wasm-simd-threaded.jsep.wasm",import.meta.url).href;try{var a=await async function(e){if(!O&&"function"==typeof WebAssembly.instantiateStreaming&&!B(j))try{var t=fetch(j,{credentials:"same-origin"});return await WebAssembly.instantiateStreaming(t,e)}catch(e){_(`wasm streaming compile failed: ${e}`),_("falling back to ArrayBuffer instantiation")}return async function(e,t){try{var r=await async function(e){if(!O)try{var t=await d(e);return new Uint8Array(t)}catch{}if(e==j&&O)e=new Uint8Array(O);else{if(!p)throw"both async and sync fetching of the wasm failed";e=p(e)}return e}(e);return await WebAssembly.instantiate(r,t)}catch(e){_(`failed to asynchronously prepare wasm: ${e}`),X(e)}}(j,e)}(i);return t(a.instance,a.module)}catch(e){return r(e),Promise.reject(e)}}();var rU=e=>(rU=rM.Ea)(e),rq=()=>(rq=rM.Fa)();e._OrtInit=(t,r)=>(e._OrtInit=rM.Ga)(t,r),e._OrtGetLastError=(t,r)=>(e._OrtGetLastError=rM.Ha)(t,r),e._OrtCreateSessionOptions=(t,r,i,a,n,s,o,u,l,d)=>(e._OrtCreateSessionOptions=rM.Ia)(t,r,i,a,n,s,o,u,l,d),e._OrtAppendExecutionProvider=(t,r,i,a,n)=>(e._OrtAppendExecutionProvider=rM.Ja)(t,r,i,a,n),e._OrtAddFreeDimensionOverride=(t,r,i)=>(e._OrtAddFreeDimensionOverride=rM.Ka)(t,r,i),e._OrtAddSessionConfigEntry=(t,r,i)=>(e._OrtAddSessionConfigEntry=rM.La)(t,r,i),e._OrtReleaseSessionOptions=t=>(e._OrtReleaseSessionOptions=rM.Ma)(t),e._OrtCreateSession=(t,r,i)=>(e._OrtCreateSession=rM.Na)(t,r,i),e._OrtReleaseSession=t=>(e._OrtReleaseSession=rM.Oa)(t),e._OrtGetInputOutputCount=(t,r,i)=>(e._OrtGetInputOutputCount=rM.Pa)(t,r,i),e._OrtGetInputOutputMetadata=(t,r,i,a)=>(e._OrtGetInputOutputMetadata=rM.Qa)(t,r,i,a),e._OrtFree=t=>(e._OrtFree=rM.Ra)(t),e._OrtCreateTensor=(t,r,i,a,n,s)=>(e._OrtCreateTensor=rM.Sa)(t,r,i,a,n,s),e._OrtGetTensorData=(t,r,i,a,n)=>(e._OrtGetTensorData=rM.Ta)(t,r,i,a,n),e._OrtReleaseTensor=t=>(e._OrtReleaseTensor=rM.Ua)(t),e._OrtCreateRunOptions=(t,r,i,a)=>(e._OrtCreateRunOptions=rM.Va)(t,r,i,a),e._OrtAddRunConfigEntry=(t,r,i)=>(e._OrtAddRunConfigEntry=rM.Wa)(t,r,i),e._OrtReleaseRunOptions=t=>(e._OrtReleaseRunOptions=rM.Xa)(t),e._OrtCreateBinding=t=>(e._OrtCreateBinding=rM.Ya)(t),e._OrtBindInput=(t,r,i)=>(e._OrtBindInput=rM.Za)(t,r,i),e._OrtBindOutput=(t,r,i,a)=>(e._OrtBindOutput=rM._a)(t,r,i,a),e._OrtClearBoundOutputs=t=>(e._OrtClearBoundOutputs=rM.$a)(t),e._OrtReleaseBinding=t=>(e._OrtReleaseBinding=rM.ab)(t),e._OrtRunWithBinding=(t,r,i,a,n)=>(e._OrtRunWithBinding=rM.bb)(t,r,i,a,n),e._OrtRun=(t,r,i,a,n,s,o,u)=>(e._OrtRun=rM.cb)(t,r,i,a,n,s,o,u),e._OrtEndProfiling=t=>(e._OrtEndProfiling=rM.db)(t),e._JsepOutput=(t,r,i)=>(e._JsepOutput=rM.eb)(t,r,i),e._JsepGetNodeName=t=>(e._JsepGetNodeName=rM.fb)(t);var rW=()=>(rW=rM.gb)(),rL=e._free=t=>(rL=e._free=rM.hb)(t),rV=e._malloc=t=>(rV=e._malloc=rM.ib)(t),rG=(e,t,r,i,a,n)=>(rG=rM.lb)(e,t,r,i,a,n),rH=()=>(rH=rM.mb)(),rF=(e,t,r,i,a)=>(rF=rM.nb)(e,t,r,i,a),rj=e=>(rj=rM.ob)(e),rK=e=>(rK=rM.pb)(e),rZ=(e,t)=>(rZ=rM.qb)(e,t),rQ=()=>(rQ=rM.rb)(),rX=(e,t)=>(rX=rM.sb)(e,t),rY=e=>(rY=rM.tb)(e),rJ=e=>(rJ=rM.ub)(e),r0=()=>(r0=rM.vb)(),r2=e.dynCall_ii=(t,r)=>(r2=e.dynCall_ii=rM.wb)(t,r),r1=e=>(r1=rM.xb)(e),r3=()=>(r3=rM.yb)(),r4=e=>(r4=rM.zb)(e),r6=()=>(r6=rM.Ab)();return e.stackSave=()=>r0(),e.stackRestore=e=>rY(e),e.stackAlloc=e=>rJ(e),e.setValue=function(e,t,r="i8"){switch(r.endsWith("*")&&(r="*"),r){case"i1":case"i8":N()[e>>>0]=t;break;case"i16":M()[e>>>1>>>0]=t;break;case"i32":U()[e>>>2>>>0]=t;break;case"i64":C[e>>>3]=BigInt(t);break;case"float":W()[e>>>2>>>0]=t;break;case"double":L()[e>>>3>>>0]=t;break;case"*":q()[e>>>2>>>0]=t;break;default:X(`invalid type for setValue: ${r}`)}},e.getValue=function(e,t="i8"){switch(t.endsWith("*")&&(t="*"),t){case"i1":case"i8":return N()[e>>>0];case"i16":return M()[e>>>1>>>0];case"i32":return U()[e>>>2>>>0];case"i64":return C[e>>>3];case"float":return W()[e>>>2>>>0];case"double":return L()[e>>>3>>>0];case"*":return q()[e>>>2>>>0];default:X(`invalid type for getValue: ${t}`)}},e.UTF8ToString=eE,e.stringToUTF8=eO,e.lengthBytesUTF8=eA,function r(){if(0<K)Z=r;else if(s)t(e),F();else{for(;0<ea.length;)ea.shift()(e);0<K?Z=r:(e.calledRun=!0,R||(F(),t(e)))}}(),e.PTR_SIZE=4,i},globalThis.self?.name?.startsWith("em-pthread")&&eh()}),nl=M(()=>{"use strict";es(),em=typeof location>"u"?void 0:location.origin,eg=import.meta.url>"file:"&&import.meta.url<"file;",ey=(()=>{if(eg){let e=URL;return new URL(new e("ort.bundle.min.mjs",import.meta.url).href,em).href}return import.meta.url})(),e_=()=>{if(ey&&!ey.startsWith("blob:"))return ey.substring(0,ey.lastIndexOf("/")+1)},eb=(e,t)=>{try{let r=t??ey;return(r?new URL(e,r):new URL(e)).origin===em}catch{return!1}},e$=async e=>{let t=await (await fetch(e,{credentials:"same-origin"})).blob();return URL.createObjectURL(t)},ev=async e=>(await import(e)).default,ew=(ed(),U(eo)).default,ex=async()=>{if(!ey)throw Error("Failed to load proxy worker: cannot determine the script source URL.");if(eb(ey))return[void 0,ew()];let e=await e$(ey);return[e,ew(e)]},ek=(nu(),U(ep)).default,eS=async(e,t,r)=>{if(!e&&!t&&ek&&ey&&eb(ey))return[void 0,ek];{let i,a,n="ort-wasm-simd-threaded.jsep.mjs",s=e??((e,t)=>{let r=t??ey;try{return(r?new URL(e,r):new URL(e)).href}catch{return}})(n,t),o=r&&s&&!eb(s,t),u=o?await e$(s):s??(i=n,a=t,`${a??"./"}${i}`);return[o?u:void 0,await ev(u)]}}}),nd=M(()=>{"use strict";nl(),eI=!1,eE=!1,eC=!1,ez=async e=>{if(eI)return Promise.resolve();if(eE)throw Error("multiple calls to 'initializeWebAssembly()' detected.");if(eC)throw Error("previous call to 'initializeWebAssembly()' failed.");eE=!0;let t=e.initTimeout,r=e.numThreads;if(!1!==e.simd){if("relaxed"===e.simd){if(!(()=>{try{return WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,5,1,96,0,1,123,3,2,1,0,10,19,1,17,0,65,1,253,15,65,2,253,15,65,3,253,15,253,147,2,11]))}catch{return!1}})())throw Error("Relaxed WebAssembly SIMD is not supported in the current environment.")}else if(!(()=>{try{return WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,3,2,1,0,10,30,1,28,0,65,0,253,15,253,12,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,253,186,1,26,11]))}catch{return!1}})())throw Error("WebAssembly SIMD is not supported in the current environment.")}let i=(()=>{if(typeof SharedArrayBuffer>"u")return!1;try{return"u">typeof MessageChannel&&new MessageChannel().port1.postMessage(new SharedArrayBuffer(1)),WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,4,1,96,0,0,3,2,1,0,5,4,1,3,1,1,10,11,1,9,0,65,0,254,16,2,0,26,11]))}catch{return!1}})();r>1&&!i&&("u">typeof self&&!self.crossOriginIsolated&&console.warn("env.wasm.numThreads is set to "+r+", but this will not work unless you enable crossOriginIsolated mode. See https://web.dev/cross-origin-isolation-guide/ for more info."),console.warn("WebAssembly multi-threading is not supported in the current environment. Falling back to single-threading."),e.numThreads=r=1);let a=e.wasmPaths,n="string"==typeof a?a:void 0,s=a?.mjs,o=s?.href??s,u=a?.wasm,l=u?.href??u,d=e.wasmBinary,[p,c]=await eS(o,n,r>1),h=!1,f=[];if(t>0&&f.push(new Promise(e=>{setTimeout(()=>{h=!0,e()},t)})),f.push(new Promise((e,t)=>{let i={numThreads:r};if(d)i.wasmBinary=d;else if(l||n)i.locateFile=e=>l??n+e;else if(o&&0!==o.indexOf("blob:"))i.locateFile=e=>new URL(e,o).href;else if(p){let e=e_();e&&(i.locateFile=t=>e+t)}c(i).then(t=>{eE=!1,eI=!0,eT=t,e(),p&&URL.revokeObjectURL(p)},e=>{eE=!1,eC=!0,t(e)})})),await Promise.race(f),h)throw Error(`WebAssembly backend initializing failed due to timeout: ${t}ms`)},eA=()=>{if(eI&&eT)return eT;throw Error("WebAssembly is not initialized yet.")}}),np=M(()=>{"use strict";nd(),eO=(e,t)=>{let r=eA(),i=r.lengthBytesUTF8(e)+1,a=r._malloc(i);return r.stringToUTF8(e,a,i),t.push(a),a},eR=(e,t,r,i)=>{if("object"==typeof e&&null!==e){if(r.has(e))throw Error("Circular reference in options");r.add(e)}Object.entries(e).forEach(([e,a])=>{let n=t?t+e:e;if("object"==typeof a)eR(a,n+".",r,i);else if("string"==typeof a||"number"==typeof a)i(n,a.toString());else if("boolean"==typeof a)i(n,a?"1":"0");else throw Error(`Can't handle extra config type: ${typeof a}`)})},eB=e=>{let t=eA(),r=t.stackSave();try{let r=t.PTR_SIZE,i=t.stackAlloc(2*r);t._OrtGetLastError(i,i+r);let a=Number(t.getValue(i,4===r?"i32":"i64")),n=t.getValue(i+r,"*"),s=n?t.UTF8ToString(n):"";throw Error(`${e} ERROR_CODE: ${a}, ERROR_MESSAGE: ${s}`)}finally{t.stackRestore(r)}}}),nc=M(()=>{"use strict";nd(),np(),eN=e=>{let t=eA(),r=0,i=[],a=e||{};try{if(e?.logSeverityLevel===void 0)a.logSeverityLevel=2;else if("number"!=typeof e.logSeverityLevel||!Number.isInteger(e.logSeverityLevel)||e.logSeverityLevel<0||e.logSeverityLevel>4)throw Error(`log serverity level is not valid: ${e.logSeverityLevel}`);if(e?.logVerbosityLevel===void 0)a.logVerbosityLevel=0;else if("number"!=typeof e.logVerbosityLevel||!Number.isInteger(e.logVerbosityLevel))throw Error(`log verbosity level is not valid: ${e.logVerbosityLevel}`);e?.terminate===void 0&&(a.terminate=!1);let n=0;return e?.tag!==void 0&&(n=eO(e.tag,i)),r=t._OrtCreateRunOptions(a.logSeverityLevel,a.logVerbosityLevel,!!a.terminate,n),0===r&&eB("Can't create run options."),e?.extra!==void 0&&eR(e.extra,"",new WeakSet,(e,a)=>{let n=eO(e,i),s=eO(a,i);0!==t._OrtAddRunConfigEntry(r,n,s)&&eB(`Can't set a run config entry: ${e} - ${a}.`)}),[r,i]}catch(e){throw 0!==r&&t._OrtReleaseRunOptions(r),i.forEach(e=>t._free(e)),e}}}),nh=M(()=>{"use strict";nd(),np(),eD=(e,t,r,i)=>{let a=eO(t,i),n=eO(r,i);0!==eA()._OrtAddSessionConfigEntry(e,a,n)&&eB(`Can't set a session config entry: ${t} - ${r}.`)},eM=async(e,t,r)=>{for(let i of t){let t="string"==typeof i?i:i.name,a=[];switch(t){case"webnn":if(t="WEBNN","string"!=typeof i){let t=i?.deviceType;t&&eD(e,"deviceType",t,r)}break;case"webgpu":if(t="JS","string"!=typeof i&&i?.preferredLayout){if("NCHW"!==i.preferredLayout&&"NHWC"!==i.preferredLayout)throw Error(`preferredLayout must be either 'NCHW' or 'NHWC': ${i.preferredLayout}`);eD(e,"preferredLayout",i.preferredLayout,r)}break;case"wasm":case"cpu":continue;default:throw Error(`not supported execution provider: ${t}`)}let n=eO(t,r),s=a.length,o=0,u=0;if(s>0){o=eA()._malloc(s*eA().PTR_SIZE),r.push(o),u=eA()._malloc(s*eA().PTR_SIZE),r.push(u);for(let e=0;e<s;e++)eA().setValue(o+e*eA().PTR_SIZE,a[e][0],"*"),eA().setValue(u+e*eA().PTR_SIZE,a[e][1],"*")}await eA()._OrtAppendExecutionProvider(e,n,o,u,s)!==0&&eB(`Can't append execution provider: ${t}.`)}},eP=async e=>{var t;let r,i=eA(),a=0,n=[],s=e||{};(t=s).extra||(t.extra={}),t.extra.session||(t.extra.session={}),(r=t.extra.session).use_ort_model_bytes_directly||(r.use_ort_model_bytes_directly="1"),t.executionProviders&&t.executionProviders.some(e=>("string"==typeof e?e:e.name)==="webgpu")&&(t.enableMemPattern=!1);try{let e=(e=>{switch(e){case"disabled":return 0;case"basic":return 1;case"extended":return 2;case"all":return 99;default:throw Error(`unsupported graph optimization level: ${e}`)}})(s.graphOptimizationLevel??"all"),t=(e=>{switch(e){case"sequential":return 0;case"parallel":return 1;default:throw Error(`unsupported execution mode: ${e}`)}})(s.executionMode??"sequential"),r="string"==typeof s.logId?eO(s.logId,n):0,o=s.logSeverityLevel??2;if(!Number.isInteger(o)||o<0||o>4)throw Error(`log serverity level is not valid: ${o}`);let u=s.logVerbosityLevel??0;if(!Number.isInteger(u)||u<0||u>4)throw Error(`log verbosity level is not valid: ${u}`);let l="string"==typeof s.optimizedModelFilePath?eO(s.optimizedModelFilePath,n):0;if(a=i._OrtCreateSessionOptions(e,!!s.enableCpuMemArena,!!s.enableMemPattern,t,!!s.enableProfiling,0,r,o,u,l),0===a&&eB("Can't create session options."),s.executionProviders&&await eM(a,s.executionProviders,n),void 0!==s.enableGraphCapture){if("boolean"!=typeof s.enableGraphCapture)throw Error(`enableGraphCapture must be a boolean value: ${s.enableGraphCapture}`);eD(a,"enableGraphCapture",s.enableGraphCapture.toString(),n)}if(s.freeDimensionOverrides)for(let[e,t]of Object.entries(s.freeDimensionOverrides)){if("string"!=typeof e)throw Error(`free dimension override name must be a string: ${e}`);if("number"!=typeof t||!Number.isInteger(t)||t<0)throw Error(`free dimension override value must be a non-negative integer: ${t}`);let r=eO(e,n);0!==i._OrtAddFreeDimensionOverride(a,r,t)&&eB(`Can't set a free dimension override: ${e} - ${t}.`)}return void 0!==s.extra&&eR(s.extra,"",new WeakSet,(e,t)=>{eD(a,e,t,n)}),[a,n]}catch(e){throw 0!==a&&0!==i._OrtReleaseSessionOptions(a)&&eB("Can't release session options."),n.forEach(e=>i._free(e)),e}}}),nf=M(()=>{"use strict";eU=e=>{switch(e){case"int8":return 3;case"uint8":return 2;case"bool":return 9;case"int16":return 5;case"uint16":return 4;case"int32":return 6;case"uint32":return 12;case"float16":return 10;case"float32":return 1;case"float64":return 11;case"string":return 8;case"int64":return 7;case"uint64":return 13;case"int4":return 22;case"uint4":return 21;default:throw Error(`unsupported data type: ${e}`)}},eq=e=>{switch(e){case 3:return"int8";case 2:return"uint8";case 9:return"bool";case 5:return"int16";case 4:return"uint16";case 6:return"int32";case 12:return"uint32";case 10:return"float16";case 1:return"float32";case 11:return"float64";case 8:return"string";case 7:return"int64";case 13:return"uint64";case 22:return"int4";case 21:return"uint4";default:throw Error(`unsupported data type: ${e}`)}},eW=(e,t)=>{let r=[-1,4,1,1,2,2,4,8,-1,1,2,8,4,8,-1,-1,-1,-1,-1,-1,-1,.5,.5][e],i="number"==typeof t?t:t.reduce((e,t)=>e*t,1);return r>0?Math.ceil(i*r):void 0},eL=e=>{switch(e){case"float16":return"u">typeof Float16Array&&Float16Array.from?Float16Array:Uint16Array;case"float32":return Float32Array;case"uint8":case"bool":return Uint8Array;case"int8":return Int8Array;case"uint16":return Uint16Array;case"int16":return Int16Array;case"int32":return Int32Array;case"float64":return Float64Array;case"uint32":return Uint32Array;case"int64":return BigInt64Array;case"uint64":return BigUint64Array;default:throw Error(`unsupported type: ${e}`)}},eV=e=>{switch(e){case"verbose":return 0;case"info":return 1;case"warning":return 2;case"error":return 3;case"fatal":return 4;default:throw Error(`unsupported logging level: ${e}`)}},eG=e=>"float32"===e||"float16"===e||"int32"===e||"int64"===e||"uint32"===e||"uint8"===e||"bool"===e||"uint4"===e||"int4"===e,eH=e=>"float32"===e||"float16"===e||"int32"===e||"int64"===e||"uint32"===e||"uint64"===e||"int8"===e||"uint8"===e||"bool"===e||"uint4"===e||"int4"===e,eF=e=>{switch(e){case"none":return 0;case"cpu":return 1;case"cpu-pinned":return 2;case"texture":return 3;case"gpu-buffer":return 4;case"ml-tensor":return 5;default:throw Error(`unsupported data location: ${e}`)}}}),nm=M(()=>{"use strict";es(),ej=async e=>{if("string"!=typeof e)return e instanceof Blob?new Uint8Array(await e.arrayBuffer()):e instanceof Uint8Array?e:new Uint8Array(e);{let t=await fetch(e);if(!t.ok)throw Error(`failed to load external data file: ${e}`);let r=t.headers.get("Content-Length"),i=r?parseInt(r,10):0;if(i<0x40000000)return new Uint8Array(await t.arrayBuffer());{if(!t.body)throw Error(`failed to load external data file: ${e}, no response body.`);let r=t.body.getReader(),a;try{a=new ArrayBuffer(i)}catch(e){if(e instanceof RangeError){let e=Math.ceil(i/65536);a=new WebAssembly.Memory({initial:e,maximum:e}).buffer}else throw e}let n=0;for(;;){let{done:e,value:t}=await r.read();if(e)break;let i=t.byteLength;new Uint8Array(a,n,i).set(t),n+=i}return new Uint8Array(a,0,i)}}}}),ng=M(()=>{"use strict";nf(),eK=["V","I","W","E","F"],eX=(e,t)=>{eZ=e,eQ=t},eY=(...e)=>{eQ&&((e,t)=>{var r,i;let a=eV(e);a>=eV(eZ)&&(r=a,i="function"==typeof t?t():t,console.log(`[${eK[r]},${new Date().toISOString()}]${i}`))})(...e)}}),ny=M(()=>{"use strict";eJ=class{static calcMatMulShape(e,t){return e[1]!==t[0]?void 0:[e[0],t[1]]}},e0=class{static calcShape(e,t,r=!1){let i=e.length,a=t.length;if(0===i)return t;if(0===a)return e;let n=Math.max(e.length,t.length),s=Array(n);if(r){if(i<2||a<2)return;let r=eJ.calcMatMulShape([e[i-2],e[i-1]],[t[a-2],t[a-1]]);if(void 0===r)return;[s[n-2],s[n-1]]=r}for(let o=r?3:1;o<=n;o++){let r=i-o<0?1:e[i-o],u=a-o<0?1:t[a-o];if(r!==u&&r>1&&u>1)return;let l=Math.max(r,u);if(r&&u)s[n-o]=Math.max(r,u);else{if(l>1)return;s[n-o]=0}}return s}static isValidBroadcast(e,t){let r=e.length,i=t.length;if(r>i)return!1;for(let a=1;a<=r;a++)if(1!==e[r-a]&&e[r-a]!==t[i-a])return!1;return!0}},e2=class e{static size(t){return e.getSizeFromDimensionRange(t,0,t.length)}static convertShape(e,t=4){let r=e.length;if(0===r)return[];let i=Array(r),a=r-1;for(;a>=0;){if(e[a]%t==0){i[a]=e[a]/t;break}if(t%e[a]!=0)throw Error("cannot convert shape");i[a]=1,t/=e[a],a--}for(a--;a>=0;a--)i[a]=e[a];return i}static sizeFromDimension(t,r){if(r<0||r>t.length)throw Error(`invalid dimension of ${r} for sizeFromDimension as Tensor has ${t.length} dimensions.`);return e.getSizeFromDimensionRange(t,r,t.length)}static sizeToDimension(t,r){if(r<0||r>t.length)throw Error(`invalid dimension of ${r} for sizeToDimension as Tensor has ${t.length} dimensions.`);return e.getSizeFromDimensionRange(t,0,r)}static getSizeFromDimensionRange(e,t,r){let i=1;for(let a=t;a<r;a++){if(e[a]<0)throw Error("cannot get valid size from specified dimension range. Most likely the range contains negative values in them.");i*=Number(e[a])}return i}static computeStrides(e){let t=e.length;if(0===t)return[];if(1===t)return[1];let r=Array(t);r[t-1]=1,r[t-2]=e[t-1];for(let i=t-3;i>=0;--i)r[i]=r[i+1]*e[i+1];return r}static normalizeAxis(e,t){if(e<-t&&e>=t)throw Error("unsupported axis for this operation.");return e<0?e+t:e}static normalizeAxes(e,t){return e.map(r=>this.normalizeAxis(r,t??e.length))}static sortBasedOnPerm(e,t){return t?t.map(t=>e[t]):e.slice().reverse()}static padShape(e,t){let r=e.length;return e.map((e,i)=>e+t[i]+t[i+r])}static areEqual(e,t){return e.length===t.length&&e.every((e,r)=>e===t[r])}},e1=class e{static adjustPoolAttributes(e,t,r,i,a,n){if(!e&&r.length!==t.length-2)throw Error("length of specified kernel shapes should be 2 less than length of input dimensions");if(e)for(let e=0;e<t.length-2;e++)e>=r.length?r.push(t[e+2]):r[e]=t[e+2];for(let e=0;e<r.length;e++)if(e<i.length){if(i[e]<0)throw Error("strides should be greater than or equal to 1")}else i.push(1);for(let e=0;e<r.length;e++)if(e<a.length){if(a[e]<0)throw Error("dilations should be greater than or equal to 1")}else a.push(1);for(let e=0;e<2*r.length;e++)if(e<n.length){if(n[e]<0)throw Error("pad should be greater than or equal to 1")}else n.push(0);for(let e=0;e<r.length;e++){if(r[e]<=0)throw Error("kernel shapes need to be greater than 0");if(n[e]>=r[e]||n[e+r.length]>=r[e])throw Error("pads should be smaller than kernel")}}static adjustPadsBasedOnAutoPad(t,r,i,a,n,s,o){if(o){if(n.length!==2*(t.length-2))throw Error("length of pads should be twice the length of data dimensions");if(r.length!==t.length-2)throw Error("length of strides should be the length of data dimensions");if(a.length!==t.length-2)throw Error("length of kernel shapes should be the length of data dimensions");for(let u=0;u<t.length-2;u++)e.adjustPadAndReturnShape(t[u+(s?1:2)],r[u],i[u],a[u],n,u,u+t.length-2,o)}}static computePoolOutputShape(t,r,i,a,n,s,o){if(r.length<=0)throw Error("input shape must be of size greater than 0");let u=[r[0],r[1]];return e.computeShapeHelper(t,r,u,i,a,n,s,o),u}static computeConvOutputShape(t,r,i,a,n,s,o){if(t.length<=0||r.length<=0)throw Error("invalid input tensor dims or invalid filter tensor dims");let u=[t[0],r[0]];return e.computeShapeHelper(!1,t,u,i,a,n,s,o),u}static computeShapeHelper(t,r,i,a,n,s,o,u){if(t)for(let e=0;e<r.length-2;e++)i.push(1);else for(let t=0;t<r.length-2;t++)i.push(e.adjustPadAndReturnShape(r[t+2],a[t],n[t],s[t],o,t,t+r.length-2,u))}static adjustPadAndReturnShape(e,t,r,i,a,n,s,o){let u=r*(i-1)+1;if(!o||"NOTSET"===o)return Math.floor((e+a[n]+a[s]-u)/t+1);switch(o){case"VALID":return a[n]=0,a[s]=0,Math.floor((e-u)/t+1);case"SAME_LOWER":case"SAME_UPPER":if(1!==r)throw Error("Dilation not supported for SAME_UPPER or SAME_LOWER");{let r=((e+t-1)/t-1)*t+i-e;return a[n]=Math.floor("SAME_LOWER"===o?(r+1)/2:r/2),a[s]=r-a[n],Math.floor((e+r-i)/t+1)}default:throw Error("Unsupported AutoPad type")}}},e3=class{static getShapeOfGemmResult(e,t,r,i,a){let n,s,o;if(2!==e.length||2!==r.length)throw Error("shape need to be of size 2");t?(n=e[1],s=e[0]):(n=e[0],s=e[1]);let u=-1;if(i?(o=r[0],u=1):(o=r[1],u=0),r[u]!==s)throw Error("dimension mismatch");if(n<=0||o<=0||s<=0)throw Error("invalid shape specified");if(a&&!e0.isValidBroadcast(a,[n,o]))throw Error("gemm: invalid bias shape for broadcast");return[n,o,s]}},e4=-34028234663852886e22,e6=34028234663852886e22}),n_=M(()=>{"use strict";nf(),e8=(e,t)=>new(eL(t))(e)}),nb=M(()=>{"use strict";nf(),ng(),e5=new Map([["float32",32],["float16",16],["int32",32],["uint32",32],["int64",64],["uint64",64],["int8",8],["uint8",8],["int4",4],["uint4",4]]),e7=(e,t)=>{if("int32"===t)return e;let r=e5.get(t);if(!r)throw Error(`WebNN backend does not support data type: ${t}`);let i=r/8;if(e.byteLength%i!=0)throw Error(`Invalid Uint8Array length - must be a multiple of ${i}.`);let a=e.byteLength/i,n=new(eL(t))(e.buffer,e.byteOffset,a);switch(t){case"int64":case"uint64":{let e=new Int32Array(a);for(let t=0;t<a;t++){let r=n[t];if(r>2147483647n||r<-2147483648n)throw Error("Can not convert int64 data to int32 - value out of range.");e[t]=Number(r)}return new Uint8Array(e.buffer)}case"int8":case"uint8":case"uint32":if("uint32"===t&&n.some(e=>e>0x7fffffff))throw Error("Can not convert uint32 data to int32 - value out of range.");return new Uint8Array(Int32Array.from(n,Number).buffer);default:throw Error(`Unsupported data conversion from ${t} to 'int32'`)}},e9=(e,t)=>{if("int32"===t)return e;if(e.byteLength%4!=0)throw Error("Invalid Uint8Array length - must be a multiple of 4 (int32).");let r=e.byteLength/4,i=new Int32Array(e.buffer,e.byteOffset,r);switch(t){case"int64":return new Uint8Array(BigInt64Array.from(i,BigInt).buffer);case"uint64":if(i.some(e=>e<0))throw Error("Can not convert int32 data to uin64 - negative value found.");return new Uint8Array(BigUint64Array.from(i,BigInt).buffer);case"int8":if(i.some(e=>e<-128||e>127))throw Error("Can not convert int32 data to int8 - value out of range.");return new Uint8Array(Int8Array.from(i,Number).buffer);case"uint8":if(i.some(e=>e<0||e>255))throw Error("Can not convert int32 data to uint8 - value out of range.");return Uint8Array.from(i,Number);case"uint32":if(i.some(e=>e<0))throw Error("Can not convert int32 data to uint32 - negative value found.");return new Uint8Array(Uint32Array.from(i,Number).buffer);default:throw Error(`Unsupported data conversion from 'int32' to ${t}`)}},te=1,tt=()=>te++,tr=new Map([["int8","int32"],["uint8","int32"],["uint32","int32"],["int64","int32"]]),ti=(e,t)=>{let r=e5.get(e);if(!r)throw Error(`WebNN backend does not support data type: ${e}`);return t.length>0?Math.ceil(t.reduce((e,t)=>e*t)*r/8):0},ta=class{constructor(e){this.isDataConverted=!1;let{sessionId:t,context:r,tensor:i,dataType:a,shape:n,fallbackDataType:s}=e;this.sessionId=t,this.mlContext=r,this.mlTensor=i,this.dataType=a,this.tensorShape=n,this.fallbackDataType=s}get tensor(){return this.mlTensor}get type(){return this.dataType}get fallbackType(){return this.fallbackDataType}get shape(){return this.tensorShape}get byteLength(){return ti(this.dataType,this.tensorShape)}destroy(){eY("verbose",()=>"[WebNN] TensorWrapper.destroy"),this.mlTensor.destroy()}write(e){this.mlContext.writeTensor(this.mlTensor,e)}async read(e){if(!this.fallbackDataType)return e?this.mlContext.readTensor(this.mlTensor,e):this.mlContext.readTensor(this.mlTensor);{let t=e9(new Uint8Array(await this.mlContext.readTensor(this.mlTensor)),this.dataType);return e?void(e instanceof ArrayBuffer?new Uint8Array(e):new Uint8Array(e.buffer,e.byteOffset,e.byteLength)).set(t):t.buffer}}canReuseTensor(e,t,r){return this.mlContext===e&&this.dataType===t&&this.tensorShape.length===r.length&&this.tensorShape.every((e,t)=>e===r[t])}setIsDataConverted(e){this.isDataConverted=e}},tn=class{constructor(e,t){this.tensorManager=e,this.wrapper=t}get tensorWrapper(){return this.wrapper}releaseTensor(){this.tensorWrapper&&(this.tensorManager.releaseTensor(this.tensorWrapper),this.wrapper=void 0)}async ensureTensor(e,t,r,i){let a=this.tensorManager.getMLContext(e),n;if(!a.opSupportLimits().input.dataTypes.includes(t)){if(!(n=tr.get(t))||!a.opSupportLimits().input.dataTypes.includes(n))throw Error(`WebNN backend does not support data type: ${t}`);eY("verbose",()=>`[WebNN] TensorIdTracker.ensureTensor: fallback dataType from ${t} to ${n}`)}if(this.wrapper){if(this.wrapper.canReuseTensor(a,t,r))return this.wrapper.tensor;if(i){if(this.wrapper.byteLength!==ti(t,r))throw Error("Unable to copy data to tensor with different size.");this.activeUpload=new Uint8Array(await this.wrapper.read())}this.tensorManager.releaseTensor(this.wrapper)}let s=typeof MLTensorUsage>"u"?void 0:MLTensorUsage.READ|MLTensorUsage.WRITE;return this.wrapper=await this.tensorManager.getCachedTensor(e,t,r,s,!0,!0,n),i&&this.activeUpload&&(this.wrapper.write(this.activeUpload),this.activeUpload=void 0),this.wrapper.tensor}upload(e){let t=e;if(this.wrapper){if(this.wrapper.fallbackType)if("int32"===this.wrapper.fallbackType)t=e7(e,this.wrapper.type),this.wrapper.setIsDataConverted(!0);else throw Error(`Unsupported fallback data type: ${this.wrapper.fallbackType}`);if(e.byteLength===this.wrapper.byteLength)return void this.wrapper.write(t);eY("verbose",()=>"Data size does not match tensor size. Releasing tensor."),this.releaseTensor()}this.activeUpload?this.activeUpload.set(t):this.activeUpload=new Uint8Array(t)}async download(e){if(this.activeUpload){let t=this.wrapper?.isDataConverted?e9(this.activeUpload,this.wrapper?.type):this.activeUpload;return e?void(e instanceof ArrayBuffer?new Uint8Array(e).set(t):new Uint8Array(e.buffer,e.byteOffset,e.byteLength).set(t)):t.buffer}if(!this.wrapper)throw Error("Tensor has not been created.");return e?this.wrapper.read(e):this.wrapper.read()}},ts=class{constructor(e){this.backend=e,this.tensorTrackersById=new Map,this.freeTensors=[],this.externalTensors=new Set}getMLContext(e){let t=this.backend.getMLContext(e);if(!t)throw Error("MLContext not found for session.");return t}reserveTensorId(){let e=tt();return this.tensorTrackersById.set(e,new tn(this)),e}releaseTensorId(e){let t=this.tensorTrackersById.get(e);t&&(this.tensorTrackersById.delete(e),t.tensorWrapper&&this.releaseTensor(t.tensorWrapper))}async ensureTensor(e,t,r,i,a){eY("verbose",()=>`[WebNN] TensorManager.ensureTensor {tensorId: ${t}, dataType: ${r}, shape: ${i}, copyOld: ${a}}`);let n=this.tensorTrackersById.get(t);if(!n)throw Error("Tensor not found.");return n.ensureTensor(e,r,i,a)}upload(e,t){let r=this.tensorTrackersById.get(e);if(!r)throw Error("Tensor not found.");r.upload(t)}async download(e,t){eY("verbose",()=>`[WebNN] TensorManager.download {tensorId: ${e}, dstBuffer: ${t?.byteLength}}`);let r=this.tensorTrackersById.get(e);if(!r)throw Error("Tensor not found.");return r.download(t)}releaseTensorsForSession(e){for(let t of this.freeTensors)t.sessionId===e&&t.destroy();this.freeTensors=this.freeTensors.filter(t=>t.sessionId!==e)}registerTensor(e,t,r,i){let a=this.getMLContext(e),n=tt(),s=new ta({sessionId:e,context:a,tensor:t,dataType:r,shape:i});return this.tensorTrackersById.set(n,new tn(this,s)),this.externalTensors.add(s),n}async getCachedTensor(e,t,r,i,a,n,s){let o=this.getMLContext(e);for(let[i,a]of this.freeTensors.entries())if(a.canReuseTensor(o,t,r)){eY("verbose",()=>`[WebNN] Reusing tensor {dataType: ${t}, ${s?`fallbackDataType: ${s},`:""} shape: ${r}`);let a=this.freeTensors.splice(i,1)[0];return a.sessionId=e,a}eY("verbose",()=>`[WebNN] MLContext.createTensor {dataType: ${t}, ${s?`fallbackDataType: ${s},`:""} shape: ${r}}`);let u=await o.createTensor({dataType:s??t,shape:r,dimensions:r,usage:i,writable:a,readable:n});return new ta({sessionId:e,context:o,tensor:u,dataType:t,shape:r,fallbackDataType:s})}releaseTensor(e){this.externalTensors.has(e)&&this.externalTensors.delete(e),this.freeTensors.push(e)}},to=(...e)=>new ts(...e)}),n$=M(()=>{"use strict";nf(),nd(),n_(),nb(),ng(),tu=new Map([[1,"float32"],[10,"float16"],[6,"int32"],[12,"uint32"],[7,"int64"],[13,"uint64"],[22,"int4"],[21,"uint4"],[3,"int8"],[2,"uint8"],[9,"uint8"]]),tl=class{constructor(e){this.tensorManager=to(this),this.mlContextBySessionId=new Map,this.sessionIdsByMLContext=new Map,this.mlContextCache=[],this.sessionGraphInputs=new Map,this.sessionGraphOutputs=new Map,this.temporaryGraphInputs=[],this.temporaryGraphOutputs=[],this.temporarySessionTensorIds=new Map,eX(e.logLevel,!!e.debug)}get currentSessionId(){if(void 0===this.activeSessionId)throw Error("No active session");return this.activeSessionId}onRunStart(e){eY("verbose",()=>`[WebNN] onRunStart {sessionId: ${e}}`),this.activeSessionId=e}onRunEnd(e){eY("verbose",()=>`[WebNN] onRunEnd {sessionId: ${e}}`);let t=this.temporarySessionTensorIds.get(e);if(t){for(let e of t)eY("verbose",()=>`[WebNN] releasing temporary tensor {tensorId: ${e}}`),this.tensorManager.releaseTensorId(e);this.temporarySessionTensorIds.delete(e),this.activeSessionId=void 0}}async createMLContext(e){if(e instanceof GPUDevice){let t=this.mlContextCache.findIndex(t=>t.gpuDevice===e);if(-1!==t)return this.mlContextCache[t].mlContext;{let t=await navigator.ml.createContext(e);return this.mlContextCache.push({gpuDevice:e,mlContext:t}),t}}if(void 0===e){let e=this.mlContextCache.findIndex(e=>void 0===e.options&&void 0===e.gpuDevice);if(-1!==e)return this.mlContextCache[e].mlContext;{let e=await navigator.ml.createContext();return this.mlContextCache.push({mlContext:e}),e}}let t=this.mlContextCache.findIndex(t=>((e,t)=>{if(e===t)return!0;if(void 0===e||void 0===t)return!1;let r=Object.keys(e).sort(),i=Object.keys(t).sort();return r.length===i.length&&r.every((r,a)=>r===i[a]&&e[r]===t[r])})(t.options,e));if(-1!==t)return this.mlContextCache[t].mlContext;{let t=await navigator.ml.createContext(e);return this.mlContextCache.push({options:e,mlContext:t}),t}}registerMLContext(e,t){this.mlContextBySessionId.set(e,t);let r=this.sessionIdsByMLContext.get(t);r||(r=new Set,this.sessionIdsByMLContext.set(t,r)),r.add(e),this.temporaryGraphInputs.length>0&&(this.sessionGraphInputs.set(e,this.temporaryGraphInputs),this.temporaryGraphInputs=[]),this.temporaryGraphOutputs.length>0&&(this.sessionGraphOutputs.set(e,this.temporaryGraphOutputs),this.temporaryGraphOutputs=[])}onReleaseSession(e){this.sessionGraphInputs.delete(e),this.sessionGraphOutputs.delete(e);let t=this.mlContextBySessionId.get(e);if(!t)return;this.tensorManager.releaseTensorsForSession(e),this.mlContextBySessionId.delete(e);let r=this.sessionIdsByMLContext.get(t);if(r.delete(e),0===r.size){this.sessionIdsByMLContext.delete(t);let e=this.mlContextCache.findIndex(e=>e.mlContext===t);-1!==e&&this.mlContextCache.splice(e,1)}}getMLContext(e){return this.mlContextBySessionId.get(e)}reserveTensorId(){return this.tensorManager.reserveTensorId()}releaseTensorId(e){eY("verbose",()=>`[WebNN] releaseTensorId {tensorId: ${e}}`),this.tensorManager.releaseTensorId(e)}async ensureTensor(e,t,r,i,a){let n=tu.get(r);if(!n)throw Error(`Unsupported ONNX data type: ${r}`);return this.tensorManager.ensureTensor(e??this.currentSessionId,t,n,i,a)}async createTemporaryTensor(e,t,r){eY("verbose",()=>`[WebNN] createTemporaryTensor {onnxDataType: ${t}, shape: ${r}}`);let i=tu.get(t);if(!i)throw Error(`Unsupported ONNX data type: ${t}`);let a=this.tensorManager.reserveTensorId();await this.tensorManager.ensureTensor(e,a,i,r,!1);let n=this.temporarySessionTensorIds.get(e);return n?n.push(a):this.temporarySessionTensorIds.set(e,[a]),a}uploadTensor(e,t){if(!eA().shouldTransferToMLTensor)throw Error("Trying to upload to a MLTensor while shouldTransferToMLTensor is false");eY("verbose",()=>`[WebNN] uploadTensor {tensorId: ${e}, data: ${t.byteLength}}`),this.tensorManager.upload(e,t)}async downloadTensor(e,t){return this.tensorManager.download(e,t)}createMLTensorDownloader(e,t){return async()=>{let r=await this.tensorManager.download(e);return e8(r,t)}}registerMLTensor(e,t,r,i){let a=tu.get(r);if(!a)throw Error(`Unsupported ONNX data type: ${r}`);let n=this.tensorManager.registerTensor(e,t,a,i);return eY("verbose",()=>`[WebNN] registerMLTensor {tensor: ${t}, dataType: ${a}, dimensions: ${i}} -> {tensorId: ${n}}`),n}registerMLConstant(e,t,r,i,a,n,s=!1){if(!n)throw Error("External mounted files are not available.");let o=e;e.startsWith("./")&&(o=e.substring(2));let u=n.get(o);if(!u)throw Error(`File with name ${o} not found in preloaded files.`);if(t+r>u.byteLength)throw Error("Out of bounds: data offset and length exceed the external file data size.");let l=u.slice(t,t+r).buffer,d;switch(a.dataType){case"float32":d=new Float32Array(l);break;case"float16":d="u">typeof Float16Array&&Float16Array.from?new Float16Array(l):new Uint16Array(l);break;case"int32":d=new Int32Array(l);break;case"uint32":d=new Uint32Array(l);break;case"int64":s?(d=new Int32Array(e7(new Uint8Array(l),"int64").buffer),a.dataType="int32"):d=new BigInt64Array(l);break;case"uint64":d=new BigUint64Array(l);break;case"int8":d=new Int8Array(l);break;case"int4":case"uint4":case"uint8":d=new Uint8Array(l);break;default:throw Error(`Unsupported data type: ${a.dataType} in creating WebNN Constant from external data.`)}return eY("verbose",()=>`[WebNN] registerMLConstant {dataType: ${a.dataType}, shape: ${a.shape}}} ${s?"(Note: it was int64 data type and registered to int32 as workaround)":""}`),i.constant(a,d)}registerGraphInput(e){this.temporaryGraphInputs.push(e)}registerGraphOutput(e){this.temporaryGraphOutputs.push(e)}isGraphInput(e,t){let r=this.sessionGraphInputs.get(e);return!!r&&r.includes(t)}isGraphOutput(e,t){let r=this.sessionGraphOutputs.get(e);return!!r&&r.includes(t)}isGraphInputOutputTypeSupported(e,t,r=!0){let i=this.mlContextBySessionId.get(e),a=tu.get(eU(t));return!(typeof a>"u")&&(r?!!i?.opSupportLimits().input.dataTypes.includes(a):!!i?.opSupportLimits().output.dataTypes.includes(a))}flush(){}}}),nv=M(()=>{}),nw=M(()=>{"use strict";ng(),nv(),td=new Map([[64,250],[128,200],[256,200],[512,200],[2048,230],[4096,200],[8192,50],[16384,50],[32768,50],[65536,50],[131072,50],[262144,50],[524288,50],[1048576,50],[2097152,30],[4194304,20],[8388608,10],[0xc00000,10],[0x1000000,10],[0x1900000,15],[0x2000000,22],[0x2a30000,2],[0x3840000,6],[0x4000000,6],[0x8000000,6],[0xa000000,6]]),tp=[],tc=e=>16*Math.ceil(Number(e)/16),th=1,tf=()=>th++,tm=async(e,t,r,i)=>{let a=tc(r),n=e.device.createBuffer({size:a,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});try{let s=e.getCommandEncoder();e.endComputePass(),s.copyBufferToBuffer(t,0,n,0,a),e.flush(),await n.mapAsync(GPUMapMode.READ);let o=n.getMappedRange();if(!i)return new Uint8Array(o.slice(0,r));{let e=i();return e.set(new Uint8Array(o,0,r)),e}}finally{n.destroy()}},tg=class{constructor(e){for(let[t]of(this.backend=e,this.storageCache=new Map,this.freeBuffers=new Map,this.freeUniformBuffers=new Map,this.buffersPending=[],this.capturedPendingBuffers=new Map,td))tp.push(t),this.freeBuffers.set(t,[]),this.freeUniformBuffers.set(t,[]);this.sessionCount=0}upload(e,t){let r=t.buffer,i=t.byteOffset,a=t.byteLength,n=tc(a),s=this.storageCache.get(e);if(!s)throw Error("gpu data for uploading does not exist");if(Number(s.originalSize)!==a)throw Error(`inconsistent data size. gpu data size=${s.originalSize}, data size=${a}`);let o=this.backend.device.createBuffer({mappedAtCreation:!0,size:n,usage:GPUBufferUsage.MAP_WRITE|GPUBufferUsage.COPY_SRC});new Uint8Array(o.getMappedRange()).set(new Uint8Array(r,i,a)),o.unmap();let u=this.backend.device.createCommandEncoder();u.copyBufferToBuffer(o,0,s.gpuData.buffer,0,n),this.backend.device.queue.submit([u.finish()]),o.destroy(),eY("verbose",()=>`[WebGPU] GpuDataManager.upload(id=${e})`)}memcpy(e,t){let r=this.storageCache.get(e);if(!r)throw Error("source gpu data for memcpy does not exist");let i=this.storageCache.get(t);if(!i)throw Error("destination gpu data for memcpy does not exist");if(r.originalSize!==i.originalSize)throw Error("inconsistent source and destination gpu data size");let a=tc(r.originalSize),n=this.backend.getCommandEncoder();this.backend.endComputePass(),n.copyBufferToBuffer(r.gpuData.buffer,0,i.gpuData.buffer,0,a)}registerExternalBuffer(e,t,r){let i;if(r){if(i=r[0],e===r[1])return eY("verbose",()=>`[WebGPU] GpuDataManager.registerExternalBuffer(size=${t}) => id=${i}, buffer is the same, skip.`),i;if(this.backend.capturedCommandList.has(this.backend.currentSessionId))throw Error(`Registering a different external buffer under graph capture mode is not supported yet.
             Please use the previous external buffer!`)}else i=tf();return this.storageCache.set(i,{gpuData:{id:i,type:0,buffer:e},originalSize:t}),eY("verbose",()=>`[WebGPU] GpuDataManager.registerExternalBuffer(size=${t}) => id=${i}, registered.`),i}unregisterExternalBuffer(e){void 0!==e&&(this.storageCache.delete(e),eY("verbose",()=>`[WebGPU] GpuDataManager.unregisterExternalBuffer() => id=${e}`))}create(e,t=GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC|GPUBufferUsage.COPY_DST){let r=(e=>{for(let t=0;t<tp.length;t++){let r=tp[t];if(e<=r)return r}return 16*Math.ceil(e/16)})(e),i,a=(t&GPUBufferUsage.STORAGE)===GPUBufferUsage.STORAGE,n=(t&GPUBufferUsage.UNIFORM)===GPUBufferUsage.UNIFORM;if(a||n){let e=(a?this.freeBuffers:this.freeUniformBuffers).get(r);i=e&&e.length>0?e.pop():this.backend.device.createBuffer({size:r,usage:t})}else i=this.backend.device.createBuffer({size:r,usage:t});let s={id:tf(),type:0,buffer:i};return this.storageCache.set(s.id,{gpuData:s,originalSize:Number(e)}),eY("verbose",()=>`[WebGPU] GpuDataManager.create(size=${e}) => id=${s.id}`),s}get(e){return this.storageCache.get(e)?.gpuData}release(e){let t="bigint"==typeof e?Number(e):e,r=this.storageCache.get(t);if(!r){if(0===this.storageCache.size)return 0;throw Error("releasing data does not exist")}return eY("verbose",()=>`[WebGPU] GpuDataManager.release(id=${t}), gpuDataId=${r.gpuData.id}`),this.storageCache.delete(t),this.buffersPending.push(r.gpuData.buffer),r.originalSize}async download(e,t){let r=this.storageCache.get(Number(e));if(!r)throw Error("data does not exist");await tm(this.backend,r.gpuData.buffer,r.originalSize,t)}refreshPendingBuffers(){if(0!==this.buffersPending.length)if("default"===this.backend.sessionStatus){for(let e of this.buffersPending){let t=td.get(e.size);if((e.usage&GPUBufferUsage.STORAGE)===GPUBufferUsage.STORAGE){let r=this.freeBuffers.get(e.size)||[];void 0===t||r.length>=t?e.destroy():r.push(e)}else if((e.usage&GPUBufferUsage.UNIFORM)===GPUBufferUsage.UNIFORM){let r=this.freeUniformBuffers.get(e.size)||[];void 0===t||r.length>=t?e.destroy():r.push(e)}else e.destroy()}this.buffersPending=[]}else{let e=this.capturedPendingBuffers.get(this.backend.currentSessionId);for(let t of(e||(e=[],this.capturedPendingBuffers.set(this.backend.currentSessionId,e)),this.buffersPending))e.push(t);this.buffersPending=[]}}dispose(){this.freeBuffers.forEach(e=>{e.forEach(e=>{e.destroy()})}),this.freeUniformBuffers.forEach(e=>{e.forEach(e=>{e.destroy()})}),this.storageCache.forEach(e=>{e.gpuData.buffer.destroy()}),this.capturedPendingBuffers.forEach(e=>{e.forEach(e=>{e.destroy()})}),this.storageCache=new Map,this.freeBuffers=new Map,this.freeUniformBuffers=new Map,this.capturedPendingBuffers=new Map}onCreateSession(){this.sessionCount+=1}onReleaseSession(e){let t=this.capturedPendingBuffers.get(e);t&&(t.forEach(e=>{e.destroy()}),this.capturedPendingBuffers.delete(e)),this.sessionCount-=1,0===this.sessionCount&&(eY("warning",()=>"[WebGPU] Clearing webgpu buffer cache"),this.storageCache.forEach(e=>{e.gpuData.buffer.destroy()}),this.storageCache=new Map)}},ty=(...e)=>new tg(...e)}),nx=M(()=>{"use strict";t_=class{constructor(e){Object.assign(this,e)}get cacheKey(){return this.key||(this.key=Object.getOwnPropertyNames(this).sort().map(e=>`${this[e]}`).join(";")),this.key}},tb=e=>new t_(e)}),nk=M(()=>{"use strict";nf(),ny(),t$=64,tv=(e,t)=>{if(3===t)throw Error("vec3 has same alignment as vec4, use vec4 instead");switch(Number(e)){case 10:return t>1?`vec${t}<f16>`:"f16";case 1:return t>1?`vec${t}<f32>`:"f32";case 6:return t>1?`vec${t}<i32>`:"i32";case 12:return t>1?`vec${t}<u32>`:"u32";case 7:if(t>1)throw Error("currently not supported vecX of uint64 yet");return["vec2<u32>","i32"];case 13:if(t>1)throw Error("currently not supported vecX of uint64 yet");return["vec2<u32>","u32"];case 9:if(4!==t)throw Error("bool must be vec4");return["u32","vec4<bool>"];case 22:return"i32";case 21:return"u32";default:throw Error(`Unknown data type: ${e}`)}},tw=(e,t=1)=>{let r=tv(e,t);return"string"==typeof r?r:r[0]},tx=(e,t=1)=>{let r=tv(e,t);return"string"==typeof r?r:r[1]},tk=(...e)=>{let t=[];return e.forEach(e=>{0!==e.length&&t.push({type:12,data:e},{type:12,data:e2.computeStrides(e)})}),t},tS=e=>e%4==0?4:e%2==0?2:1,tT=(e="f32",t,r="0")=>t&&1!==t?`vec${t}<${e}>(${r})`:`${e}(${r})`,tI=(e,t,r)=>"f32"===e?r:1===t?`f32(${r})`:`vec${t}<f32>(${r})`,tE=(e,t)=>4===t?`(${e}.x + ${e}.y + ${e}.z + ${e}.w)`:2===t?`(${e}.x + ${e}.y)`:3===t?`(${e}.x + ${e}.y + ${e}.z)`:e,tC=(e,t,r,i)=>e.startsWith("uniforms.")&&r>4?"string"==typeof t?"f16"===i?`${e}[(${t}) / 8][(${t}) % 8 / 4][(${t}) % 8 % 4]`:`${e}[(${t}) / 4][(${t}) % 4]`:"f16"===i?`${e}[${Math.floor(t/8)}][${Math.floor(t%8/4)}][${t%8%4}]`:`${e}[${Math.floor(t/4)}][${t%4}]`:r>1?`${e}[${t}]`:e,tz=(e,t,r,i,a)=>{let n,s,o,u,l="number"==typeof r,d=l?r:r.length,p=[...Array(d).keys()],c=d<2?"u32":d<=4?`vec${d}<u32>`:`array<u32, ${d}>`,h=tv(t,a),f="string"==typeof h?h:h[1],m={indices:c,value:f,storage:"string"==typeof h?h:h[0],tensor:t},g=e=>"string"==typeof e?e:`${e}u`,y={offsetToIndices:!1,indicesToOffset:!1,broadcastedIndicesToOffset:!1,set:!1,setByIndices:!1,get:!1,getByIndices:!1},_=l?"uniforms.":"",b=`${_}${e}_shape`,$=`${_}${e}_strides`,v="";for(let e=0;e<d-1;e++)v+=`
    let dim${e} = current / ${tC($,e,d)};
    let rest${e} = current % ${tC($,e,d)};
    indices[${e}] = dim${e};
    current = rest${e};
    `;v+=`indices[${d-1}] = current;`;let w=d<2?"":`
  fn o2i_${e}(offset: u32) -> ${m.indices} {
    var indices: ${m.indices};
    var current = offset;
    ${v}
    return indices;
  }`,x=[];if(d>=2)for(let e=d-1;e>=0;e--)x.push(`${tC($,e,d)} * (indices[${e}])`);let k=d<2?"":`
  fn i2o_${e}(indices: ${m.indices}) -> u32 {
    return ${x.join("+")};
  }`,S=(...e)=>0===d?"0u":`${m.indices}(${e.map(g).join(",")})`,T=(e,t)=>d<2?`${e}`:`${tC(e,t,d)}`,I={},E=(t,r)=>(()=>{if(m.storage===m.value)return`${e}[${t}]=${r};`;if("vec2<u32>"===m.storage&&"i32"===m.value)return`${e}[${t}]=vec2<u32>(u32(${r}), select(0u, 0xFFFFFFFFu, ${r} < 0));`;if("vec2<u32>"===m.storage&&"u32"===m.value)return`${e}[${t}]=vec2<u32>(u32(${r}), 0u);`;if("u32"===m.storage&&"vec4<bool>"===m.value)return`${e}[${t}]=dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(${r}));`;throw Error(`not supported combination of storage type ${m.storage} and value type ${m.value} yet`)})(),C=t=>(()=>{if(m.storage===m.value)return`${e}[${t}]`;if("vec2<u32>"===m.storage&&"i32"===m.value)return`i32(${e}[${t}].x)`;if("vec2<u32>"===m.storage&&"u32"===m.value)return`u32(${e}[${t}].x)`;if("u32"===m.storage&&"vec4<bool>"===m.value)return`vec4<bool>(bool(${e}[${t}] & 0xFFu), bool(${e}[${t}] & 0xFF00u), bool(${e}[${t}] & 0xFF0000u), bool(${e}[${t}] & 0xFF000000u))`;throw Error(`not supported combination of storage type ${m.storage} and value type ${m.value} yet`)})(),z=d<2?"":`
  fn get_${e}ByIndices(indices: ${m.indices}) -> ${f} {
    return ${C(`i2o_${e}(indices)`)};
  }`,A=d<2?"":(n=p.map(e=>`d${e}: u32`).join(", "),s=p.map(e=>`d${e}`).join(", "),`
  fn get_${e}(${n}) -> ${f} {
    return get_${e}ByIndices(${S(s)});
  }`),O=d<2?"":`
  fn set_${e}ByIndices(indices: ${m.indices}, value: ${f}) {
    ${E(`i2o_${e}(indices)`,"value")}
  }`,R=d<2?"":(o=p.map(e=>`d${e}: u32`).join(", "),u=p.map(e=>`d${e}`).join(", "),`
  fn set_${e}(${o}, value: ${f}) {
    set_${e}ByIndices(${S(u)}, value);
  }`);return{impl:()=>{let e=[],t=!1;return y.offsetToIndices&&(e.push(w),t=!0),y.indicesToOffset&&(e.push(k),t=!0),y.broadcastedIndicesToOffset&&(Object.values(I).forEach(t=>e.push(t)),t=!0),y.set&&(e.push(R),t=!0),y.setByIndices&&(e.push(O),t=!0),y.get&&(e.push(A),t=!0),y.getByIndices&&(e.push(z),t=!0),!l&&t&&e.unshift(`const ${b} = ${m.indices}(${r.join(",")});`,`const ${$} = ${m.indices}(${e2.computeStrides(r).join(",")});`),e.join(`
`)},type:m,offsetToIndices:t=>(y.offsetToIndices=!0,d<2?t:`o2i_${e}(${t})`),indicesToOffset:t=>(y.indicesToOffset=!0,d<2?t:`i2o_${e}(${t})`),broadcastedIndicesToOffset:(t,r)=>{y.broadcastedIndicesToOffset=!0;let i=`${r.name}broadcastedIndicesTo${e}Offset`;if(i in I)return`${i}(${t})`;let a=[];for(let e=d-1;e>=0;e--){let t=r.indicesGet("outputIndices",e+r.rank-d);a.push(`${T($,e)} * (${t} % ${T(b,e)})`)}return I[i]=`fn ${i}(outputIndices: ${r.type.indices}) -> u32 {
             return ${a.length>0?a.join("+"):"0u"};
           }`,`${i}(${t})`},indices:S,indicesGet:T,indicesSet:(e,t,r)=>d<2?`${e}=${r};`:`${tC(e,t,d)}=${r};`,set:(...t)=>{if(t.length!==d+1)throw Error(`indices length must be ${d}`);let r=t[d];if("string"!=typeof r)throw Error("value must be string");let i=t.slice(0,d).map(g).join(",");return 0===d?E("0u",r):1===d?E(i[0],r):(y.set=!0,y.setByIndices=!0,y.indicesToOffset=!0,`set_${e}(${i}, ${r})`)},setByOffset:E,setByIndices:(t,r)=>d<2?E(t,r):(y.setByIndices=!0,y.indicesToOffset=!0,`set_${e}ByIndices(${t}, ${r});`),get:(...t)=>{if(t.length!==d)throw Error(`indices length must be ${d}`);let r=t.map(g).join(",");return 0===d?C("0u"):1===d?C(r[0]):(y.get=!0,y.getByIndices=!0,y.indicesToOffset=!0,`get_${e}(${r})`)},getByOffset:C,getByIndices:t=>d<2?C(t):(y.getByIndices=!0,y.indicesToOffset=!0,`get_${e}ByIndices(${t})`),usage:i,name:e,strides:$,shape:b,rank:d}},tA=(e,t,r,i=1)=>tz(e,t,r,"input",i),tO=(e,t,r,i=1)=>tz(e,t,r,"output",i),tR=(e,t,r)=>tz(e,t,r,"atomicOutput",1),tB=(e,t,r,i=1)=>tz(e,t,r,"internal",i),tN=class{constructor(e,t){this.normalizedDispatchGroup=e,this.limits=t,this.internalVariables=[],this.variables=[],this.uniforms=[],this.variableIndex=0}guardAgainstOutOfBoundsWorkgroupSizes(e){return`if (global_idx >= ${"number"==typeof e?`${e}u`:e}) { return; }`}mainStart(e=t$){let t="number"==typeof e?e:e[0],r="number"==typeof e?1:e[1],i="number"==typeof e?1:e[2];if(t>this.limits.maxComputeWorkgroupSizeX||r>this.limits.maxComputeWorkgroupSizeY||i>this.limits.maxComputeWorkgroupSizeZ)throw Error(`workgroup size [${t}, ${r}, ${i}] exceeds the maximum workgroup size [${this.limits.maxComputeWorkgroupSizeX}, ${this.limits.maxComputeWorkgroupSizeY}, ${this.limits.maxComputeWorkgroupSizeZ}].`);if(t*r*i>this.limits.maxComputeInvocationsPerWorkgroup)throw Error(`workgroup size [${t}, ${r}, ${i}] exceeds the maximum workgroup invocations ${this.limits.maxComputeInvocationsPerWorkgroup}.`);let a=1===this.normalizedDispatchGroup[1]&&1===this.normalizedDispatchGroup[2],n=a?`@builtin(global_invocation_id) global_id : vec3<u32>,
    @builtin(workgroup_id) workgroup_id : vec3<u32>,
    @builtin(local_invocation_index) local_idx : u32,
    @builtin(local_invocation_id) local_id : vec3<u32>`:`@builtin(global_invocation_id) global_id : vec3<u32>,
                                             @builtin(local_invocation_id) local_id : vec3<u32>,
    @builtin(local_invocation_index) local_idx : u32,
    @builtin(workgroup_id) workgroup_id : vec3<u32>,
    @builtin(num_workgroups) num_workgroups : vec3<u32>`,s=a?`let global_idx = global_id.x;
         let workgroup_index = workgroup_id.x;`:`let workgroup_index = workgroup_id.z * num_workgroups[0] * num_workgroups[1] +
             workgroup_id.y * num_workgroups[0] + workgroup_id.x;
         let global_idx = workgroup_index * ${t*r*i}u + local_idx;`;return`@compute @workgroup_size(${t}, ${r}, ${i})
  fn main(${n}) {
    ${s}
  `}appendVariableUniforms(e){0!==e.rank&&(e.shape.startsWith("uniforms.")&&this.uniforms.push({name:e.shape.replace("uniforms.",""),type:"u32",length:e.rank}),e.strides.startsWith("uniforms.")&&this.uniforms.push({name:e.strides.replace("uniforms.",""),type:"u32",length:e.rank}))}declareVariable(e,t){if("internal"===e.usage)throw Error("cannot use internal variable with declareVariable(). use registerInternalVariables() instead.");this.variables.push(e),this.appendVariableUniforms(e);let r="input"===e.usage?"read":"read_write",i="atomicOutput"===e.usage?"atomic<i32>":e.type.storage;return`@group(0) @binding(${t}) var<storage, ${r}> ${e.name}: array<${i}>;`}declareVariables(...e){return e.map(e=>this.declareVariable(e,this.variableIndex++)).join(`
`)}registerInternalVariable(e){if("internal"!==e.usage)throw Error("cannot use input or output variable with registerInternalVariable(). use declareVariables() instead.");this.internalVariables.push(e),this.appendVariableUniforms(e)}registerInternalVariables(...e){return e.forEach(e=>this.registerInternalVariable(e)),this}registerUniform(e,t,r=1){return this.uniforms.push({name:e,type:t,length:r}),this}registerUniforms(e){return this.uniforms=this.uniforms.concat(e),this}uniformDeclaration(){if(0===this.uniforms.length)return"";let e=[];for(let{name:t,type:r,length:i}of this.uniforms)if(i&&i>4)"f16"===r?e.push(`@align(16) ${t}:array<mat2x4<${r}>, ${Math.ceil(i/8)}>`):e.push(`${t}:array<vec4<${r}>, ${Math.ceil(i/4)}>`);else{let a=null==i||1===i?r:`vec${i}<${r}>`;e.push(`${t}:${a}`)}return`
      struct Uniforms { ${e.join(", ")} };
      @group(0) @binding(${this.variableIndex}) var<uniform> uniforms: Uniforms;`}get additionalImplementations(){return this.uniformDeclaration()+this.variables.map(e=>e.impl()).join(`
`)+this.internalVariables.map(e=>e.impl()).join(`
`)}get variablesInfo(){if(0!==this.uniforms.length)return this.uniforms.map(e=>[[12,10,1,6][["u32","f16","f32","i32"].indexOf(e.type)],e.length??1])}},tD=(e,t)=>new tN(e,t)}),nS=M(()=>{"use strict";nf(),ny(),nx(),nk(),tM=(e,t)=>0!==t.length?t:[...Array(e).keys()].reverse(),tP=(e,t)=>{let r,i,a=e.dataType,n=e.dims.length,s=tM(n,t),o=(r=e.dims,i=s,e2.sortBasedOnPerm(r,tM(r.length,i))),u=e.dims,l=o;if(n<2||((e,t)=>{let r=0;for(let i=0;i<e.length;++i)if(1!==t[e[i]]){if(e[i]<r)return!1;r=e[i]}return!0})(s,e.dims))return{name:"TransposeCopy",shaderCache:{inputDependencies:["type"]},getRunData:()=>{let t=e2.size(o);return{outputs:[{dims:o,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(t/64/4)},programUniforms:[{type:12,data:Math.ceil(t/4)}]}},getShaderSource:e=>{let t=tA("input",a,u,4),r=tO("output",a,l,4);return`
  ${e.registerUniform("output_size","u32").declareVariables(t,r)}
  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    output[global_idx] = input[global_idx];
  }`}};let{newShape:d,newPerm:p}=((e,t)=>{let r=[],i=[];for(let a=0;a<e.length;++a)1!==e[a]&&r.push(e[a]),1!==e[t[a]]&&i.push(t[a]);return{newShape:r,newPerm:i}})(e.dims,s),c=e2.areEqual(p,[2,3,1]),h=e2.areEqual(p,[3,1,2]);return 2===d.length||c||h?(l=[(u=c?[d[0],d[1]*d[2]]:h?[d[0]*d[1],d[2]]:d)[1],u[0]],{name:"TransposeShared",shaderCache:{inputDependencies:["type"]},getRunData:()=>{let t=e2.size(o);return{outputs:[{dims:o,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(l[1]/16),y:Math.ceil(l[0]/16)},programUniforms:[{type:12,data:t},...tk(u,l)]}},getShaderSource:e=>{let t=tA("a",a,u.length),r=tO("output",a,l.length);return`
  ${e.registerUniform("output_size","u32").declareVariables(t,r)}
  var<workgroup> tile : array<array<${r.type.value}, 17>, 16>;
  ${e.mainStart([16,16,1])}
    let stride = (uniforms.output_shape[1] - 1) / 16 + 1;
    let workgroup_id_x = workgroup_index % stride;
    let workgroup_id_y = workgroup_index / stride;
    let input_col = workgroup_id_y * 16u + local_id.x;
    let input_row = workgroup_id_x * 16u + local_id.y;
    if (input_row < uniforms.a_shape[0] && input_col < uniforms.a_shape[1]) {
      tile[local_id.y][local_id.x] = ${t.getByIndices(`${t.type.indices}(input_row, input_col)`)};
    }
    workgroupBarrier();

    let output_col = workgroup_id_x * 16u + local_id.x;
    let output_row = workgroup_id_y * 16u + local_id.y;
    if (output_row < uniforms.output_shape[0] && output_col < uniforms.output_shape[1]) {
      ${r.setByIndices(`${r.type.indices}(output_row, output_col)`,"tile[local_id.x][local_id.y]")}
    }
  }`}}):{name:"Transpose",shaderCache:{hint:`${t}`,inputDependencies:["rank"]},getRunData:()=>{let t=e2.size(o);return{outputs:[{dims:o,dataType:e.dataType}],dispatchGroup:{x:Math.ceil(t/64)},programUniforms:[{type:12,data:t},...tk(u,l)]}},getShaderSource:e=>{let t=tA("a",a,u.length),r=tO("output",a,l.length);return`
  ${e.registerUniform("output_size","u32").declareVariables(t,r)}

  ${((e,t,r,i)=>{let a=`fn perm(i: ${i.type.indices}) -> ${r.type.indices} {
    var a: ${r.type.indices};`;for(let r=0;r<t;++r)a+=`a[${e[r]}]=i[${r}];`;return a+"return a;}"})(s,n,t,r)}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let indices = ${r.offsetToIndices("global_idx")};
    let aIndices = perm(indices);

    ${r.setByOffset("global_idx",t.getByIndices("aIndices"))}
  }`}}},tU=(e,t)=>{((e,t)=>{if(!e||1!==e.length)throw Error("Transpose requires 1 input.");if(0!==t.length&&t.length!==e[0].dims.length)throw Error(`perm size ${t.length} does not match input rank ${e[0].dims.length}`)})(e.inputs,t.perm),e.compute(tP(e.inputs[0],t.perm))},tq=e=>tb({perm:e.perm})}),nT=M(()=>{"use strict";nf(),ny(),nk(),nI(),nS(),tW={max:"select(bestValue, candidate, candidate > bestValue)",min:"select(bestValue, candidate, candidate < bestValue)",mean:"bestValue + candidate",sum:"bestValue + candidate",prod:"bestValue * candidate",sumSquare:"bestValue + candidate * candidate",logSumExp:"bestValue + exp(candidate)",l1:"bestValue + abs(candidate)",l2:"bestValue + candidate * candidate",logSum:"bestValue + candidate"},tL={max:"select(bestValue, candidate, candidate > bestValue)",min:"select(bestValue, candidate, candidate < bestValue)",mean:"bestValue + candidate",sum:"bestValue + candidate",prod:"bestValue * candidate",sumSquare:"bestValue + candidate",logSumExp:"bestValue + candidate",l1:"bestValue + candidate",l2:"bestValue + candidate",logSum:"bestValue + candidate"},tV={max:"_A[offset]",min:"_A[offset]",mean:"0",sum:"0",prod:"1",sumSquare:"0",logSumExp:"0",l1:"0",l2:"0",logSum:"0"},tG={max:"bestValue",min:"bestValue",sum:"bestValue",prod:"bestValue",sumSquare:"bestValue",logSumExp:"log(bestValue)",l1:"bestValue",l2:"sqrt(bestValue)",logSum:"log(bestValue)"},tH=(e,t,r,i)=>{var a,n,s,o,u,l,d;let p,c,h,f,m,g,y,_=1===e.inputs.length?r:t6(e.inputs,r),b=_.axes;0!==b.length||_.noopWithEmptyAxes||(b=e.inputs[0].dims.map((e,t)=>t));let $=e2.normalizeAxes(b,e.inputs[0].dims.length),v=$,w=e.inputs[0],x=((e,t)=>{let r=[];if(!((e,t)=>{for(let r=0;r<e.length;++r)if(e[e.length-r-1]!==t-1-r)return!1;return!0})(e,t)){for(let i=0;i<t;++i)-1===e.indexOf(i)&&r.push(i);e.forEach(e=>r.push(e))}return r})(v,e.inputs[0].dims.length);x.length>0&&(w=e.compute(tP(e.inputs[0],x),{inputs:[0],outputs:[-1]})[0],v=((e,t)=>{let r=[];for(let i=t-e;i<t;++i)r.push(i);return r})(v.length,w.dims.length));let[k,S]=((e,t)=>{let r=[],i=e.length;for(let a=0;a<i;a++)-1===t.indexOf(a)&&r.push(e[a]);return[r,t.map(t=>e[t])]})(w.dims,v),T=k;_.keepDims&&(T=((e,t)=>{let r=e.length+t.length,i=[],a=0;for(let n=0;n<r;n++)-1===t.indexOf(n)?i.push(e[a++]):i.push(1);return i})(k,$)),e.compute((a=t,n=_.cacheKey,s=[w],o=i,u=e.inputs[0].dataType,l=T,d=S,p=s[0].dims,c=e2.size(l),h=e2.size(d),f=tA("_A",s[0].dataType,p),m=tO("output",u,l),g=64,1===c&&(g=256),y=`
          var<workgroup> aBestValues : array<f32, ${g}>;
       `,{name:a,shaderCache:{hint:`${n};${g}`,inputDependencies:["type"]},getShaderSource:e=>`
        ${e.registerUniform("reduceSize","u32").declareVariables(f,m)}
        ${y}
        fn DIV_CEIL(a : u32, b : u32) -> u32 {
          return ((a - 1u) / b + 1u);
         }
         ${e.mainStart(g)}

          let outputIndex = global_idx / ${g};
          let offset = outputIndex * uniforms.reduceSize;

          var bestValue = f32(${tV[o]});
          let Length = uniforms.reduceSize;
          for (var k = local_idx; k < Length; k = k + ${g}) {
           let candidate = f32(${f.getByOffset("offset + k")});
           bestValue = ${tW[o]};
          }
          aBestValues[local_idx] = bestValue;
          workgroupBarrier();

         var reduceSize = min(Length, ${g}u);
         for (var currentSize = reduceSize / 2u; reduceSize > 1u;
             currentSize = reduceSize / 2u) {
           let interval = DIV_CEIL(reduceSize, 2u);
           if (local_idx < currentSize) {
            let candidate = aBestValues[local_idx + interval];
            bestValue = ${tL[o]};
            aBestValues[local_idx] = bestValue;
           }
           reduceSize = interval;
           workgroupBarrier();
         }

         if (local_idx == 0u) {
          ${m.setByOffset("outputIndex",`${"mean"===o?`${m.type.storage}(bestValue / f32(uniforms.reduceSize))`:`${m.type.storage}(${tG[o]})`}`)};
         }
        }`,getRunData:()=>({outputs:[{dims:l,dataType:u}],dispatchGroup:{x:c},programUniforms:[{type:12,data:h}]})}),{inputs:[w]})},tF=(e,t)=>{tH(e,"ReduceMeanShared",t,"mean")},tj=(e,t)=>{tH(e,"ReduceL1Shared",t,"l1")},tK=(e,t)=>{tH(e,"ReduceL2Shared",t,"l2")},tZ=(e,t)=>{tH(e,"ReduceLogSumExpShared",t,"logSumExp")},tQ=(e,t)=>{tH(e,"ReduceMaxShared",t,"max")},tX=(e,t)=>{tH(e,"ReduceMinShared",t,"min")},tY=(e,t)=>{tH(e,"ReduceProdShared",t,"prod")},tJ=(e,t)=>{tH(e,"ReduceSumShared",t,"sum")},t0=(e,t)=>{tH(e,"ReduceSumSquareShared",t,"sumSquare")},t2=(e,t)=>{tH(e,"ReduceLogSumShared",t,"logSum")}}),nI=M(()=>{"use strict";nf(),ny(),nx(),nk(),nT(),t1=e=>{if(!e||0===e.length||e.length>2)throw Error("Reduce op requires 1 or 2 inputs.");if(2===e.length&&1!==e[1].dims.length)throw Error("Invalid axes input dims.")},t3=e=>["","",`var value = ${e.getByIndices("input_indices")};`,""],t4=(e,t,r,i,a,n,s=!1,o=!1)=>{let u=[],l=r[0].dims,d=l.length,p=e2.normalizeAxes(a,d),c=!o&&0===p.length;l.forEach((e,t)=>{c||p.indexOf(t)>=0?s&&u.push(1):u.push(e)});let h=u.length,f=e2.size(u);return{name:e,shaderCache:t,getShaderSource:e=>{let t=[],a=tA("_A",r[0].dataType,d),o=tO("output",n,h),u=i(a,o,p),f=u[2];for(let e=0,r=0;e<d;e++)c||p.indexOf(e)>=0?(s&&r++,f=`for(var j${e}: u32 = 0; j${e} < ${l[e]}; j${e}++) {
                  ${u[2].includes("last_index")?`let last_index = j${e};`:""}
                  ${a.indicesSet("input_indices",e,`j${e}`)}
                  ${f}
                }`):(t.push(`${a.indicesSet("input_indices",e,o.indicesGet("output_indices",r))};`),r++);return`

        ${e.registerUniform("output_size","u32").declareVariables(a,o)}

        ${e.mainStart()}
          ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          var input_indices: ${a.type.indices};
          let output_indices = ${o.offsetToIndices("global_idx")};

          ${t.join(`
`)}
          ${u[0]}       // init ops for reduce max/min
          ${u[1]}
          ${f}
          ${u[3]}
          ${4===u.length?o.setByOffset("global_idx","value"):u.slice(4).join(`
`)}
        }`},getRunData:()=>({outputs:[{dims:u,dataType:n}],dispatchGroup:{x:Math.ceil(f/64)},programUniforms:[{type:12,data:f},...tk(l,u)]})}},t6=(e,t)=>{let r=[];return e[1].dims[0]>0&&e[1].getBigInt64Array().forEach(e=>r.push(Number(e))),tb({axes:r,keepDims:t.keepDims,noopWithEmptyAxes:t.noopWithEmptyAxes})},t8=(e,t,r,i)=>{let a=e.inputs,n=1===a.length?r:t6(a,r);e.compute(t4(t,{hint:n.cacheKey,inputDependencies:["rank"]},[a[0]],n.noopWithEmptyAxes&&0===n.axes.length?t3:i,n.axes,a[0].dataType,n.keepDims,n.noopWithEmptyAxes),{inputs:[0]})},t5=(e,t,r)=>{if(0===t.length)return r;let i=1,a=1;for(let r=0;r<t.length;r++)-1===t.indexOf(r)?i*=e[r]:a*=e[r];return a<32&&i>1024},t7=(e,t)=>{var r,i;t5(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?(r=e,i=t,t1(r.inputs),t8(r,"ReduceMean",i,(e,t,i)=>{let a=1;for(let t=0;t<e.rank;t++)(i.indexOf(t)>=0||0===i.length)&&(a*=r.inputs[0].dims[t]);return["var sum = f32(0);","",`sum += f32(${e.getByIndices("input_indices")});`,`let value = ${t.type.value}(sum / ${a});`]})):tF(e,t)},t9=(e,t)=>{var r,i;t5(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?(r=e,i=t,t1(r.inputs),t8(r,"ReduceL1",i,(e,t)=>[`var value = ${t.type.storage}(0);`,"",`value += abs(${e.getByIndices("input_indices")});`,""])):tj(e,t)},re=(e,t)=>{var r,i;t5(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?(r=e,i=t,t1(r.inputs),t8(r,"ReduceL2",i,(e,t)=>[`var t = ${t.type.value}(0); var value = ${t.type.value}(0);`,"",`t = ${e.getByIndices("input_indices")}; value += (t * t);`,"value = sqrt(value);"])):tK(e,t)},rt=(e,t)=>{var r,i;t5(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?(r=e,i=t,t1(r.inputs),t8(r,"ReduceLogSumExp",i,(e,t)=>[`var value = ${t.type.storage}(0);`,"",`value += exp(${e.getByIndices("input_indices")});`,"value = log(value);"])):tZ(e,t)},rr=(e,t)=>{var r,i;t5(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?(r=e,i=t,t1(r.inputs),t8(r,"ReduceMax",i,(e,t,r)=>{let i=[];for(let t=0;t<e.rank;t++)(r.indexOf(t)>=0||0===r.length)&&i.push(e.indicesSet("input_indices",t,0));return[`${i.join(`
`)}`,`var value = ${e.getByIndices("input_indices")};`,`value = max(value, ${e.getByIndices("input_indices")});`,""]})):tQ(e,t)},ri=(e,t)=>{var r,i;t5(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?(r=e,i=t,t1(r.inputs),t8(r,"ReduceMin",i,(e,t,r)=>{let i=[];for(let t=0;t<e.rank;t++)(r.indexOf(t)>=0||0===r.length)&&i.push(`input_indices[${t}] = 0;`);return[`${i.join(`
`)}`,`var value = ${e.getByIndices("input_indices")};`,`value = min(value, ${e.getByIndices("input_indices")});`,""]})):tX(e,t)},ra=(e,t)=>{var r,i;t5(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?(r=e,i=t,t1(r.inputs),t8(r,"ReduceProd",i,(e,t)=>[`var value = ${t.type.storage}(1);`,"",`value *= ${e.getByIndices("input_indices")};`,""])):tY(e,t)},rn=(e,t)=>{var r,i;t5(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?(r=e,i=t,t1(r.inputs),t8(r,"ReduceSum",i,(e,t)=>[`var value = ${t.type.storage}(0);`,"",`value += ${e.getByIndices("input_indices")};`,""])):tJ(e,t)},rs=(e,t)=>{var r,i;t5(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?(r=e,i=t,t1(r.inputs),t8(r,"ReduceSumSquare",i,(e,t)=>[`var t = ${t.type.value}(0); var value = ${t.type.value}(0);`,"",`t = ${e.getByIndices("input_indices")}; value += t * t;`,""])):t0(e,t)},ro=(e,t)=>{var r,i;t5(e.inputs[0].dims,t.axes,t.noopWithEmptyAxes)?(r=e,i=t,t1(r.inputs),t8(r,"ReduceLogSum",i,(e,t)=>[`var value = ${t.type.storage}(0);`,"",`value += ${e.getByIndices("input_indices")};`,"value = log(value);"])):t2(e,t)}}),nE=M(()=>{"use strict";nf(),nx(),nI(),ru=e=>{if(!e||0===e.length||e.length>2)throw Error("ArgMinMaxOp op requires 1 or 2 inputs.");if(1!==e[0].dataType)throw Error("Invalid input type.")},rl=(e,t)=>{ru(e.inputs),e.compute(t4("ArgMin",{hint:t.cacheKey,inputDependencies:["rank"]},[e.inputs[0]],(e,r,i)=>{let a=[];for(let t=0;t<e.rank;t++)(i.indexOf(t)>=0||0===i.length)&&a.push(`input_indices[${t}] = 0;`);return[`${a.join(`
`)}`,`var value = ${e.getByIndices("input_indices")};
var best_index : i32 = 0;`,`if (${e.getByIndices("input_indices")} ${t.selectLastIndex>0?"<=":"<"} value) {
         value = ${e.getByIndices("input_indices")};
         best_index = i32(last_index);
       }`,"",r.setByOffset("global_idx","best_index")]},[t.axis],7,t.keepDims),{inputs:[0]})},rd=(e,t)=>{ru(e.inputs),e.compute(t4("argMax",{hint:t.cacheKey,inputDependencies:["rank"]},[e.inputs[0]],(e,r,i)=>{let a=[];for(let t=0;t<e.rank;t++)(i.indexOf(t)>=0||0===i.length)&&a.push(`input_indices[${t}] = 0;`);return[`${a.join(`
`)}`,`var value = ${e.getByIndices("input_indices")};
var best_index : i32 = 0;`,`if (${e.getByIndices("input_indices")} ${t.selectLastIndex>0?">=":">"} value) {
         value = ${e.getByIndices("input_indices")};
         best_index = i32(last_index);
       }`,"",r.setByOffset("global_idx","best_index")]},[t.axis],7,t.keepDims),{inputs:[0]})},rp=e=>tb(e)}),nC=M(()=>{"use strict";nf(),ny(),nv(),nk(),rc=(e,t,r)=>t&&e?`
      let total_sequence_length_input = u32(${t.getByOffset("0")});
      let present_sequence_length = max(total_sequence_length_input, uniforms.past_sequence_length);
      let is_subsequent_prompt: bool = sequence_length > 1 && sequence_length != total_sequence_length_input;
      let is_first_prompt: bool = is_subsequent_prompt == false && sequence_length == total_sequence_length_input;
      total_sequence_length = u32(${e?.getByOffset("batchIdx")}) + 1;
      var past_sequence_length: u32 = 0;
      if (is_first_prompt == false) {
        past_sequence_length = total_sequence_length - sequence_length;
      }
       `:`
    ${r?"let past_sequence_length = uniforms.past_sequence_length":""};
    let present_sequence_length = total_sequence_length;
    `,rh=(e,t,r,i,a,n,s,o,u,l,d,p)=>{var c,h,f,m,g,y,_,b,$,v,w,x,k,S,T,I,E,C,z,A,O,R,B,N,D;let M,P,U,q,W,L,V,G,H,F,j,K,Z,Q,X,Y,J,ee,et,er,ei,ea,en,es,eo,eu,el,ed,ep,ec,eh,ef,em,eg=Math.min(e.outputCount,1+ +!!s+ +!!o),ey=eg>1?l.pastSequenceLength:0,e_=ey+l.kvSequenceLength,eb=u&&e2.size(u.dims)>0?u:void 0,e$=[t,r];eg>1&&s&&e2.size(s.dims)>0&&e$.push(s),eb&&e$.push(eb),d&&e$.push(d),p&&e$.push(p);let ev=e.compute((c=eg,h=t,f=r,m=s,g=eb,y=l,_=ey,b=d,$=p,M=_+y.kvSequenceLength,P=[y.batchSize,y.numHeads,y.sequenceLength,M],U=c>1&&m,q=y.kvNumHeads?y.kvNumHeads:y.numHeads,W=U?[y.batchSize,q,M,y.headSize]:void 0,L=y.nReps?y.nReps:1,V=0===y.scale?1/Math.sqrt(y.headSize):y.scale,G=tS(y.headSize),H=y.headSize/G,F={x:Math.ceil(M/12),y:Math.ceil(y.sequenceLength/12),z:y.batchSize*y.numHeads},j=[{type:12,data:y.sequenceLength},{type:12,data:H},{type:12,data:M},{type:12,data:y.numHeads},{type:12,data:y.headSize},{type:1,data:V},{type:12,data:_},{type:12,data:y.kvSequenceLength},{type:12,data:L}],K=U&&m&&e2.size(m.dims)>0,Z=["type","type"],K&&Z.push("type"),g&&Z.push("type"),b&&Z.push("type"),$&&Z.push("type"),Q=[{dims:P,dataType:h.dataType,gpuDataType:0}],U&&Q.push({dims:W,dataType:h.dataType,gpuDataType:0}),{name:"AttentionProbs",shaderCache:{hint:`${G};${void 0!==g};${void 0!==m};${c}`,inputDependencies:Z},getRunData:()=>({outputs:Q,dispatchGroup:F,programUniforms:j}),getShaderSource:e=>{let t=tA("q",h.dataType,h.dims,G),r=[t,tA("key",f.dataType,f.dims,G)];if(K){let e=tA("past_key",m.dataType,m.dims,G);r.push(e)}g&&r.push(tA("attention_bias",g.dataType,g.dims));let i=b?tA("seq_lens",b.dataType,b.dims):void 0;i&&r.push(i);let a=$?tA("total_sequence_length_input",$.dataType,$.dims):void 0;a&&r.push(a);let n=tO("output",h.dataType,P),s=[n];U&&s.push(tO("present_key",h.dataType,W,G));let o=tx(1,G);return`
  const TILE_SIZE = 12u;

  var<workgroup> tileQ: array<${t.type.storage}, 144>;
  var<workgroup> tileK: array<${t.type.storage}, 144>;
  ${e.registerUniforms([{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"alpha",type:"f32"},{name:"past_sequence_length",type:"u32"},{name:"kv_sequence_length",type:"u32"},{name:"n_reps",type:"u32"}]).declareVariables(...r,...s)}
  ${e.mainStart([12,12,1])}
    // x holds the N and y holds the M
    let headIdx = workgroup_id.z % uniforms.num_heads;
    let kvHeadIdx = ${1===L?"headIdx":"headIdx / uniforms.n_reps"};
    let kv_num_heads = ${1===L?"uniforms.num_heads":"uniforms.num_heads / uniforms.n_reps"};
    let batchIdx = workgroup_id.z / uniforms.num_heads;
    let m = workgroup_id.y * TILE_SIZE;
    let n = workgroup_id.x * TILE_SIZE;
    let sequence_length = uniforms.M;
    var total_sequence_length = uniforms.N;
    ${rc(i,a,!0)}
    let absKvHeadIdx = batchIdx * kv_num_heads + kvHeadIdx;
    let qOffset = workgroup_id.z * uniforms.M * uniforms.K + m * uniforms.K;
    ${K&&U?"let pastKeyOffset = absKvHeadIdx * uniforms.past_sequence_length * uniforms.K;":""};
    let kOffset = absKvHeadIdx * uniforms.kv_sequence_length * uniforms.K;
    ${U?"let presentKeyOffset = absKvHeadIdx * uniforms.N * uniforms.K;":""}
    var value = ${o}(0);
    for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (global_id.y < uniforms.M && w + local_id.x < uniforms.K) {
        tileQ[TILE_SIZE * local_id.y + local_id.x] = q[qOffset + local_id.y * uniforms.K + w + local_id.x];
      }
      if (n + local_id.y < uniforms.N && w + local_id.x < uniforms.K) {
        var idx = TILE_SIZE * local_id.y + local_id.x;
      ${K&&U?`
              if (n + local_id.y < past_sequence_length) {
                tileK[idx] = past_key[pastKeyOffset + (n + local_id.y) * uniforms.K + w + local_id.x];
              } else if (n + local_id.y - past_sequence_length < uniforms.kv_sequence_length) {
                tileK[idx] = key[kOffset + (n + local_id.y - past_sequence_length) * uniforms.K + w + local_id.x];
              }`:`
          if (n + local_id.y < uniforms.kv_sequence_length) {
            tileK[idx] = key[kOffset + (n + local_id.y) * uniforms.K + w + local_id.x];
          }`}
      ${U?`if (n + local_id.y < present_sequence_length) {
        present_key[presentKeyOffset + (n + local_id.y) * uniforms.K + w + local_id.x] = tileK[idx];
      }`:""}
      }
      workgroupBarrier();

      for (var k: u32 = 0u; k < TILE_SIZE && w+k < uniforms.K; k++) {
          value += ${o}(tileQ[TILE_SIZE * local_id.y + k] * tileK[TILE_SIZE * local_id.x + k]);
      }

      workgroupBarrier();
    }

    if (global_id.y < uniforms.M && global_id.x < total_sequence_length) {
      let headOffset = workgroup_id.z * uniforms.M * uniforms.N;
      let outputIdx = headOffset + global_id.y * uniforms.N + global_id.x;
      var sum: f32 = ${(()=>{switch(G){case 1:return"value";case 2:return"value.x + value.y";case 4:return"value.x + value.y + value.z + value.w";default:throw Error(`Unsupported components: ${G}`)}})()};
        output[outputIdx] = ${n.type.value} (sum * uniforms.alpha) + ${g?"attention_bias[outputIdx]":"0.0"};
    }
  }`}}),{inputs:e$,outputs:eg>1?[-1,1]:[-1]})[0];e.compute((v=ev,w=l.batchSize,x=l.numHeads,k=ey,S=l.sequenceLength,T=e_,I=d,E=p,X=tS(I?1:T),Y=64,(J=T/X)<64&&(Y=32),ee=[{type:12,data:w},{type:12,data:x},{type:12,data:k},{type:12,data:S},{type:12,data:J},{type:12,data:Math.ceil(T/X/Y)}],et=tw(v.dataType,X),er=tx(1,X),ei=["type"],I&&ei.push("type"),E&&ei.push("type"),{name:"AttentionProbsSoftmax",shaderCache:{hint:`${Y};${et};${X}`,inputDependencies:ei},getShaderSource:e=>{let t=tO("x",v.dataType,v.dims,X),r=[t],i=I?tA("seq_lens",I.dataType,I.dims):void 0;i&&r.push(i);let a=E?tA("total_sequence_length_input",E.dataType,E.dims):void 0;a&&r.push(a);let n=tx(v.dataType);return`
  var<workgroup> thread_max: array<f32, ${Y}>;
  var<workgroup> thread_sum: array<f32, ${Y}>;
  ${e.registerUniforms([{name:"batch_size",type:"u32"},{name:"num_heads",type:"u32"},{name:"past_sequence_length",type:"u32"},{name:"sequence_length",type:"u32"},{name:"total_sequence_length",type:"u32"},{name:"elements_per_thread",type:"u32"}]).declareVariables(...r)}
  ${e.mainStart([Y,1,1])}
    let batchIdx = workgroup_id.z / uniforms.num_heads;
    let headIdx = workgroup_id.z % uniforms.num_heads;
    let sequence_length = uniforms.sequence_length;
    var total_sequence_length = uniforms.total_sequence_length;
    ${rc(i,a,!1)}
    let local_offset = local_idx * uniforms.elements_per_thread;
    let offset = (global_idx / ${Y}) * uniforms.total_sequence_length + local_offset;
    let seq_causal_length = ${I?"u32(past_sequence_length + workgroup_id.y + 1)":"total_sequence_length"};
    var thread_max_vector = ${er}(-3.402823e+38f);
    for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
      thread_max_vector = max(${er}(x[offset + i]), thread_max_vector);
    }
    thread_max[local_idx] = ${(()=>{switch(X){case 1:return"thread_max_vector";case 2:return"max(thread_max_vector.x, thread_max_vector.y)";case 4:return"max(max(thread_max_vector.x, thread_max_vector.y), max(thread_max_vector.z, thread_max_vector.w))";default:throw Error(`Unsupported components: ${X}`)}})()};
    workgroupBarrier();

    var max_value =  f32(-3.402823e+38f);
    for (var i = 0u; i < ${Y}; i++) {
      max_value = max(thread_max[i], max_value);
    }

    var sum_vector = ${er}(0);
    for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
      sum_vector += exp(${er}(x[offset + i]) - max_value);
    }
    thread_sum[local_idx] = ${(()=>{switch(X){case 1:return"sum_vector";case 2:return"sum_vector.x + sum_vector.y";case 4:return"sum_vector.x + sum_vector.y + sum_vector.z + sum_vector.w";default:throw Error(`Unsupported components: ${X}`)}})()};
    workgroupBarrier();

    var sum: f32 = 0;
    for (var i = 0u; i < ${Y}; i++) {
      sum += thread_sum[i];
    }

    if (sum == 0) {
      for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
        x[offset + i] = ${t.type.value}(${n}(1.0) / ${n}(seq_causal_length));
      }
    } else {
      for (var i: u32 = 0; i < uniforms.elements_per_thread && i + local_offset < seq_causal_length; i++) {
        var f32input = ${er}(x[offset + i]);
        x[offset + i] = ${t.type.value}(exp(f32input - max_value) / sum);
      }
    }
      ${I?`
        for (var total_seq_id: u32 = seq_causal_length; total_seq_id + local_offset < uniforms.total_sequence_length; total_seq_id++) {
          x[offset + total_seq_id] = ${t.type.value}(${n}(0));
        }`:""};
  }`},getRunData:()=>({outputs:[],dispatchGroup:{x:1,y:S,z:w*x},programUniforms:ee})}),{inputs:d&&p?[ev,d,p]:[ev],outputs:[]});let ew=[ev,i];eg>1&&o&&e2.size(o.dims)>0&&ew.push(o),d&&ew.push(d),p&&ew.push(p),e.compute((C=eg,z=ev,A=i,O=o,R=l,B=ey,N=d,D=p,ea=B+R.kvSequenceLength,en=R.nReps?R.nReps:1,es=R.vHiddenSize*en,eo=C>1&&O,eu=R.kvNumHeads?R.kvNumHeads:R.numHeads,el=eo?[R.batchSize,eu,ea,R.headSize]:void 0,ed=[R.batchSize,R.sequenceLength,es],ep={x:Math.ceil(R.vHeadSize/12),y:Math.ceil(R.sequenceLength/12),z:R.batchSize*R.numHeads},ec=[{type:12,data:R.sequenceLength},{type:12,data:ea},{type:12,data:R.vHeadSize},{type:12,data:R.numHeads},{type:12,data:R.headSize},{type:12,data:es},{type:12,data:B},{type:12,data:R.kvSequenceLength},{type:12,data:en}],eh=eo&&O&&e2.size(O.dims)>0,ef=["type","type"],eh&&ef.push("type"),N&&ef.push("type"),D&&ef.push("type"),em=[{dims:ed,dataType:z.dataType,gpuDataType:0}],eo&&em.push({dims:el,dataType:z.dataType,gpuDataType:0}),{name:"AttentionScore",shaderCache:{hint:`${void 0!==O};${C}`,inputDependencies:ef},getRunData:()=>({outputs:em,dispatchGroup:ep,programUniforms:ec}),getShaderSource:e=>{let t=tA("probs",z.dataType,z.dims),r=[t,tA("v",A.dataType,A.dims)];eh&&r.push(tA("past_value",O.dataType,O.dims));let i=N?tA("seq_lens",N.dataType,N.dims):void 0;N&&r.push(i);let a=D?tA("total_sequence_length_input",D.dataType,D.dims):void 0;D&&r.push(a);let n=[tO("output",z.dataType,ed)];return eo&&n.push(tO("present_value",z.dataType,el)),`
  const TILE_SIZE = 12u;
  var<workgroup> tileQ: array<${t.type.value}, 144>;
  var<workgroup> tileV: array<${t.type.value}, 144>;
  ${e.registerUniforms([{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"v_hidden_size",type:"u32"},{name:"past_sequence_length",type:"u32"},{name:"kv_sequence_length",type:"u32"},{name:"n_reps",type:"u32"}]).declareVariables(...r,...n)}
  ${e.mainStart([12,12,1])}
   let headIdx = workgroup_id.z % uniforms.num_heads;
   let batchIdx = workgroup_id.z / uniforms.num_heads;
   let kvHeadIdx = ${1===en?"headIdx":"headIdx / uniforms.n_reps"};
   let kv_num_heads = ${1===en?"uniforms.num_heads":"uniforms.num_heads / uniforms.n_reps"};
   let m = global_id.y;
   let n = global_id.x;
   let sequence_length = uniforms.M;
   var total_sequence_length = uniforms.K;
   ${rc(i,a,!0)}
   let offsetA = workgroup_id.z * uniforms.M * uniforms.K + m * uniforms.K;
   let absKvHeadIdx = batchIdx * kv_num_heads + kvHeadIdx; // kvHeadIdx is relative to the batch
   ${eh&&eo?"let pastValueOffset = absKvHeadIdx * uniforms.N * uniforms.past_sequence_length + n;":""};
   let vOffset = absKvHeadIdx * uniforms.N * uniforms.kv_sequence_length + n;
   ${eo?"let presentValueOffset = absKvHeadIdx * uniforms.N * uniforms.K + n;":""}
   var value = ${t.type.storage}(0);
   for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (m < uniforms.M && w + local_id.x < uniforms.K) {
        tileQ[TILE_SIZE * local_id.y + local_id.x] = probs[offsetA + w + local_id.x];
      }
      if (n < uniforms.N && w + local_id.y < uniforms.K) {
        var idx = TILE_SIZE * local_id.y + local_id.x;
        ${eh&&eo?`
        if (w + local_id.y < past_sequence_length) {
          tileV[idx] = past_value[pastValueOffset + (w + local_id.y) * uniforms.N];
        } else if (w + local_id.y - past_sequence_length < uniforms.kv_sequence_length) {
          tileV[idx] = v[vOffset + (w + local_id.y - past_sequence_length) * uniforms.N];
        }
      `:`
            if (w + local_id.y < uniforms.kv_sequence_length) {
              tileV[idx] = v[vOffset + (w + local_id.y) * uniforms.N];
            }`}
        ${eo?`
            if (w + local_id.y < present_sequence_length) {
          present_value[presentValueOffset + (w + local_id.y) * uniforms.N] = tileV[idx];
        }`:""}
      }
     workgroupBarrier();
     for (var k: u32 = 0u; k < TILE_SIZE && w+k < total_sequence_length; k++) {
       value += tileQ[TILE_SIZE * local_id.y + k] * tileV[TILE_SIZE * k + local_id.x];
     }
     workgroupBarrier();
   }

   // we need to transpose output from BNSH_v to BSND_v
   if (m < uniforms.M && n < uniforms.N) {
     let outputIdx = batchIdx * uniforms.M * uniforms.v_hidden_size + m * uniforms.v_hidden_size
       + headIdx * uniforms.N + n;
     output[outputIdx] = value;
   }
  }`}}),{inputs:ew,outputs:eg>1?[0,2]:[0]})},rf=(e,t)=>{var r,i;let a,n,s,o,u,l,d,p=((e,t)=>{let r=e[0],i=e[1],a=e[2],n=e[3],s=e[4],o=e[5];if(s&&o)throw Error("Attention cannot have both past and attention_bias");if(3!==r.dims.length)throw Error('Input "input" must have 3 dimensions');let u=r.dims[0],l=r.dims[1],d=r.dims[2];if(1!==a.dims.length)throw Error('Input "bias" is expected to have 1 dimensions');if(2!==i.dims.length)throw Error('Input "weights" is expected to have 2 dimensions');if(i.dims[0]!==d)throw Error("Input 1 dimension 0 should have same length as dimension 2 of input 0");if(a.dims[0]!==i.dims[1])throw Error('Input "bias" dimension 0 should have same length as dimension 1 of input "weights"');let p=a.dims[0]/3,c=p,h=c;if(t.qkvHiddenSizes.length>0){if(3!==t.qkvHiddenSizes.length)throw Error("qkv_hidden_sizes attribute should have 3 elements");for(let e of t.qkvHiddenSizes)if(e%t.numHeads!=0)throw Error("qkv_hidden_sizes should be divisible by num_heads");p=t.qkvHiddenSizes[0],c=t.qkvHiddenSizes[1],h=t.qkvHiddenSizes[2]}if(p!==c)throw Error("qkv_hidden_sizes first element should be same as the second");if(a.dims[0]!==p+c+h)throw Error('Input "bias" dimension 0 should have same length as sum of Q/K/V hidden sizes');let f=0;if(s){if(c!==h)throw Error('Input "past" expect k_hidden_size == v_hidden_size');if(5!==s.dims.length)throw Error('Input "past" must have 5 dimensions');if(2!==s.dims[0])throw Error('Input "past" first dimension must be 2');if(s.dims[1]!==u)throw Error('Input "past" second dimension must be batch_size');if(s.dims[2]!==t.numHeads)throw Error('Input "past" third dimension must be num_heads');if(s.dims[4]!==c/t.numHeads)throw Error('Input "past" fifth dimension must be k_hidden_size / num_heads');t.pastPresentShareBuffer||(f=s.dims[3])}let m=l+f;if(n)throw Error("Mask not supported");if(s)throw Error("past is not supported");if(o){if(4!==o.dims.length)throw Error('Input "attention_bias" must have 4 dimensions');if(o.dims[0]!==u||o.dims[1]!==t.numHeads||o.dims[2]!==l||o.dims[3]!==m)throw Error('Expect "attention_bias" shape (batch_size, num_heads, sequence_length, total_sequence_length)')}return{batchSize:u,sequenceLength:l,pastSequenceLength:f,kvSequenceLength:l,totalSequenceLength:m,maxSequenceLength:-1,inputHiddenSize:d,hiddenSize:p,vHiddenSize:h,headSize:Math.floor(p/t.numHeads),vHeadSize:Math.floor(h/t.numHeads),numHeads:t.numHeads,isUnidirectional:!1,pastPresentShareBuffer:!1,maskFilterValue:t.maskFilterValue,maskType:0,scale:t.scale,broadcastResPosBias:!1,passPastInKv:!1,qkvFormat:1}})(e.inputs,t),[c,h,f]=(r=e,a=[(i=p).batchSize,i.numHeads,i.sequenceLength,i.headSize],n=i.sequenceLength,s=i.inputHiddenSize,o=i.headSize,u={x:Math.ceil(i.headSize/12),y:Math.ceil(i.sequenceLength/12),z:i.batchSize*i.numHeads},l=[r.inputs[0],r.inputs[1],r.inputs[2]],d=[{type:12,data:n},{type:12,data:s},{type:12,data:o},{type:12,data:i.numHeads},{type:12,data:i.headSize},{type:12,data:i.hiddenSize},{type:12,data:i.hiddenSize+i.hiddenSize+i.vHiddenSize}],r.compute({name:"AttentionPrepare",shaderCache:{inputDependencies:["type","type","type"]},getRunData:()=>({outputs:[{dims:a,dataType:r.inputs[0].dataType,gpuDataType:0},{dims:a,dataType:r.inputs[0].dataType,gpuDataType:0},{dims:a,dataType:r.inputs[0].dataType,gpuDataType:0}],dispatchGroup:u,programUniforms:d}),getShaderSource:e=>{let t=tO("output_q",l[0].dataType,a),r=tO("output_k",l[0].dataType,a),i=tO("output_v",l[0].dataType,a),n=tA("input",l[0].dataType,l[0].dims),s=tA("weight",l[1].dataType,l[1].dims),o=tA("bias",l[2].dataType,l[2].dims),u=n.type.storage;return`
  const TILE_SIZE = 12u;
  var<workgroup> tileInput: array<${u}, 144>;
  var<workgroup> tileWeightQ: array<${u}, 144>;
  var<workgroup> tileWeightK: array<${u}, 144>;
  var<workgroup> tileWeightV: array<${u}, 144>;
  ${e.registerUniforms([{name:"M",type:"u32"},{name:"K",type:"u32"},{name:"N",type:"u32"},{name:"num_heads",type:"u32"},{name:"head_size",type:"u32"},{name:"hidden_size",type:"u32"},{name:"ldb",type:"u32"}]).declareVariables(n,s,o,t,r,i)}
  ${e.mainStart([12,12,1])}
    let batchIndex = workgroup_id.z / uniforms.num_heads;
    let headNumber = workgroup_id.z % uniforms.num_heads;
    let m = global_id.y;
    let n = global_id.x;

    let inputOffset = batchIndex * (uniforms.M * uniforms.K) + m * uniforms.K;
    let biasOffsetQ = headNumber * uniforms.head_size;
    let biasOffsetK = uniforms.hidden_size + biasOffsetQ;
    let biasOffsetV = uniforms.hidden_size + biasOffsetK;

    var valueQ = ${u}(0);
    var valueK = ${u}(0);
    var valueV = ${u}(0);
    for (var w: u32 = 0u; w < uniforms.K; w += TILE_SIZE) {
      if (m < uniforms.M && w + local_id.x < uniforms.K) {
        tileInput[TILE_SIZE * local_id.y + local_id.x] = input[inputOffset + w + local_id.x];
      }
      if (n < uniforms.N && w + local_id.y < uniforms.K) {
        let offset = n + (w + local_id.y) * uniforms.ldb;
        tileWeightQ[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetQ + offset];
        tileWeightK[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetK + offset];
        tileWeightV[TILE_SIZE * local_id.y + local_id.x] = weight[biasOffsetV + offset];
      }
      workgroupBarrier();
      for (var k: u32 = 0u; k<TILE_SIZE && w+k < uniforms.K; k++) {
        let inputTileOffset = TILE_SIZE * local_id.y + k;
        let weightTileOffset = TILE_SIZE * k + local_id.x;
        valueQ += tileInput[inputTileOffset] * tileWeightQ[weightTileOffset];
        valueK += tileInput[inputTileOffset] * tileWeightK[weightTileOffset];
        valueV += tileInput[inputTileOffset] * tileWeightV[weightTileOffset];
      }

      workgroupBarrier();
    }

    let headOffset = (m * uniforms.N + n) % uniforms.head_size;
    valueQ += bias[headOffset + biasOffsetQ];
    valueK += bias[headOffset + biasOffsetK];
    valueV += bias[headOffset + biasOffsetV];

    let offset = workgroup_id.z * uniforms.M * uniforms.N;
    if (m < uniforms.M && n < uniforms.N) {
      let outputIdx = offset + m * uniforms.N + n;
      output_q[outputIdx] = valueQ;
      output_k[outputIdx] = valueK;
      output_v[outputIdx] = valueV;
    }
  }`}},{inputs:l,outputs:[-1,-1,-1]}));return rh(e,c,h,f,e.inputs[4],void 0,void 0,void 0,e.inputs[5],p)}}),nz=M(()=>{"use strict";en(),nf(),ny(),nx(),nk(),rm=(e,t)=>{let r,{inputs:i,outputCount:a}=e,n=(r={...t,outputCount:a},tb(r));if(h.webgpu.validateInputContent&&((e,t)=>{if(!e||5!==e.length)throw Error("BatchNormalization requires 5 inputs");let r=(e,t,r)=>{let i=t.length;if(i!==e.length)throw Error(`${r}: num dimensions != ${i}`);t.forEach((t,i)=>{if(t!==e[i])throw Error(`${r}: dim[${i}] do not match`)})};if(e[0].dims.length>1){let i="NHWC"===t.format?t.spatial?e[0].dims.slice(-1):e[0].dims.slice(-1).concat(e[0].dims.slice(1,e[0].dims.length-1)):e[0].dims.slice(1,t.spatial?2:void 0);r(e[1].dims,i,"Invalid input scale"),r(e[2].dims,i,"Invalid input B"),r(e[3].dims,i,"Invalid input mean"),r(e[4].dims,i,"Invalid input var")}else r(e[1].dims,[1],"Invalid input scale"),r(e[2].dims,[1],"Invalid input B"),r(e[3].dims,[1],"Invalid input mean"),r(e[4].dims,[1],"Invalid input var")})(i,n),t.trainingMode)throw Error("BatchNormalization trainingMode is not supported yet.");e.compute(((e,t)=>{let{epsilon:r,spatial:i,format:a}=t,n=e[0].dims,s=i?tS(n[n.length-1]):1,o="NHWC"===a&&n.length>1?s:1,u=e2.size(n)/s,l=i?n.length:n,d=tA("x",e[0].dataType,e[0].dims,s),p=tA("scale",e[1].dataType,e[1].dims,o),c=tA("bias",e[2].dataType,e[2].dims,o),h=tA("inputMean",e[3].dataType,e[3].dims,o),f=tA("inputVar",e[4].dataType,e[4].dims,o),m=tO("y",e[0].dataType,l,s);return{name:"BatchNormalization",shaderCache:{hint:`${t.epsilon}_${t.format}_${i}_${s}`,inputDependencies:i?["rank","type","type","type","type"]:void 0},getShaderSource:e=>`
  const epsilon = ${r};
  ${e.registerUniform("outputSize","u32").declareVariables(d,p,c,h,f,m)}
  ${e.mainStart()}
  ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
    var outputIndices = ${m.offsetToIndices(`global_idx * ${s}`)};
    ${(()=>{let e="";if(i)e=`let cOffset = ${1===n.length?"0u":"NHWC"===a?`outputIndices[${n.length-1}] / ${s}`:"outputIndices[1]"};`;else if("NCHW"===a)e=`
            ${m.indicesSet("outputIndices","0","0")}
            let cOffset = ${m.indicesToOffset("outputIndices")};`;else{e=`var cIndices = ${p.type.indices}(0);
                       cIndices[0] = outputIndices[${n.length-1}];`;for(let t=1;t<p.rank;t++)e+=`cIndices[${t}] = outputIndices[${t}];`;e+=`let cOffset = ${p.indicesToOffset("cIndices")};`}return e})()}
    let scale = ${p.getByOffset("cOffset")};
    let bias = ${c.getByOffset("cOffset")};
    let inputMean = ${h.getByOffset("cOffset")};
    let inputVar = ${f.getByOffset("cOffset")};
    let x = ${d.getByOffset("global_idx")};
    let value = (x - inputMean) * inverseSqrt(inputVar + epsilon) * scale + bias;
    ${m.setByOffset("global_idx","value")}
  }`,getRunData:()=>({outputs:[{dims:e[0].dims,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(u/64)},programUniforms:i?[{type:12,data:u},...tk(n)]:[{type:12,data:u}]})}})(i,n))}}),nA=M(()=>{"use strict";ny(),nk(),rg=e=>{var t;let r,i,a,n,s,o,u,l;(e=>{if(3!==e[0].dims.length)throw Error("input should have 3 dimensions");if(![320,640,1280].includes(e[0].dims[2]))throw Error("number of channels should be 320, 640 or 1280");if(1!==e[1].dims.length)throw Error("bias is expected to have 1 dimensions");if(e[0].dims[2]!==e[1].dims[0])throw Error("last dimension of input and bias are not the same")})(e.inputs),e.compute((r=(t=e.inputs)[0].dims,i=t[0].dims[2],a=e2.size(r)/4,n=t[0].dataType,s=tA("input",n,r,4),o=tA("bias",n,[i],4),u=tA("residual",n,r,4),l=tO("output",n,r,4),{name:"BiasAdd",getRunData:()=>({outputs:[{dims:r,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(a/64)}}),getShaderSource:e=>`
  const channels = ${i}u / 4;
  ${e.declareVariables(s,o,u,l)}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes(a)}
    let value = ${s.getByOffset("global_idx")}
      + ${o.getByOffset("global_idx % channels")} + ${u.getByOffset("global_idx")};
    ${l.setByOffset("global_idx","value")}
  }`}))}}),nO=M(()=>{"use strict";nf(),ny(),nx(),nk(),ry=(e,t,r,i,a,n=e.dataType,s,o)=>{let u=[{type:12,data:Math.ceil(e2.size(e.dims)/4)}];return s&&u.push(...s),{name:t,shaderCache:{hint:a,inputDependencies:["type"]},getShaderSource:t=>{var a,s,u,l,d,p,c;let h,f,m,g,y;return a=t,s=e2.size(e.dims),u=e.dataType,l=n,d=r,p=i,c=o,h=Math.ceil(s/4),f="",f="string"==typeof d?`${d}(a)`:d("a"),m=tA("inputData",u,[h],4),g=tO("outputData",l,[h],4),y=[{name:"vec_size",type:"u32"}],c&&y.push(...c),`
      ${a.registerUniforms(y).declareVariables(m,g)}

  ${p??""}

  ${a.mainStart()}
    ${a.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}

    let a = ${m.getByOffset("global_idx")};
    ${g.setByOffset("global_idx",f)}
  }`},getRunData:t=>({outputs:[{dims:e.dims,dataType:n}],dispatchGroup:{x:Math.ceil(e2.size(t[0].dims)/64/4)},programUniforms:u})}},r_=e=>{e.compute(ry(e.inputs[0],"Abs","abs"))},rb=e=>{e.compute(ry(e.inputs[0],"Acos","acos"))},r$=e=>{e.compute(ry(e.inputs[0],"Acosh","acosh"))},rv=e=>{e.compute(ry(e.inputs[0],"Asin","asin"))},rw=e=>{e.compute(ry(e.inputs[0],"Asinh","asinh"))},rx=e=>{e.compute(ry(e.inputs[0],"Atan","atan"))},rk=e=>{e.compute(ry(e.inputs[0],"Atanh","atanh"))},rS=e=>tb(e),rT=(e,t)=>{let r;switch(t.to){case 10:r="vec4<f16>";break;case 1:r="vec4<f32>";break;case 12:r="vec4<u32>";break;case 6:r="vec4<i32>";break;case 9:r="vec4<bool>";break;default:throw RangeError(`not supported type (specified in attribute 'to' from 'Cast' operator): ${t.to}`)}e.compute(ry(e.inputs[0],"Cast",r,void 0,t.cacheKey,t.to))},rI=(e,t)=>{let r=t||(e=>{let t,r,i=e.length>=2&&0!==e[1].data,a=e.length>=3&&0!==e[2].data;switch(e[0].dataType){case 1:t=i?e[1].getFloat32Array()[0]:-34028234663852886e22,r=a?e[2].getFloat32Array()[0]:34028234663852886e22;break;case 10:t=i?e[1].getUint16Array()[0]:64511,r=a?e[2].getUint16Array()[0]:31743;break;default:throw Error("Unsupport data type")}return tb({min:t,max:r})})(e.inputs),i=tx(e.inputs[0].dataType);e.compute(ry(e.inputs[0],"Clip",e=>`clamp(${e}, vec4<${i}>(uniforms.min), vec4<${i}>(uniforms.max))`,void 0,r.cacheKey,void 0,[{type:e.inputs[0].dataType,data:r.min},{type:e.inputs[0].dataType,data:r.max}],[{name:"min",type:i},{name:"max",type:i}]),{inputs:[0]})},rE=e=>{e.compute(ry(e.inputs[0],"Ceil","ceil"))},rC=e=>{e.compute(ry(e.inputs[0],"Cos","cos"))},rz=e=>{e.compute(ry(e.inputs[0],"Cosh","cosh"))},rA=e=>tb(e),rO=(e,t)=>{let r=tx(e.inputs[0].dataType);e.compute(ry(e.inputs[0],"Elu",e=>`elu_vf32(${e})`,`
  const elu_alpha_ = ${r}(${t.alpha});

  fn elu_f32(a: ${r}) -> ${r} {
  return select((exp(a) - 1.0) * elu_alpha_, a, a >= 0.0);
  }

  fn elu_vf32(v: vec4<${r}>) -> vec4<${r}> {
  return vec4(elu_f32(v.x), elu_f32(v.y), elu_f32(v.z), elu_f32(v.w));
  }`,t.cacheKey))},rR=(e="f32")=>`
const r0: ${e} = 0.3275911;
const r1: ${e} = 0.254829592;
const r2: ${e} = -0.284496736;
const r3: ${e} = 1.421413741;
const r4: ${e} = -1.453152027;
const r5: ${e} = 1.061405429;

fn erf_vf32(v: vec4<${e}>) -> vec4<${e}> {
  let absv = abs(v);
  let x = 1.0 / (1.0 + r0 * absv);
  return sign(v) * (1.0 - ((((r5 * x + r4) * x + r3) * x + r2) * x + r1) * x * exp(-absv * absv));
}`,rB=e=>{let t=tx(e.inputs[0].dataType);e.compute(ry(e.inputs[0],"Erf",e=>`erf_vf32(${e})`,rR(t)))},rN=e=>{e.compute(ry(e.inputs[0],"Exp","exp"))},rD=e=>{e.compute(ry(e.inputs[0],"Floor","floor"))},rM=e=>{let t=tx(e.inputs[0].dataType);e.compute(ry(e.inputs[0],"Gelu",e=>`0.5 * ${e} * (1.0 + erf_vf32(${e} * 0.7071067811865475))`,rR(t)))},rP=(e,t)=>{let r=tx(e.inputs[0].dataType);e.compute(ry(e.inputs[0],"LeakyRelu",e=>`select(leaky_relu_alpha_ * ${e}, ${e}, ${e} >= vec4<${r}>(0.0))`,`const leaky_relu_alpha_ = ${r}(${t.alpha});`,t.cacheKey))},rU=e=>{e.compute(ry(e.inputs[0],"Not",e=>`!${e}`))},rq=e=>{e.compute(ry(e.inputs[0],"Neg",e=>`-${e}`))},rW=e=>{e.compute(ry(e.inputs[0],"Reciprocal",e=>`1.0/${e}`))},rL=e=>{let t=tx(e.inputs[0].dataType);e.compute(ry(e.inputs[0],"Relu",e=>`select(vec4<${t}>(0.0), ${e}, ${e} > vec4<${t}>(0.0))`))},rV=e=>{e.compute(ry(e.inputs[0],"Sigmoid",e=>`(1.0 / (1.0 + exp(-${e})))`))},rG=e=>tb(e),rH=(e,t)=>{let r=tx(e.inputs[0].dataType);e.compute(ry(e.inputs[0],"HardSigmoid",e=>`max(vec4<${r}>(0.0), min(vec4<${r}>(1.0), ${t.alpha} * ${e} + vec4<${r}>(${t.beta})))`,void 0,t.cacheKey))},rF=e=>{e.compute(ry(e.inputs[0],"Sin","sin"))},rj=e=>{e.compute(ry(e.inputs[0],"Sinh","sinh"))},rK=e=>{e.compute(ry(e.inputs[0],"Sqrt","sqrt"))},rZ=e=>{e.compute(ry(e.inputs[0],"Tan","tan"))},rQ=e=>`sign(${e}) * (1 - exp(-2 * abs(${e}))) / (1 + exp(-2 * abs(${e})))`,rX=e=>{e.compute(ry(e.inputs[0],"Tanh",rQ))},rY=(e="f32")=>`
const fast_gelu_a: ${e} = 0.5;
const fast_gelu_b: ${e} = 0.7978845608028654;
const fast_gelu_c: ${e} = 0.035677408136300125;

fn tanh_v(v: vec4<${e}>) -> vec4<${e}> {
  return ${rQ("v")};
}
`,rJ=e=>`(fast_gelu_a + fast_gelu_a * tanh_v(${e} * (fast_gelu_c * ${e} * ${e} + fast_gelu_b))) * ${e}`,r0=e=>{let t=tx(e.inputs[0].dataType);e.compute(ry(e.inputs[0],"FastGelu",rJ,rY(t),void 0,e.inputs[0].dataType))},r2=(e,t)=>{let r=tx(e.inputs[0].dataType);return e.compute(ry(e.inputs[0],"ThresholdedRelu",e=>`select(vec4<${r}>(0.0), ${e}, ${e} > thresholded_relu_alpha_)`,`const thresholded_relu_alpha_ = vec4<${r}>(${t.alpha});`,t.cacheKey)),0},r1=e=>{e.compute(ry(e.inputs[0],"Log","log"))},r3=e=>`quick_gelu_impl(${e})`,r4=(e,t)=>{let r,i,a=tx(e.inputs[0].dataType);e.compute(ry(e.inputs[0],"QuickGelu",r3,(r=a,i=t.alpha,`
const alpha = vec4<${r}>(${i});
const one = ${r}(1.0);
const zero = ${r}(0.0);

fn quick_gelu_impl(x: vec4<${r}>) -> vec4<${r}> {
  let v = x *alpha;
  var x1 : vec4<${r}>;
  for (var i = 0; i < 4; i = i + 1) {
    if (v[i] >= zero) {
      x1[i] = one / (one + exp(-v[i]));
    } else {
      x1[i] = one - one / (one + exp(v[i]));
    }
  }
  return x * x1;
}
`),t.cacheKey,e.inputs[0].dataType))}}),nR=M(()=>{"use strict";ny(),nk(),nO(),r6=e=>{var t;let r,i,a,n,s,o;(e=>{if(3!==e[0].dims.length)throw Error("input should have 3 dimensions");if(![2560,5120,10240].includes(e[0].dims[2]))throw Error("hidden state should be 2560, 5120 or 10240");if(1!==e[1].dims.length)throw Error("bias is expected to have 1 dimensions");if(e[0].dims[2]!==e[1].dims[0])throw Error("last dimension of input and bias are not the same")})(e.inputs),e.compute(((r=(t=e.inputs)[0].dims.slice())[2]=r[2]/2,i=tA("input",t[0].dataType,t[0].dims,4),a=tA("bias",t[0].dataType,[t[0].dims[2]],4),n=tO("output",t[0].dataType,r,4),s=e2.size(r)/4,o=tw(t[0].dataType),{name:"BiasSplitGelu",getRunData:()=>({outputs:[{dims:r,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(s/64)}}),getShaderSource:e=>`
  const M_SQRT2 = sqrt(2.0);
  const halfChannels = ${t[0].dims[2]/4/2}u;

  ${e.declareVariables(i,a,n)}

  ${rR(o)}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes(s)}
    let biasIdx = global_idx % halfChannels;
    let batchIndex = global_idx / halfChannels;
    let inputOffset = biasIdx + batchIndex * halfChannels * 2;
    let valueLeft = input[inputOffset] + bias[biasIdx];
    let valueRight = input[inputOffset + halfChannels] + bias[biasIdx + halfChannels];
    let geluRight = valueRight * 0.5 * (erf_vf32(valueRight / M_SQRT2) + 1);

    ${n.setByOffset("global_idx","valueLeft * geluRight")}
  }`}))}}),nB=M(()=>{"use strict";nf(),ny(),nk(),r8=(e,t,r,i,a,n)=>{e.compute(((e,t,r,i,a,n,s=r.dataType)=>{let o=r.dims.map(e=>Number(e)??1),u=i.dims.map(e=>Number(e)??1),l=!e2.areEqual(o,u),d=o,p=e2.size(o),c=!1,h=!1,f=[l];if(l){let e=e0.calcShape(o,u,!1);if(!e)throw Error("Can't perform binary op on the given tensors");d=e.slice(),p=e2.size(d);let t=1===e2.size(o),r=1===e2.size(u),i=o.length>0&&o[o.length-1]%4==0,a=u.length>0&&u[u.length-1]%4==0;f.push(t),f.push(r),f.push(i),f.push(a);let n=1;for(let e=1;e<d.length;e++){let t=o[o.length-e];if(t===u[u.length-e])n*=t;else break}n%4==0?(h=!0,c=!0):(t||r||i||a)&&(c=!0)}else c=!0;return f.push(c),{name:e,shaderCache:{hint:t+f.map(e=>e.toString()).join("_"),inputDependencies:["rank","rank"]},getShaderSource:e=>((e,t,r,i,a,n,s,o,u,l,d,p)=>{let c,h;"string"==typeof o?c=h=(e,t)=>`${o}((${e}),(${t}))`:"function"==typeof o?c=h=o:(c=o.scalar,h=o.vector);let f=tO("outputData",d,i.length,4),m=tA("aData",u,t.length,4),g=tA("bData",l,r.length,4),y;if(a)if(n){let e=1===e2.size(t),i=1===e2.size(r),a=t.length>0&&t[t.length-1]%4==0,n=r.length>0&&r[r.length-1]%4==0;y=e||i?f.setByOffset("global_idx",h(e?`${m.type.value}(${m.getByOffset("0")}.x)`:m.getByOffset("global_idx"),i?`${g.type.value}(${g.getByOffset("0")}.x)`:g.getByOffset("global_idx"))):`
            let outputIndices = ${f.offsetToIndices("global_idx * 4u")};
            let offsetA = ${m.broadcastedIndicesToOffset("outputIndices",f)};
            let offsetB = ${g.broadcastedIndicesToOffset("outputIndices",f)};
            ${f.setByOffset("global_idx",h(s||a?m.getByOffset("offsetA / 4u"):`${m.type.value}(${m.getByOffset("offsetA / 4u")}[offsetA % 4u])`,s||n?g.getByOffset("offsetB / 4u"):`${g.type.value}(${g.getByOffset("offsetB / 4u")}[offsetB % 4u])`))}
          `}else y=f.setByOffset("global_idx",h(m.getByOffset("global_idx"),g.getByOffset("global_idx")));else{if(!n)throw Error("no necessary to use scalar implementation for element-wise binary op implementation.");let e=(e,t,r="")=>{let i=`aData[indexA${t}][componentA${t}]`,a=`bData[indexB${t}][componentB${t}]`;return`
            let outputIndices${t} = ${f.offsetToIndices(`global_idx * 4u + ${t}u`)};
            let offsetA${t} = ${m.broadcastedIndicesToOffset(`outputIndices${t}`,f)};
            let offsetB${t} = ${g.broadcastedIndicesToOffset(`outputIndices${t}`,f)};
            let indexA${t} = offsetA${t} / 4u;
            let indexB${t} = offsetB${t} / 4u;
            let componentA${t} = offsetA${t} % 4u;
            let componentB${t} = offsetB${t} % 4u;
            ${e}[${t}] = ${r}(${c(i,a)});
          `};y=9===d?`
            var data = vec4<u32>(0);
            ${e("data",0,"u32")}
            ${e("data",1,"u32")}
            ${e("data",2,"u32")}
            ${e("data",3,"u32")}
            outputData[global_idx] = dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(data));`:`
            ${e("outputData[global_idx]",0)}
            ${e("outputData[global_idx]",1)}
            ${e("outputData[global_idx]",2)}
            ${e("outputData[global_idx]",3)}
          `}return`
        ${e.registerUniform("vec_size","u32").declareVariables(m,g,f)}

        ${p??""}

        ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
        ${y}
      }`})(e,o,u,d,c,l,h,a,r.dataType,i.dataType,s,n),getRunData:()=>({outputs:[{dims:d,dataType:s}],dispatchGroup:{x:Math.ceil(p/64/4)},programUniforms:[{type:12,data:Math.ceil(e2.size(d)/4)},...tk(o,u,d)]})}})(t,a??"",e.inputs[0],e.inputs[1],r,i,n))},r5=e=>{r8(e,"Add",(e,t)=>`${e}+${t}`)},r7=e=>{r8(e,"Div",(e,t)=>`${e}/${t}`)},r9=e=>{r8(e,"Equal",{scalar:(e,t)=>`u32(${e}==${t})`,vector:(e,t)=>`vec4<u32>(${e}==${t})`},void 0,void 0,9)},ie=e=>{r8(e,"Mul",(e,t)=>`${e}*${t}`)},it=e=>{let t=tA("input",e.inputs[0].dataType,e.inputs[0].dims).type.value;r8(e,"Pow",{scalar:(e,t)=>`pow_custom(${e},${t})`,vector:(e,t)=>`pow_vector_custom(${e},${t})`},`
    fn pow_custom(a : ${t}, b : ${t}) -> ${t} {
      if (b == ${t}(0.0)) {
        return ${t}(1.0);
      } else if (a < ${t}(0.0) && f32(b) != floor(f32(b))) {
        return ${t}(pow(f32(a), f32(b))); // NaN
      }
      return select(sign(a), ${t}(1.0), round(f32(abs(b) % ${t}(2.0))) != 1.0) * ${t}(${"i32"===t?"round":""}(pow(f32(abs(a)), f32(b))));
    }
    fn pow_vector_custom(a : vec4<${t}>, b : vec4<${t}>) -> vec4<${t}> {
      // TODO: implement vectorized pow
      return vec4<${t}>(pow_custom(a.x, b.x), pow_custom(a.y, b.y), pow_custom(a.z, b.z), pow_custom(a.w, b.w));
    }
      `)},ir=e=>{r8(e,"Sub",(e,t)=>`${e}-${t}`)},ii=e=>{r8(e,"Greater",{scalar:(e,t)=>`u32(${e}>${t})`,vector:(e,t)=>`vec4<u32>(${e}>${t})`},void 0,void 0,9)},ia=e=>{r8(e,"Less",{scalar:(e,t)=>`u32(${e}<${t})`,vector:(e,t)=>`vec4<u32>(${e}<${t})`},void 0,void 0,9)},is=e=>{r8(e,"GreaterOrEqual",{scalar:(e,t)=>`u32(${e}>=${t})`,vector:(e,t)=>`vec4<u32>(${e}>=${t})`},void 0,void 0,9)},io=e=>{r8(e,"LessOrEqual",{scalar:(e,t)=>`u32(${e}<=${t})`,vector:(e,t)=>`vec4<u32>(${e}<=${t})`},void 0,void 0,9)}}),nN=M(()=>{"use strict";nf(),ny(),nx(),nk(),iu=(e,t)=>{let r=e.inputs,i=r[0].dims,a=e2.normalizeAxis(t.axis,i.length);var n=r,s=a;if(!n||n.length<1)throw Error("too few inputs");let o=n[0],u=o.dataType,l=o.dims.length;n.forEach((e,t)=>{if(0!==t){if(e.dataType!==u)throw Error("input tensors should be one type");if(e.dims.length!==l)throw Error("input tensors should have the same shape");e.dims.forEach((e,t)=>{if(t!==s&&e!==o.dims[t])throw Error("non concat dimensions must match")})}});let d=i.slice();d[a]=r.reduce((e,t)=>e+(t.dims.length>a?t.dims[a]:0),0);let p=r.filter(e=>e2.size(e.dims)>0);e.compute(((e,t,r,i)=>{let a=e2.size(r),n=Array(e.length),s=Array(e.length),o=0,u=[],l=[],d=[{type:12,data:a}];for(let r=0;r<e.length;++r)o+=e[r].dims[t],n[r]=o,l.push(e[r].dims.length),s[r]=tA(`input${r}`,i,l[r]),u.push("rank"),d.push({type:12,data:n[r]});for(let t=0;t<e.length;++t)d.push(...tk(e[t].dims));d.push(...tk(r));let p=tO("output",i,r.length),c=p.indicesGet("indices",t),h=Array.from(Array(n.length).keys()).map(e=>`uniforms.sizeInConcatAxis${e}`).join(",");return{name:"Concat",shaderCache:{hint:`${t}`,inputDependencies:u},getRunData:()=>({outputs:[{dims:r,dataType:i}],dispatchGroup:{x:Math.ceil(a/64)},programUniforms:d}),getShaderSource:t=>{let r,i;return`

  ${(()=>{t.registerUniform("outputSize","u32");for(let r=0;r<e.length;r++)t.registerUniform(`sizeInConcatAxis${r}`,"u32");return t.declareVariables(...s,p)})()}

  ${r=n.length,i=h,`
  fn calculateInputIndex(index: u32) -> u32 {
    let sizeInConcatAxis = array<u32, ${r}u>(${i});
    for (var i: u32 = 0u; i < ${r}; i += 1u ) {
      if (index < sizeInConcatAxis[i]) {
        return i;
      }
    }
    return ${r}u;
  }`}

  ${t.mainStart()}
    ${t.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

    var indices = ${p.offsetToIndices("global_idx")};

    let inputIndex = calculateInputIndex(${c});
    if (inputIndex != 0u) {
      let sizeInConcatAxis = array<u32, ${n.length}u>(${h});
      ${c} -= sizeInConcatAxis[inputIndex - 1u];
    }

    ${((e,t)=>{let r=e.length,i=[];for(let a=0;a<r;++a){let n=t.setByOffset("global_idx",e[a].getByIndices("indices"));1===r?i.push(n):0===a?i.push(`if (inputIndex == ${a}u) { ${n} }`):a===r-1?i.push(`else { ${n} }`):i.push(`else if (inputIndex == ${a}) { ${n} }`)}return i.join(`
`)})(s,p)}
  }`}}})(p,a,d,r[0].dataType),{inputs:p})},il=e=>tb({axis:e.axis})}),nD=M(()=>{"use strict";nf(),ny(),id=(e,t,r="f32")=>{switch(e.activation){case"Relu":return`value = max(value, ${t}(0.0));`;case"Sigmoid":return`value = (${t}(1.0) / (${t}(1.0) + exp(-value)));`;case"Clip":return`value = clamp(value, ${t}(${r}(uniforms.clip_min)), ${t}(${r}(uniforms.clip_max)));`;case"HardSigmoid":return`value = max(${t}(0.0), min(${t}(1.0), ${r}(uniforms.alpha) * value + ${r}(uniforms.beta)));`;case"LeakyRelu":return`value = select(${r}(uniforms.alpha) * value, value, value >= ${t}(0.0));`;case"Tanh":return`let e2x = exp(-2.0 * abs(value));
              value = sign(value) * (1.0 - e2x) / (1.0 + e2x);
        `;case"":return"";default:throw Error(`Unsupported activation ${e.activation}`)}},ip=(e,t)=>{"Clip"===e.activation?t.push({type:1,data:e.clipMax},{type:1,data:e.clipMin}):"HardSigmoid"===e.activation?t.push({type:1,data:e.alpha},{type:1,data:e.beta}):"LeakyRelu"===e.activation&&t.push({type:1,data:e.alpha})},ic=(e,t)=>{"Clip"===e.activation?t.push({name:"clip_max",type:"f32"},{name:"clip_min",type:"f32"}):"HardSigmoid"===e.activation?t.push({name:"alpha",type:"f32"},{name:"beta",type:"f32"}):"LeakyRelu"===e.activation&&t.push({name:"alpha",type:"f32"})},ih=e=>{let t=e?.activation||"";if("HardSigmoid"===t){let[r,i]=e?.activation_params||[.2,.5];return{activation:t,alpha:r,beta:i}}if("Clip"===t){let[r,i]=e?.activation_params||[e4,e6];return{activation:t,clipMax:i,clipMin:r}}if("LeakyRelu"===t){let[r]=e?.activation_params||[.01];return{activation:t,alpha:r}}return{activation:t}}}),nM=M(()=>{"use strict";im=(e,t)=>{switch(e){case 1:return t;case 2:return`vec2<${t}>`;case 3:return`vec3<${t}>`;case 4:return`vec4<${t}>`;default:throw Error(`${e}-component is not supported.`)}},ig=e=>`
      ${e?"value = value + getBiasByOutputCoords(coords);":""}
      `}),nP=M(()=>{"use strict";iy=e=>`
fn getIndexFromCoords4D(coords : vec4<i32>, shape : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(
      shape.y * shape.z * shape.w, shape.z * shape.w, shape.w, 1));
}
fn getOutputIndexFromCoords(coords : vec4<i32>) -> i32 {
  return dot(coords, vec4<i32>(
    i32(${e}.x), i32(${e}.y), i32(${e}.z), 1));
}
`}),nU=M(()=>{"use strict";nf(),ny(),nk(),nD(),i_=(e,t,r,i,a)=>{let n=i-r;return`
      ${Array.from({length:r}).map((r,s)=>`
      if (${tC(t.shape,s,t.rank)} != 1) {
        ${t.indicesSet(e,s,tC(a,s+n,i))}
      } else {
        ${t.indicesSet(e,s,0)}
      }`).join("")}
`},ib=(e,t,r,i,a=!1,n)=>{let s=e[0].dims,o=e[1].dims,u=s[s.length-2],l=o[o.length-1],d=s[s.length-1],p=tS(l),c=tS(d),h=tS(u),f=e2.size(r)/p/h,m=e.length>2,g=i?i.slice(0,-2):r.slice(0,-2),y=[e2.size(g),u,l],_=[{type:12,data:f},{type:12,data:u},{type:12,data:l},{type:12,data:d}];return ip(t,_),_.push(...tk(g,s,o)),m&&_.push(...tk(e[2].dims)),_.push(...tk(y)),{name:"MatMulNaive",shaderCache:{hint:`${t.activation};${p};${c};${h};${a}`,inputDependencies:m?["rank","rank","rank"]:["rank","rank"]},getRunData:()=>({outputs:[{dims:n?n(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(f/64)},programUniforms:_}),getShaderSource:i=>{let n=tB("batch_dims",e[0].dataType,g.length),u=tA("a",e[0].dataType,s.length,c),l=tA("b",e[1].dataType,o.length,p),d=tO("output",e[0].dataType,y.length,p),f=tw(d.type.tensor),_=id(t,d.type.value,f),b=[u,l],$="";if(m){let t=a?p:1;b.push(tA("bias",e[2].dataType,e[2].dims.length,t)),$=`${a?`value += bias[col / ${t}];`:`value += ${d.type.value}(bias[row + i]);`}`}let v=[{name:"output_size",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"}];return ic(t,v),`
  ${i.registerUniforms(v).registerInternalVariables(n).declareVariables(...b,d)}
  ${i.mainStart()}
    ${i.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let col = (global_idx % (uniforms.N / ${p})) * ${p};
    var index1 = global_idx / (uniforms.N / ${p});
    let stride1 = uniforms.M / ${h};
    let row = (index1 % stride1) * ${h};
    let batch = index1 / stride1;

    ${2===r.length?"":`let batch_indices = ${n.offsetToIndices("batch")};`}

    var a_indices: ${u.type.indices};
    ${i_("a_indices",u,u.rank-2,n.rank,"batch_indices")}
    ${u.indicesSet("a_indices",u.rank-2,0)}
    ${u.indicesSet("a_indices",u.rank-1,0)}
    let a_offset = ${u.indicesToOffset("a_indices")};

    var b_indices: ${l.type.indices};
    ${i_("b_indices",l,l.rank-2,n.rank,"batch_indices")}
    ${l.indicesSet("b_indices",l.rank-2,0)}
    ${l.indicesSet("b_indices",l.rank-1,0)}
    let b_offset = ${l.indicesToOffset("b_indices")};
    var values: array<${d.type.value}, ${h}>;
    for (var k: u32 = 0u; k < uniforms.K; k = k + ${c}) {
      ${(()=>{let e=`var a_data: ${u.type.value};`;for(let t=0;t<c;t++)e+=`
              let b_data${t} = b[(b_offset + (k + ${t}) * uniforms.N + col) / ${p}];`;for(let t=0;t<h;t++){e+=`a_data = a[(a_offset + (row + ${t}) * uniforms.K + k) / ${c}];`;for(let r=0;r<c;r++)e+=`
            values[${t}] = fma(${l.type.value}(a_data${1===c?"":`[${r}]`}), b_data${r}, values[${t}]);
`}return e})()}
    }
    for (var i = 0u; i < ${h}u; i++) {
      var value = values[i];
      ${$}
      ${_}
      let cur_indices = ${d.type.indices}(batch, row + i, col);
      let offset = ${d.indicesToOffset("cur_indices")};
      ${d.setByOffset(`offset / ${p}`,"value")};
    }
  }
  `}}}}),nq=M(()=>{"use strict";nf(),ny(),nk(),nD(),nU(),nM(),i$=(e,t,r="f32",i,a=!1,n=32,s=!1,o=32)=>{let u,l,d,p,c=t[1]*e[1],h=t[0]*e[0],f=a?c:n,m=a?n:c,g=f/t[0],y=n/t[1];if(!((a&&4===g&&4===e[1]||!a&&(3===g||4===g))&&f%t[0]==0&&n%t[1]==0&&4===e[0]))throw Error(`If transposeA ${a} is true, innerElementSize ${g} and workPerThread[1] ${e[1]} must be 4.
      Otherwise, innerElementSize ${g} must be 3 or 4.
  tileAWidth ${f} must be divisible by workgroupSize[0]${t[0]}. tileInner ${n} must be divisible by workgroupSize[1] ${t[1]}. colPerThread ${e[0]} must be 4.`);return`
var<workgroup> mm_Asub: array<array<vec${g}<${r}>, ${f/g}>, ${m}>;
var<workgroup> mm_Bsub: array<array<vec4<${r}>, ${h/e[0]}>, ${n}>;

const rowPerThread = ${e[1]};
const colPerThread = ${e[0]};
const innerElementSize = ${g};
const tileInner = ${n};

@compute @workgroup_size(${t[0]}, ${t[1]}, ${t[2]})
fn main(@builtin(local_invocation_id) localId : vec3<u32>,
        @builtin(global_invocation_id) globalId : vec3<u32>,
        @builtin(workgroup_id) workgroupId : vec3<u32>) {
  let localRow = i32(localId.y);
  let tileRow = localRow * rowPerThread;
  let tileCol = i32(localId.x);

  let globalRow =i32(globalId.y) * rowPerThread;
  let globalCol = i32(globalId.x);
  let batch = ${s?"0":"i32(globalId.z)"};
  ${i?`let batchIndices = ${i.offsetToIndices("u32(batch)")};`:""}
  let globalRowStart = i32(workgroupId.y) * ${c};

  let num_tiles = ${s?`${Math.ceil(o/n)}`:"(uniforms.dim_inner - 1) / tileInner + 1"};
  var kStart = ${s?`i32(globalId.z) * ${o}`:"0"};

  var acc: array<vec4<${r}>, rowPerThread>;

  // Loop over shared dimension.
  let tileRowB = localRow * ${y};
  for (var t = 0; t < num_tiles; t = t + 1) {
      // Load one tile of A into local memory.
      for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
          let inputRow = tileRow + innerRow;
          let inputCol = tileCol;
          ${u=a,l=i,u?`
        mm_Asub[inputRow][inputCol] = mm_readA(batch,
          kStart + inputRow,
          globalRowStart / innerElementSize + inputCol${l?", batchIndices":""});
        `:`
        mm_Asub[inputRow][inputCol] = mm_readA(batch,
          globalRow + innerRow,
          kStart / innerElementSize + inputCol${l?", batchIndices":""});
        `}
      }

      // Load one tile of B into local memory.
      for (var innerRow = 0; innerRow < ${y}; innerRow = innerRow + 1) {
          let inputRow = tileRowB + innerRow;
          let inputCol = tileCol;
          mm_Bsub[inputRow][inputCol] = mm_readB(batch, kStart + inputRow, globalCol${i?", batchIndices":""});
      }
      kStart = kStart + tileInner;
      workgroupBarrier();

      // Compute acc values for a single thread.
      for (var k = 0; k < tileInner / innerElementSize; k = k + 1) {
          let BCached0 = mm_Bsub[k * innerElementSize][tileCol];
          let BCached1 = mm_Bsub[k * innerElementSize + 1][tileCol];
          let BCached2 = mm_Bsub[k * innerElementSize + 2][tileCol];
          ${3===g?"":"let BCached3 = mm_Bsub[k * innerElementSize + 3][tileCol];"}

          ${d=a,p=g,d?`
        let ACached0 = mm_Asub[k * innerElementSize][localRow];
        let ACached1 = mm_Asub[k * innerElementSize + 1][localRow];
        let ACached2 = mm_Asub[k * innerElementSize + 2][localRow];
        ${3===p?"":"let ACached3 = mm_Asub[k * innerElementSize + 3][localRow];"}
        for (var i = 0; i < rowPerThread; i = i + 1) {
          acc[i] = BCached0 * ACached0[i] + acc[i];
          acc[i] = BCached1 * ACached1[i] + acc[i];
          acc[i] = BCached2 * ACached2[i] + acc[i];
          ${3===p?"":"acc[i] = BCached3 * ACached3[i] + acc[i];"}
        }`:`
        for (var i = 0; i < rowPerThread; i = i + 1) {
          let ACached = mm_Asub[tileRow + i][k];
          acc[i] = BCached0 * ACached.x + acc[i];
          acc[i] = BCached1 * ACached.y + acc[i];
          acc[i] = BCached2 * ACached.z + acc[i];
          ${3===p?"":"acc[i] = BCached3 * ACached.w + acc[i];"}
        }`}
      }

      workgroupBarrier();
  }

  for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      mm_write(batch, globalRow + innerRow, globalCol, acc[innerRow]);
  }
}`},iv=(e,t)=>e?`
            mm_Asub[inputRow][inputCol] = mm_readA(batch,
              kStart + inputRow,
              globalRowStart + inputCol${t?", batchIndices":""});
            `:`
            mm_Asub[inputRow][inputCol] = mm_readA(batch,
              globalRowStart + inputRow,
              kStart + inputCol${t?", batchIndices":""});
            `,iw=(e,t,r="f32",i,a=!1,n=32,s=!1,o=32,u=!1)=>{let l=e[1]*t[1],d=e[0]*t[0],p=a?l:n,c=a?n:l;if(c%t[1]!=0||p%t[0]!=0||n%t[1]!=0)throw Error(`tileAHight ${c} must be divisible by workgroupSize[1]${t[1]}, tileAWidth ${p} must be divisible by workgroupSize[0]${t[0]}, tileInner ${n} must be divisible by workgroupSize[1]${t[1]}`);let h=c/t[1],f=p/t[0],m=n/t[1],g=u?`
    let localRow = i32(localId.y);
    let localCol = i32(localId.x);
    let globalRowStart = i32(workgroupId.y) * ${l};
    let globalColStart = i32(workgroupId.x) * ${d};

    // Loop over shared dimension.
    for (var t = 0; t < num_tiles; t = t + 1) {
      // Load one tile of A into local memory.
      for (var inputRow = localRow; inputRow < ${c}; inputRow = inputRow + ${t[1]}) {
        for (var inputCol = localCol; inputCol < ${p}; inputCol = inputCol + ${t[0]}) {
          ${iv(a,i)}
        }
      }
      // Load one tile of B into local memory.
      for (var inputRow = localRow; inputRow < ${n}; inputRow = inputRow + ${t[1]}) {
            for (var inputCol = localCol; inputCol < ${d}; inputCol = inputCol + ${t[0]}) {
          mm_Bsub[inputRow][inputCol] = mm_readB(batch,
            kStart + inputRow,
            globalColStart + inputCol${i?", batchIndices":""});
        }
      }
      kStart = kStart + tileInner;
      workgroupBarrier();

      // Compute acc values for a single thread.
      var BCached : array<${r}, colPerThread>;
      for (var k = 0; k < tileInner; k = k + 1) {
        for (var inner = 0; inner < colPerThread; inner = inner + 1) {
          BCached[inner] = mm_Bsub[k][localCol + inner * ${t[0]}];
        }
        for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
          let ACached = ${a?`mm_Asub[k][localRow + innerRow * ${t[1]}];`:`mm_Asub[localRow + innerRow * ${t[1]}][k];`}
          for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
            acc[innerRow][innerCol] = acc[innerRow][innerCol] +
                ACached * BCached[innerCol];
          }
        }
      }
      workgroupBarrier();
    }
    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      let gRow = globalRowStart + localRow + innerRow * ${t[1]};
      for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
        let gCol = globalColStart + localCol + innerCol * ${t[0]};
        mm_write(batch, gRow, gCol, acc[innerRow][innerCol]);
      }
    }
    `:`
let tileRow = i32(localId.y) * rowPerThread;
let tileCol = i32(localId.x) * colPerThread;

let globalRow = i32(globalId.y) * rowPerThread;
let globalCol = i32(globalId.x) * colPerThread;
let globalRowStart = i32(workgroupId.y) * ${l};

let tileRowA = i32(localId.y) * ${h};
let tileColA = i32(localId.x) * ${f};
let tileRowB = i32(localId.y) * ${m};
// Loop over shared dimension.
for (var t = 0; t < num_tiles; t = t + 1) {
  // Load one tile of A into local memory.
  for (var innerRow = 0; innerRow < ${h}; innerRow = innerRow + 1) {
    for (var innerCol = 0; innerCol < ${f}; innerCol = innerCol + 1) {
      let inputRow = tileRowA + innerRow;
      let inputCol = tileColA + innerCol;
      ${iv(a,i)}
    }
  }

  // Load one tile of B into local memory.
  for (var innerRow = 0; innerRow < ${m}; innerRow = innerRow + 1) {
    for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
      let inputRow = tileRowB + innerRow;
      let inputCol = tileCol + innerCol;
      mm_Bsub[inputRow][inputCol] = mm_readB(batch,
        kStart + inputRow,
        globalCol + innerCol${i?", batchIndices":""});
    }
  }
  kStart = kStart + tileInner;
  workgroupBarrier();

  // Compute acc values for a single thread.
  var BCached : array<${r}, colPerThread>;
  for (var k = 0; k < tileInner; k = k + 1) {
    for (var inner = 0; inner < colPerThread; inner = inner + 1) {
      BCached[inner] = mm_Bsub[k][tileCol + inner];
    }

    for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
      ${a?"let ACached = mm_Asub[k][tileRow + innerRow];":"let ACached = mm_Asub[tileRow + innerRow][k];"}
      for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
        acc[innerRow][innerCol] = acc[innerRow][innerCol] + ACached * BCached[innerCol];
      }
    }
  }

  workgroupBarrier();
}

for (var innerRow = 0; innerRow < rowPerThread; innerRow = innerRow + 1) {
  for (var innerCol = 0; innerCol < colPerThread; innerCol = innerCol + 1) {
    mm_write(batch, globalRow + innerRow, globalCol + innerCol,
        acc[innerRow][innerCol]);
  }
}
`;return`
  var<workgroup> mm_Asub : array<array<${r}, ${p}>, ${c}>;
  var<workgroup> mm_Bsub : array<array<${r}, ${d}>, ${n}>;
  const rowPerThread = ${e[1]};
  const colPerThread = ${e[0]};
  const tileInner = ${n};

@compute @workgroup_size(${t[0]}, ${t[1]}, ${t[2]})
fn main(@builtin(local_invocation_id) localId : vec3<u32>,
        @builtin(global_invocation_id) globalId : vec3<u32>,
        @builtin(workgroup_id) workgroupId : vec3<u32>) {
    let batch = ${s?"0":"i32(globalId.z)"};
    ${i?`let batchIndices = ${i.offsetToIndices("u32(batch)")};`:""}
    let num_tiles = ${s?`${Math.ceil(o/n)}`:"(uniforms.dim_inner - 1) / tileInner + 1"};
    var kStart = ${s?`i32(globalId.z) * ${o}`:"0"};

    var acc : array<array<${r}, colPerThread>, rowPerThread>;
    ${g}
  }
`},ix=(e,t,r,i,a=!1,n)=>{let s=e[0].dims,o=e[1].dims,u=s.slice(0,-2),l=o.slice(0,-2),d=i?i.slice(0,-2):r.slice(0,-2),p=e2.size(d),c=s[s.length-2],h=s[s.length-1],f=o[o.length-1],m=h%4==0&&f%4==0,g=c<=8?[4,1,1]:[4,4,1],y=[8,8,1],_=[Math.ceil(f/y[0]/g[0]),Math.ceil(c/y[1]/g[1]),Math.ceil(p/y[2]/g[2])],b=m?4:1,$=[...u,c,h/b],v=$.length,w=[...l,h,f/b],x=w.length,k=[p,c,f/b],S=[{type:6,data:c},{type:6,data:f},{type:6,data:h}];ip(t,S),S.push(...tk(d,$,w));let T=["rank","rank"],I=e.length>2;return I&&(S.push(...tk(e[2].dims)),T.push("rank")),S.push(...tk(k)),{name:"MatMul",shaderCache:{hint:`${g};${t.activation};${m};${a}`,inputDependencies:T},getRunData:()=>({outputs:[{dims:n?n(r):r,dataType:e[0].dataType}],dispatchGroup:{x:_[0],y:_[1],z:_[2]},programUniforms:S}),getShaderSource:r=>{let i=d.length,n=tB("batchDims",e[0].dataType,i,1),s=tw(e[0].dataType),o=tA("a",e[0].dataType,v,b),u=tA("b",e[1].dataType,x,b),l=tO("result",e[0].dataType,k.length,b),p=[o,u];if(I){let t=a?b:1;p.push(tA("bias",e[2].dataType,e[2].dims.length,t))}let c=[{name:"dim_a_outer",type:"i32"},{name:"dim_b_outer",type:"i32"},{name:"dim_inner",type:"i32"}];ic(t,c);let h=tw(l.type.tensor),f=((e,t,r,i,a=!1)=>{let[n,s,o,u]=i,l=tw(i[0].type.tensor);return`
    fn mm_readA(batch: i32, row: i32, colIn: i32, batchIndices: ${n.type.indices}) -> ${im(e,l)} {
      var value = ${im(e,l)}(0.0);
      let col = colIn * ${e};
      if(row < uniforms.dim_a_outer && col < uniforms.dim_inner)
      {
        var aIndices: ${s.type.indices};
        ${i_("aIndices",s,s.rank-2,n.rank,"batchIndices")}
        ${s.indicesSet("aIndices",s.rank-2,"u32(row)")}
        ${s.indicesSet("aIndices",s.rank-1,"u32(colIn)")}
        value = ${s.getByIndices("aIndices")};
      }
      return value;
    }

    fn mm_readB(batch: i32, row: i32, colIn: i32, batchIndices: ${n.type.indices}) -> ${im(e,l)} {
      var value = ${im(e,l)}(0.0);
      let col = colIn * ${e};
      if(row < uniforms.dim_inner && col < uniforms.dim_b_outer)
      {
        var bIndices: ${o.type.indices};
        ${i_("bIndices",o,o.rank-2,n.rank,"batchIndices")}
        ${o.indicesSet("bIndices",o.rank-2,"u32(row)")}
        ${o.indicesSet("bIndices",o.rank-1,"u32(colIn)")}
        value = ${o.getByIndices("bIndices")};
      }
      return value;
    }

    fn mm_write(batch: i32, row: i32, colIn: i32, valueIn: ${im(e,l)}) {
      let col = colIn * ${e};
      if (row < uniforms.dim_a_outer && col < uniforms.dim_b_outer) {
        var value = valueIn;
        let coords = vec3<i32>(batch, row, colIn);
        ${t?`value = value + ${a?"bias[colIn]":`${im(e,l)}(bias[row])`};`:""}
        ${r}
        ${u.setByIndices("vec3<u32>(coords)","value")}
      }
    }
    `})(b,I,id(t,l.type.value,h),[n,o,u,l],a);return`
  ${r.registerUniforms(c).registerInternalVariables(n).declareVariables(...p,l)}
  ${f}
  ${m?i$(g,y,s,n):iw(g,y,s,n)}
                   `}}}}),nW=M(()=>{"use strict";nf(),ng(),nk(),nD(),nM(),nP(),nq(),ik=(e,t,r,i,a,n,s,o,u)=>{let l="NHWC"===t.format,d=l?e[0].dims[3]:e[0].dims[1],p=r[0],c=l?r[2]:r[3],h=l?r[1]:r[2],f=l?r[3]:r[1],m=l&&(d%4==0||d%3==0)&&f%4==0,g=l?f:c*h,y=l?c*h:f,_=[8,8,1],b=i<=8?[4,1,1]:[4,4,1],$=[Math.ceil(g/_[0]/b[0]),Math.ceil(y/_[1]/b[1]),Math.ceil(p/_[2]/b[2])];eY("verbose",()=>`[conv2d_mm_webgpu] dispatch = ${$}`);let v=m?l&&d%4!=0?3:4:1,w=_[1]*b[1],x=_[0]*b[0],k=Math.max(_[0]*v,_[1]),S=i%w==0,T=a%x==0,I=n%k==0,E=m?[v,4,4]:[1,1,1],C=[{type:6,data:i},{type:6,data:a},{type:6,data:n},{type:6,data:[t.pads[0],t.pads[1]]},{type:6,data:t.strides},{type:6,data:t.dilations}];ip(t,C),C.push(...tk(e[0].dims,e[1].dims));let z=["rank","rank"];return s&&(C.push(...tk(e[2].dims)),z.push("rank")),C.push(...tk(r)),{name:"Conv2DMatMul",shaderCache:{hint:`${t.cacheKey};${v};${m};${S};${T};${I};${w};${x};${k}`,inputDependencies:z},getRunData:()=>({outputs:[{dims:u?u(r):r,dataType:e[0].dataType}],dispatchGroup:{x:$[0],y:$[1],z:$[2]},programUniforms:C}),getShaderSource:i=>{let a=[{name:"dim_a_outer",type:"i32"},{name:"dim_b_outer",type:"i32"},{name:"dim_inner",type:"i32"},{name:"pad",type:"i32",length:2},{name:"stride",type:"i32",length:2},{name:"dilation",type:"i32",length:2}];ic(t,a);let n=m?4:1,u=tw(e[0].dataType),d=`
      fn setOutputAtIndex(flatIndex : i32, value : ${m?`vec4<${u}>`:u}) {
        result[flatIndex] = ${m?`vec4<${u}>`:u}(value);
      }
      fn setOutputAtCoords(d0 : i32, d1 : i32, d2 : i32, d3 : i32, value : ${m?`vec4<${u}>`:u}) {
        let flatIndex = getOutputIndexFromCoords(vec4<i32>(d0, d1, d2, d3));
        setOutputAtIndex(flatIndex ${m?"/ 4":""}, value);
      }`,p=[tA("x",e[0].dataType,e[0].dims.length,3===v?1:v),tA("w",e[1].dataType,e[1].dims.length,n)],c=tO("result",e[0].dataType,r.length,n);if(s){let t=tA("bias",e[2].dataType,e[2].dims.length,n);p.push(t),d+=`
        fn getBiasByOutputCoords(coords : vec4<i32>) -> ${m?`vec4<${u}>`:u} {
          return bias[coords.${l?"w":"y"}${m?"/ 4":""}];
        }`}return`
        ${iy("uniforms.result_strides")}
        //struct Uniforms { xShape : vec4<i32>, wShape : vec4<i32>, outShape : vec4<i32>,
        //  outShapeStrides: vec3<i32>, filterDims : vec2<i32>, pad : vec2<i32>, stride : vec2<i32>,
        //  dilation : vec2<i32>, dimAOuter : i32, dimBOuter : i32, dimInner : i32 };
        ${i.registerUniforms(a).declareVariables(...p,c)}
        ${d}
        ${((e,t,r,i,a=!1,n,s=4,o=4,u=4,l="f32")=>{let d=e=>{switch(e){case 1:return"return w[row * i32(uniforms.w_shape[3]) + colIn];";case 4:return"return w[row * i32(uniforms.w_shape[3]) / 4 + colIn];";default:throw Error(`innerElementSize ${e} is not supported.`)}},p=e?`
    let coord = vec4<i32>(batch, xRow, xCol, xCh);
    `:`
    let coord = vec4<i32>(batch, xCh, xRow, xCol);
    `,c=e?`
    let coords = vec4<i32>(
      batch,
      row / outWidth,
      row % outWidth,
      col);
    `:`
    let coords = vec4<i32>(
      batch,
      row,
      col / outWidth,
      col % outWidth);
    `,h=e?"row":"col",f=e?"col":"row",m=`
    let inChannels = i32(uniforms.w_shape[2]);
    let outWidth = ${e?"i32(uniforms.result_shape[2])":"i32(uniforms.result_shape[3])"};
    let outRow = ${h} / outWidth;
    let outCol = ${h} % outWidth;

    let WRow = ${f} / (i32(uniforms.w_shape[1]) * inChannels);
    let WCol = ${f} / inChannels % i32(uniforms.w_shape[1]);
    let xRow = outRow * uniforms.stride[0] + uniforms.dilation[0] * WRow - uniforms.pad[0];
    let xCol = outCol * uniforms.stride[1] + uniforms.dilation[1] * WCol - uniforms.pad[1];
    let xCh = ${f} % inChannels;
    var resData = ${im(s,l)}(0.0);
    // The bounds checking is always needed since we use it to pad zero for
    // the 'same' padding type.
    if (xRow >= 0 && xRow < ${e?"i32(uniforms.x_shape[1])":"i32(uniforms.x_shape[2])"} && xCol >= 0 && xCol < ${e?"i32(uniforms.x_shape[2])":"i32(uniforms.x_shape[3])"}) {
      ${p}
      let xIndex = getIndexFromCoords4D(coord, vec4<i32>(uniforms.x_shape));
      ${(e=>{switch(e){case 1:return"resData = x[xIndex];";case 3:return`resData = vec3<${l}>(x[xIndex], x[xIndex + 1], x[xIndex + 2]);`;case 4:return"resData = x[xIndex / 4];";default:throw Error(`innerElementSize ${e} is not supported.`)}})(s)}
    }
    return resData;`,g=e?t&&i?`
    let col = colIn * ${s};
    ${m}`:`
    let col = colIn * ${s};
    if (row < uniforms.dim_a_outer && col < uniforms.dim_inner) {
      ${m}
    }
    return ${im(s,l)}(0.0);`:i&&r?`
    let col = colIn * ${s};
    ${m}`:`
    let col = colIn * ${s};
    if (row < uniforms.dim_inner && col < uniforms.dim_b_outer) {
      ${m}
    }
    return ${im(s,l)}(0.0);`,y=e?i&&r?d(o):`
    let col = colIn * ${o};
    if (row < uniforms.dim_inner && col < uniforms.dim_b_outer) {
      ${d(o)}
    }
    return ${im(o,l)}(0.0);`:`
    let col = colIn * ${o};
    if (row < uniforms.dim_inner && col < uniforms.dim_a_outer) {
      ${d(o)}
    }
    return ${im(o,l)}(0.0);`,_=im(u,l),b=e?im(s,l):im(o,l),$=e?im(o,l):im(s,l),v=id(n,_,l);return`
    fn mm_readA(batch: i32, row : i32, colIn : i32) -> ${b} {
      ${e?g:y}
    }

    fn mm_readB(batch: i32, row : i32, colIn : i32) -> ${$} {
      ${e?y:g}
    }

    fn mm_write(batch: i32, row : i32, colIn : i32, valueIn : ${_}) {
      let col = colIn * ${u};
      if (row < uniforms.dim_a_outer && col < uniforms.dim_b_outer)
      {
      var value = valueIn;
      let outWidth = ${e?"i32(uniforms.result_shape[2])":"i32(uniforms.result_shape[3])"};
      ${c}
      ${ig(a)}
      ${v}
      setOutputAtCoords(coords[0], coords[1], coords[2], coords[3], value);
      }
    }`})(l,S,T,I,s,t,E[0],E[1],E[2],u)}
        ${m?i$(b,_,u,void 0,!l,k):iw(b,_,u,void 0,!l,k,!1,void 0,o)}`}}}}),nL=M(()=>{"use strict";nf(),ng(),ny(),nk(),nD(),nM(),iS=e=>"number"==typeof e?[e,e,e]:e,iT=(e,t)=>t<=1?e:e+(e-1)*(t-1),iI=(e,t,r,i,a)=>{null==a&&(a=((e,t,r,i=1)=>{let a=iT(t,i);return Math.floor((e[0]*(r-1)-r+a)/2)})(e,t[0],i[0]));let n=[0,0,0,r];for(let r=0;r<3;r++)e[r]+2*a>=t[r]&&(n[r]=Math.trunc((e[r]-t[r]+2*a)/i[r]+1));return n},iE=(e,t,r,i,a,n=!1,s="channelsLast")=>{let o,u,l,d,p;if("channelsLast"===s)[o,u,l,d,p]=e;else if("channelsFirst"===s)[o,p,u,l,d]=e;else throw Error(`Unknown dataFormat ${s}`);let[c,,h,f,m]=t,[g,y,_]=iS(r),[b,$,v]=iS(i),w=iT(h,b),x=iT(f,$),k=iT(m,v),{padInfo:S,outDepth:T,outHeight:I,outWidth:E}=((e,t,r,i,a,n,s,o,u,l)=>{let d,p,c,h;if("VALID"===e&&(e=0),"number"==typeof e){d={top:e,bottom:e,left:e,right:e,front:e,back:e};let f=iI([t,r,i,1],[o,u,l],1,[a,n,s],e);p=f[0],c=f[1],h=f[2]}else if(Array.isArray(e)){if(!e.every((e,t,r)=>e===r[0]))throw Error(`Unsupported padding parameter: ${e}`);d={top:e[0],bottom:e[1],left:e[2],right:e[3],front:e[4],back:e[5]};let f=iI([t,r,i,1],[o,u,l],1,[a,n,s],e[0]);p=f[0],c=f[1],h=f[2]}else if("SAME_UPPER"===e){p=Math.ceil(t/a),c=Math.ceil(r/n),h=Math.ceil(i/s);let e=(p-1)*a+o-t,f=(c-1)*n+u-r,m=(h-1)*s+l-i,g=Math.floor(e/2),y=Math.floor(f/2),_=Math.floor(m/2);d={top:y,bottom:f-y,left:_,right:m-_,front:g,back:e-g}}else throw Error(`Unknown padding parameter: ${e}`);return{padInfo:d,outDepth:p,outHeight:c,outWidth:h}})(a,u,l,d,g,y,_,w,x,k),C=n?c*p:c,z=[0,0,0,0,0];return"channelsFirst"===s?z=[o,C,T,I,E]:"channelsLast"===s&&(z=[o,T,I,E,C]),{batchSize:o,dataFormat:s,inDepth:u,inHeight:l,inWidth:d,inChannels:p,outDepth:T,outHeight:I,outWidth:E,outChannels:C,padInfo:S,strideDepth:g,strideHeight:y,strideWidth:_,filterDepth:h,filterHeight:f,filterWidth:m,effectiveFilterDepth:w,effectiveFilterHeight:x,effectiveFilterWidth:k,dilationDepth:b,dilationHeight:$,dilationWidth:v,inShape:e,outShape:z,filterShape:t}},iC=(e,t,r,i,a,n)=>{let s="channelsLast"===n,o=(s?e[0].dims[3]:e[0].dims[1],[Math.ceil((e=>{let t=1;for(let r=0;r<e.length;r++)t*=e[r];return t})(({x:r.map((e,t)=>t)}).x.map(e=>r[e]))/64),1,1]);eY("verbose",()=>`[conv3d_naive_webgpu] dispatch = ${o}`);let u=[{type:12,data:e2.size(r)},{type:12,data:i},{type:12,data:a},{type:12,data:t.strides},{type:12,data:t.dilations}];ip(t,u),u.push(...tk(e[0].dims,e[1].dims));let l=["rank","rank"],d=3===e.length;return d&&(u.push(...tk(e[2].dims)),l.push("rank")),u.push(...tk(r)),{name:"Conv3DNaive",shaderCache:{hint:`${t.cacheKey};${s};1;${d}`,inputDependencies:l},getRunData:()=>({outputs:[{dims:r,dataType:e[0].dataType}],dispatchGroup:{x:o[0],y:o[1],z:o[2]},programUniforms:u}),getShaderSource:n=>{let o=[{name:"output_size",type:"u32"},{name:"filter_dims",type:"u32",length:i.length},{name:"pads",type:"u32",length:a.length},{name:"strides",type:"u32",length:t.strides.length},{name:"dilations",type:"u32",length:t.dilations.length}];ic(t,o);let u=tw(e[0].dataType),l=tA("x",e[0].dataType,e[0].dims.length,1),p=tA("W",e[1].dataType,e[1].dims.length,1),c=[l,p],h=tO("result",e[0].dataType,r.length,1),f="";if(d){let t=tA("bias",e[2].dataType,e[2].dims.length,1);c.push(t),f+=`
        fn getBiasByOutputCoords(coords : array<u32, 5>) -> ${u} {
          return bias[${s?tC("coords",4,5):tC("coords",1,5)}];
        }`}let m=im(1,u),g=id(t,m,u);return`
            ${f}
            fn getX(d0 : u32, d1 : u32, d2 : u32, d3 : u32, d4 : u32) -> f32 {
              let aIndices = array<u32, 5>(d0, d1, d2, d3, d4);
              return ${l.getByIndices("aIndices")};
            }
            fn getW(d0 : u32, d1 : u32, d2 : u32, d3 : u32, d4 : u32) -> f32 {
              let aIndices = array<u32, 5>(d0, d1, d2, d3, d4);
              return ${p.getByIndices("aIndices")};
            }
          ${n.registerUniforms(o).declareVariables(...c,h)}
          ${n.mainStart()}
          ${n.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
              let coords = ${h.offsetToIndices("global_idx")};
              let batch = ${tC("coords",0,l.rank)};
              let d2 = ${s?tC("coords",l.rank-1,l.rank):tC("coords",1,l.rank)};
              let xFRCCorner = vec3<u32>(${s?tC("coords",1,l.rank):tC("coords",2,l.rank)},
              ${s?tC("coords",2,l.rank):tC("coords",3,l.rank)},
              ${s?tC("coords",3,l.rank):tC("coords",4,l.rank)}) * uniforms.strides - uniforms.pads;
              let xFCorner = xFRCCorner.x;
              let xRCorner = xFRCCorner.y;
              let xCCorner = xFRCCorner.z;
              let xShapeY = ${s?tC("uniforms.x_shape",1,l.rank):tC("uniforms.x_shape",2,l.rank)};
              let xShapeZ = ${s?tC("uniforms.x_shape",2,l.rank):tC("uniforms.x_shape",3,l.rank)};
              let xShapeW = ${s?tC("uniforms.x_shape",3,l.rank):tC("uniforms.x_shape",4,l.rank)};
              let xShapeU = ${s?tC("uniforms.x_shape",4,l.rank):tC("uniforms.x_shape",1,l.rank)};
              let inputDepthNearestVec4 = (xShapeU / 4) * 4;
              let inputDepthVec4Remainder = xShapeU % 4;

              var value = 0.0;
              for (var wF = 0u; wF < uniforms.filter_dims[0]; wF++) {
                let xF = xFCorner + wF * uniforms.dilations[0];
                if (xF < 0 || xF >= xShapeY) {
                  continue;
                }

                for (var wR = 0u; wR < uniforms.filter_dims[1]; wR++) {
                  let xR = xRCorner + wR * uniforms.dilations[1];
                  if (xR < 0 || xR >= xShapeZ) {
                    continue;
                  }

                  for (var wC = 0u; wC < uniforms.filter_dims[2]; wC++) {
                    let xC = xCCorner + wC * uniforms.dilations[2];
                    if (xC < 0 || xC >= xShapeW) {
                      continue;
                    }

                    for (var d1 = 0u; d1 < inputDepthNearestVec4; d1 += 4) {
                      ${s?`let xValues = vec4<f32>(
                               getX(batch, xF, xR, xC, d1),
                               getX(batch, xF, xR, xC, d1 + 1),
                               getX(batch, xF, xR, xC, d1 + 2),
                               getX(batch, xF, xR, xC, d1 + 3));
                            `:`let xValues = vec4<f32>(
                               getX(batch, d1, xF, xR, xC),
                               getX(batch, d1 + 1, xF, xR, xC),
                               getX(batch, d1 + 2, xF, xR, xC),
                               getX(batch, d1 + 3, xF, xR, xC));
                            `}
                            let wValues = vec4<f32>(
                              getW(d2, d1, wF, wR, wC),
                              getW(d2, d1 + 1, wF, wR, wC),
                              getW(d2, d1 + 2, wF, wR, wC),
                              getW(d2, d1 + 3, wF, wR, wC));
                      value += dot(xValues, wValues);
                    }
                    if (inputDepthVec4Remainder == 1) {
                        ${s?`value += getX(batch, xF, xR, xC, inputDepthNearestVec4)
                          * getW(d2, inputDepthNearestVec4, wF, wR, wC);`:`value += getX(batch, inputDepthNearestVec4, xF, xR, xC)
                          * getW(d2, inputDepthNearestVec4, wF, wR, wC);`}
                    } else if (inputDepthVec4Remainder == 2) {
                      ${s?`let xValues = vec2<f32>(
                        getX(batch, xF, xR, xC, inputDepthNearestVec4),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 1));
                      `:`let xValues = vec2<f32>(
                        getX(batch, inputDepthNearestVec4, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 1, xF, xR, xC));
                    `}
                    let wValues = vec2<f32>(
                      getW(d2, inputDepthNearestVec4, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 1, wF, wR, wC));
                      value += dot(xValues, wValues);
                    } else if (inputDepthVec4Remainder == 3) {
                      ${s?`let xValues = vec3<f32>(
                        getX(batch, xF, xR, xC, inputDepthNearestVec4),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 1),
                        getX(batch, xF, xR, xC, inputDepthNearestVec4 + 2));
                      `:`let xValues = vec3<f32>(
                        getX(batch, inputDepthNearestVec4, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 1, xF, xR, xC),
                        getX(batch, inputDepthNearestVec4 + 2, xF, xR, xC));
                    `}
                    let wValues = vec3<f32>(
                      getW(d2, inputDepthNearestVec4, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 1, wF, wR, wC),
                      getW(d2, inputDepthNearestVec4 + 2, wF, wR, wC));
                      value += dot(xValues, wValues);
                    }
                  }
                }
              }
              ${d?"value = value + getBiasByOutputCoords(coords)":""};
              ${g}
              result[global_idx] = f32(value);
          }`}}}}),nV=M(()=>{"use strict";nf(),ny(),nk(),nD(),iz=(e,t,r,i)=>{let a=e.length>2,n=a?"value += b[output_channel];":"",s=e[0].dims,o=e[1].dims,u="NHWC"===t.format,l=u?r[3]:r[1],d=l/t.group,p=u&&d>=4?tS(l):1,c=e2.size(r)/p,h=[{type:12,data:c},{type:12,data:t.dilations},{type:12,data:[t.strides[0],t.strides[1]]},{type:12,data:[t.pads[0],t.pads[1]]},{type:12,data:d}];return ip(t,h),h.push(...tk(s,[o[0],o[1],o[2],o[3]/p])),h.push(...tk([r[0],r[1],r[2],r[3]/p])),{name:"GroupedConv",shaderCache:{hint:`${t.cacheKey}_${p}`,inputDependencies:a?["rank","rank","rank"]:["rank","rank"]},getRunData:()=>({outputs:[{dims:i?i(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(c/64)},programUniforms:h}),getShaderSource:i=>{let l=tO("output",e[0].dataType,r.length,p),d=tw(l.type.tensor),c=id(t,l.type.value,d),h=tA("x",e[0].dataType,s.length),f=tA("w",e[1].dataType,o.length,p),m=[h,f];a&&m.push(tA("b",e[2].dataType,e[2].dims,p));let g=[{name:"output_size",type:"u32"},{name:"dilations",type:"u32",length:t.dilations.length},{name:"strides",type:"u32",length:2},{name:"pads",type:"u32",length:2},{name:"output_channels_per_group",type:"u32"}];ic(t,g);let y=u?`
      for (var wHeight: u32 = 0u; wHeight < uniforms.w_shape[0]; wHeight++) {
        let xHeight = xRCCorner.x + wHeight * uniforms.dilations[0];

        if (xHeight < 0u || xHeight >= uniforms.x_shape[1]) {
          continue;
        }

        for (var wWidth: u32 = 0u; wWidth < uniforms.w_shape[1]; wWidth++) {
          let xWidth = xRCCorner.y + wWidth * uniforms.dilations[1];
          if (xWidth < 0u || xWidth >= uniforms.x_shape[2]) {
            continue;
          }

          for (var wInChannel: u32 = 0u; wInChannel < uniforms.w_shape[2]; wInChannel++) {
            let input_channel = in_channel_offset + wInChannel;
            let xVal = ${h.get("batch","xHeight","xWidth","input_channel")};
            let wVal = ${f.get("wHeight","wWidth","wInChannel","output_channel")};
            value += xVal * wVal;
          }
        }
      }
      `:`
      for (var wInChannel: u32 = 0u; wInChannel < uniforms.w_shape[1]; wInChannel++) {
        let input_channel = in_channel_offset + wInChannel;
        for (var wHeight: u32 = 0u; wHeight < uniforms.w_shape[2]; wHeight++) {
          let xHeight = xRCCorner.x + wHeight * uniforms.dilations[0];

          if (xHeight < 0u || xHeight >= uniforms.x_shape[2]) {
            continue;
          }

          for (var wWidth: u32 = 0u; wWidth < uniforms.w_shape[3]; wWidth++) {
            let xWidth = xRCCorner.y + wWidth * uniforms.dilations[1];
            if (xWidth < 0u || xWidth >= uniforms.x_shape[3]) {
              continue;
            }

            let xVal = ${h.get("batch","input_channel","xHeight","xWidth")};
            let wVal = ${f.get("output_channel","wInChannel","wHeight","wWidth")};
            value += xVal * wVal;
          }
        }
      }
      `;return`
  ${i.registerUniforms(g).declareVariables(...m,l)}

  ${i.mainStart()}
    ${i.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let outputIndices = ${l.offsetToIndices("global_idx")};
    let batch: u32 = outputIndices[0];
    let output_channel: u32 = outputIndices[${u?3:1}];
    let xRCCorner: vec2<u32> = vec2<u32>(outputIndices[${u?1:2}], outputIndices[${u?2:3}]) * uniforms.strides - uniforms.pads;
    let group_id: u32 = output_channel * ${p} / uniforms.output_channels_per_group;
    var in_channel_offset = group_id * uniforms.w_shape[${u?2:1}];

    var value: ${l.type.value} = ${l.type.value}(0);
    ${y}
    ${n}
    ${c}
    ${l.setByOffset("global_idx","value")}
  }`}}},iA=(e,t,r,i)=>{let a=e.length>2,n=tS(r[3]),s=tS(r[2]),o=e2.size(r)/n/s,u=[e[0].dims[0],e[0].dims[1],e[0].dims[2],e[0].dims[3]/n],l=[e[1].dims[0],e[1].dims[1],e[1].dims[2],e[1].dims[3]/n],d=[r[0],r[1],r[2],r[3]/n],p=[{type:12,data:o},{type:6,data:[t.strides[0],t.strides[1]]},{type:6,data:[t.pads[0],t.pads[1]]}];ip(t,p),p.push(...tk(u,l,d));let c=(s-1)*t.strides[1]+l[1];return{name:"GroupedConv-Vectorize",shaderCache:{hint:`${t.cacheKey};${n};${s};${c};${l[0]};${l[1]}`,inputDependencies:a?["rank","rank","type"]:["rank","rank"]},getRunData:()=>({outputs:[{dims:i?i(r):r,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(o/64)},programUniforms:p}),getShaderSource:r=>{let i=tO("output",e[0].dataType,d.length,n),o=tw(i.type.tensor),p=id(t,i.type.value,o),h=tA("x",e[0].dataType,u.length,n),f=tA("w",e[1].dataType,l.length,n),m=[h,f];a&&m.push(tA("b",e[2].dataType,e[2].dims,n));let g=[{name:"output_size",type:"u32"},{name:"strides",type:"i32",length:2},{name:"pads",type:"i32",length:2}];return ic(t,g),`
  ${r.registerUniforms(g).declareVariables(...m,i)}
  ${r.mainStart()}
    ${r.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let width0 = uniforms.output_shape[3];
    let output_channel = global_idx % width0;
    var index1 = global_idx / width0;
    let width1 = uniforms.output_shape[2] / ${s}u;
    let col = (index1 % width1) * ${s}u;
    index1 = index1 / width1;
    let row = index1 % uniforms.output_shape[1];
    let batch = index1 / uniforms.output_shape[1];

    let x_corner = vec2<i32>(i32(row), i32(col)) * uniforms.strides - uniforms.pads;

    var x_vals: array<${h.type.value}, ${c}>;
    var values: array<${i.type.value}, ${s}>;
    let input_channel = output_channel;
    // Use constant instead of uniform can give better performance for w's height/width.
    for (var w_height: u32 = 0u; w_height < ${l[0]}; w_height++) {
      let x_height = x_corner.x + i32(w_height);
      if (x_height >= 0 && u32(x_height) < uniforms.x_shape[1]) {
        for (var i = 0; i < ${c}; i++) {
          let x_width = x_corner.y + i;
          if (x_width >= 0 && u32(x_width) < uniforms.x_shape[2]) {
            x_vals[i] = ${h.get("batch","u32(x_height)","u32(x_width)","input_channel")};
          } else {
            x_vals[i] = ${h.type.value}(0);
          }
        }
        for (var w_width: u32 = 0u; w_width < ${l[1]}; w_width++) {
          let w_val = ${f.get("w_height","w_width","0","output_channel")};
          for (var i = 0u; i < ${s}u; i++) {
            values[i] = fma(x_vals[i * u32(uniforms.strides[1]) + w_width], w_val, values[i]);
          }
        }
      }
    }

    for (var i = 0u; i < ${s}u; i++) {
      var value = values[i];
      ${a?"value += b[output_channel];":""}
      ${p}
      ${i.set("batch","row","col + i","output_channel","value")};
    }
  }`}}}}),nG=M(()=>{"use strict";ny(),nW(),nL(),nq(),nV(),nD(),nU(),nS(),iO=[2,3,1,0],iR=(e,t)=>{let r=e.kernelShape.slice();r.length<t[1].dims.length-2&&r.push(...Array(t[1].dims.length-2-r.length).fill(0));for(let e=2;e<t[1].dims.length;++e)0===r[e-2]&&(r[e-2]=t[1].dims[e]);let i=e.pads.slice();e1.adjustPadsBasedOnAutoPad(t[0].dims,e.strides,e.dilations,r,i,"NHWC"===e.format,e.autoPad);let a=Object.assign({},e);return Object.assign(a,{kernelShape:r,pads:i}),a},iB=e=>{let t=ih(e),r=e.format;return{autoPad:["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][e.auto_pad],format:r,dilations:e.dilations,group:e.group,kernelShape:e.kernel_shape,pads:e.pads,strides:e.strides,wIsConst:e.w_is_const(),...t,cacheKey:`${e.format};${t.activation};`}},iN=(e,t,r,i)=>{var a,n,s,o,u,l;let d,p,c,h,f,m,g="NHWC"===r.format,y=(a=t[0].dims,n=t[1].dims,s=r.dilations,o=r.pads,u=r.strides,l=g,d=a[0],c=(p=a.slice(l?1:2,l?3:4)).length,h=n[0],f=n.slice(2).map((e,t)=>e+(e-1)*(s[t]-1)),(m=p.map((e,t)=>e+o[t]+o[t+c]).map((e,t)=>Math.floor((e-f[t]+u[t])/u[t]))).splice(0,0,d),m.splice(l?3:1,0,h),m);if(1!==r.group){let a=[t[0]];if(g){let i=e.kernelCustomData.wT??e.compute(tP(t[1],iO),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=i),a.push(i)}else a.push(t[1]);3===t.length&&a.push(t[2]),!e.adapterInfo.isArchitecture("ampere")&&g&&t[1].dims[0]===r.group&&1===t[1].dims[1]&&1===r.dilations[0]&&1===r.dilations[1]?e.compute(iA(a,r,y,i),{inputs:a}):e.compute(iz(a,r,y,i),{inputs:a});return}let _=3===t.length,b=t[0].dims[g?1:2],$=t[0].dims[g?2:3],v=t[0].dims[g?3:1],w=t[1].dims[2],x=t[1].dims[3],k=y[g?1:2],S=y[g?2:3],T=y[g?3:1],I=g&&w===b&&x===$&&0===r.pads[0]&&0===r.pads[1];if(I||1===w&&1===x&&1===r.dilations[0]&&1===r.dilations[1]&&1===r.strides[0]&&1===r.strides[1]&&0===r.pads[0]&&0===r.pads[1]){let a=y[0],n,s,o,u=[];if(g){let i=e.kernelCustomData.wT??e.compute(tP(t[1],iO),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];if(r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=i),I){let e=b*$*v;n=t[0].reshape([1,a,e]),s=i.reshape([1,e,T]),o=[1,a,T]}else n=t[0].reshape([a,b*$,v]),s=i.reshape([1,v,T]),o=[a,k*S,T];u.push(n),u.push(s)}else n=t[0].reshape([a,v,b*$]),s=t[1].reshape([1,T,v]),o=[a,T,k*S],u.push(s),u.push(n);_&&u.push(t[2]);let l=o[2],d=u[0].dims[u[0].dims.length-1];l<8&&d<8?e.compute(ib(u,r,y,o,g,i),{inputs:u}):e.compute(ix(u,r,y,o,g,i),{inputs:u});return}let E=e.kernelCustomData.wT??e.compute(tP(t[1],iO),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=E);let C=[t[0],E];_&&C.push(t[2]);let z=g?k*S:T,A=g?T:k*S,O=w*x*v;e.compute(ik(C,r,y,z,A,O,_,!0,i),{inputs:C})},iD=(e,t)=>{var r,i,a,n,s;if(((e,t)=>{if(!e||2!==e.length&&3!==e.length)throw Error("Conv requires 2 or 3 inputs");if(e[0].dims.length>5)throw Error("greater than 5D is not supported");if(e[0].dims.length!==e[1].dims.length)throw Error("filter does not have same dimension as input");if(e[0].dims["NHWC"===t.format?e[0].dims.length-1:1]!==e[1].dims[1]*t.group)throw Error("FILTER_IN_CHANNEL should be equal to DATA_CHANNEL");if(3===e.length&&(1!==e[2].dims.length||e[1].dims[0]!==e[2].dims[0]))throw Error("invalid bias");let r=e[0].dims.length-2;if(t.dilations.length!==r)throw Error(`dilations should be ${r}D`);if(t.strides.length!==r)throw Error(`strides should be ${r}D`);if(t.pads.length!==2*r)throw Error(`pads should be ${2*r}D`);if(0!==t.kernelShape.length&&t.kernelShape.length!==e[1].dims.length-2)throw Error("invalid kernel shape")})(e.inputs,t),3===e.inputs[0].dims.length){let a,n,s,o,u,l,d;r=e,a="NHWC"===(i=t).format,n=[r.inputs[0].reshape(a?[r.inputs[0].dims[0],1,r.inputs[0].dims[1],r.inputs[0].dims[2]]:[r.inputs[0].dims[0],r.inputs[0].dims[1],1,r.inputs[0].dims[2]]),r.inputs[1].reshape([r.inputs[1].dims[0],r.inputs[1].dims[1],1,r.inputs[1].dims[2]])],3===r.inputs.length&&n.push(r.inputs[2]),s=[0,i.pads[0],0,i.pads[1]],o=[1].concat(i.strides),u=[1].concat(i.dilations),l=[1].concat(i.kernelShape),d=iR({...i,pads:s,strides:o,dilations:u,kernelShape:l},n),iN(r,n,d,e=>a?[e[0],e[2],e[3]]:[e[0],e[1],e[3]])}else if(5===e.inputs[0].dims.length){let r,i,o,u;a=e,n=e.inputs,r="NHWC"===(s=t).format?"channelsLast":"channelsFirst",i=iR(s,n),o="NOTSET"===s.autoPad?s.pads:s.autoPad,u=iE(n[0].dims,n[1].dims,s.strides,s.dilations,o,!1,r),a.compute(iC(n,i,u.outShape,[u.filterDepth,u.filterHeight,u.filterWidth],[u.padInfo.front,u.padInfo.top,u.padInfo.left],r))}else{let r=iR(t,e.inputs);iN(e,e.inputs,r)}}}),nH=M(()=>{"use strict";nf(),ng(),ny(),nk(),iM=(e,t,r)=>{let i=e.length>2,a=t.outputShape,n="NHWC"===t.format,s=t.group,o=e[1].dims,u=o[2]/s,l=o[3],d=n?tS(u):1,p=n&&1===l&&u>=4,c=p?4*Math.floor(u/4):Math.floor(u/d)*d,h=u-c,f=n?tS(l):1,m=n?1===l?d:f:1,g=e2.size(a)/f,y=[Math.ceil(g/64),1,1];eY("verbose",()=>`[conv2d_backprop_webgpu] dispatch = ${y}`);let _=["rank","rank"],b=[t.strides[0],t.strides[1]],$=[t.kernelShape[n?1:2],t.kernelShape[n?2:3]],v=[t.dilations[0],t.dilations[1]],w=[$[0]+(t.dilations[0]<=1?0:(t.kernelShape[n?1:2]-1)*(t.dilations[0]-1)),$[1]+(t.dilations[1]<=1?0:(t.kernelShape[n?2:3]-1)*(t.dilations[1]-1))],x=[w[0]-1-Math.floor((t.pads[0]+t.pads[2])/2),w[1]-1-Math.floor((t.pads[1]+t.pads[3])/2)],k=[{type:12,data:g},{type:12,data:b},{type:12,data:$},{type:12,data:v},{type:12,data:w},{type:6,data:x},{type:12,data:c},{type:12,data:u},{type:12,data:l},...tk(e[0].dims,e[1].dims)];return i&&(k.push(...tk(e[2].dims)),_.push("rank")),k.push(...tk(a)),{name:"ConvTranspose2D",shaderCache:{hint:`${t.cacheKey};${d}${m}${f}${p}${h}`,inputDependencies:_},getRunData:()=>({dispatchGroup:{x:y[0],y:y[1],z:y[2]},outputs:[{dims:r?r(a):a,dataType:e[0].dataType}],programUniforms:k}),getShaderSource:t=>{let r=[{name:"output_size",type:"u32"},{name:"strides",type:"u32",length:b.length},{name:"filter_dims",type:"u32",length:$.length},{name:"dilations",type:"u32",length:$.length},{name:"effective_filter_dims",type:"u32",length:w.length},{name:"pads",type:"i32",length:x.length},{name:"input_channels_per_group_int",type:"u32"},{name:"input_channels_per_group",type:"u32"},{name:"output_channels_per_group",type:"u32"}],s=tw(e[0].dataType),o=n?1:2,u=n?2:3,l=n?3:1,c=tA("W",e[1].dataType,e[1].dims.length,m),g=tA("Dy",e[0].dataType,e[0].dims.length,d),y=[g,c];i&&y.push(tA("bias",e[2].dataType,[a[l]].length,f));let _=tO("result",e[0].dataType,a.length,f),v=`
            let outputIndices = ${_.offsetToIndices(`global_idx * ${f}`)};
            let batch = ${_.indicesGet("outputIndices",0)};
            let d1 = ${_.indicesGet("outputIndices",l)};
            let r = ${_.indicesGet("outputIndices",o)};
            let c = ${_.indicesGet("outputIndices",u)};
            let dyCorner = vec2<i32>(i32(r), i32(c)) - uniforms.pads;
            let dyRCorner = dyCorner.x;
            let dyCCorner = dyCorner.y;
            let groupId = d1 / uniforms.output_channels_per_group;
            let wOutChannel = d1 - groupId * uniforms.output_channels_per_group;
            // Convolve dy(?, ?, d2) with w(:, :, d1, d2) to compute dx(xR, xC, d1).
            // ? = to be determined. : = across all values in that axis.
            var dotProd = ${_.type.value}(0.0);
            var wR: u32 = 0;
            if (uniforms.dilations.x == 1) {
              // Minimum wR >= 0 that satisfies (dyRCorner + wR) % (uniforms.strides.x) == 0
              wR = u32(((dyRCorner + i32(uniforms.strides.x) - 1) / i32(uniforms.strides.x)) * i32(uniforms.strides.x) - dyRCorner);
            }
            for (; wR < uniforms.effective_filter_dims.x; wR = wR + 1) {
              if (wR % uniforms.dilations.x != 0) {
                continue;
              }
              let dyR = (${s}(dyRCorner) + ${s}(wR)) / ${s}(uniforms.strides[0]);
              let wRPerm = uniforms.filter_dims.x - 1 - wR / uniforms.dilations.x;
              if (dyR < 0.0 || dyR >= ${s}(uniforms.Dy_shape[${o}]) || fract(dyR) > 0.0 ||
                  wRPerm < 0) {
                continue;
              }
              let idyR: u32 = u32(dyR);
              var wC: u32 = 0;
              if (uniforms.dilations.y == 1) {
                // Minimum wC >= 0 that satisfies (dyCCorner + wC) % (uniforms.strides.y) == 0
                wC = u32(((dyCCorner + i32(uniforms.strides.y) - 1) / i32(uniforms.strides.y)) * i32(uniforms.strides.y) - dyCCorner);
              }
              for (; wC < uniforms.effective_filter_dims.y; wC = wC + 1) {
                if (wC % uniforms.dilations.y != 0) {
                  continue;
                }
                let dyC = (${s}(dyCCorner) + ${s}(wC)) / ${s}(uniforms.strides.y);
                let wCPerm = uniforms.filter_dims.y - 1 - wC / uniforms.dilations.y;
                if (dyC < 0.0 || dyC >= ${s}(uniforms.Dy_shape[${u}]) ||
                    fract(dyC) > 0.0 || wCPerm < 0) {
                  continue;
                }
                let idyC: u32 = u32(dyC);
                var inputChannel = groupId * uniforms.input_channels_per_group;
                ${p?`
                var x_offset = ${g.indicesToOffset(`${g.type.indices}(batch, idyR, idyC, inputChannel)`)} / ${d};
                var w_offset = ${c.indicesToOffset(`${c.type.indices}(wRPerm, wCPerm, inputChannel, wOutChannel)`)} / ${m};
                  `:""}
                for (var d2: u32 = 0; d2 < uniforms.input_channels_per_group_int; d2 = d2 + ${p?4:d}) {
                  ${(()=>{let e="";if(p)4===d?e+=`
        let xValue = ${g.getByOffset("x_offset")};
        let wValue = ${c.getByOffset("w_offset")};
        dotProd = dotProd + dot(xValue, wValue);
        x_offset += 1u;
        w_offset += 1u;`:2===d?e+=`
          dotProd = dotProd + dot(vec4<${s}>(${g.getByOffset("x_offset")}, ${g.getByOffset("x_offset + 1u")}), vec4<${s}>(${c.getByOffset("w_offset")}, ${c.getByOffset("w_offset + 1u")}));
          x_offset += 2u;
          w_offset += 2u;`:1===d&&(e+=`
          dotProd = dotProd + dot(vec4<${s}>(${g.getByOffset("x_offset")}, ${g.getByOffset("x_offset + 1u")}, ${g.getByOffset("x_offset + 2u")}, ${g.getByOffset("x_offset + 3u")}), vec4<${s}>(${c.getByOffset("w_offset")}, ${c.getByOffset("w_offset + 1u")}, ${c.getByOffset("w_offset + 2u")}, ${c.getByOffset("w_offset + 3u")}));
          x_offset += 4u;
          w_offset += 4u;`);else if(e+=`
                  let xValue = ${n?g.getByOffset(`${g.indicesToOffset(`${g.type.indices}(batch, idyR, idyC, inputChannel)`)} / ${d}`):g.get("batch","inputChannel","idyR","idyC")};
        `,1===d)e+=`
          let w_offset = ${c.indicesToOffset(`${c.type.indices}(u32(wRPerm), u32(wCPerm), inputChannel, wOutChannel)`)};
          let wValue = ${c.getByOffset(`w_offset / ${m}`)};
          dotProd = dotProd + xValue * wValue;`;else for(let t=0;t<d;t++)e+=`
            let wValue${t} = ${c.getByOffset(`${c.indicesToOffset(`${c.type.indices}(u32(wRPerm), u32(wCPerm), inputChannel + ${t}, wOutChannel)`)} / ${m}`)};
            dotProd = dotProd + xValue[${t}] * wValue${t};`;return e})()}
                  inputChannel = inputChannel + ${p?4:d};
                }
                ${(()=>{if(0===h)return"";if(!p)throw Error(`packInputAs4 ${p} is not true.`);let e="";if(1===d){e+="dotProd = dotProd";for(let t=0;t<h;t++)e+=`
            + ${g.getByOffset(`x_offset + ${t}`)} * ${c.getByOffset(`w_offset + ${t}`)}`;e+=";"}else if(2===d){if(2!==h)throw Error(`Invalid inputChannelsRemainder ${h}.`);e+=`
          let xValue = ${g.getByOffset("x_offset")};
          let wValue = ${c.getByOffset("w_offset")};
          dotProd = dotProd + dot(xValue, wValue);`}return e})()}
                wC = wC + uniforms.strides.y - 1;
              }
              wR = wR + uniforms.strides[0] - 1;
            }
            let value = dotProd${i?` + bias[d1 / ${f}]`:""};
            ${_.setByOffset("global_idx","value")};
          `;return`
    ${t.registerUniforms(r).declareVariables(...y,_)}
      ${t.mainStart()}
      ${t.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")};
    ${v}}`}}}}),nF=M(()=>{"use strict";nH(),nD(),nS(),iP=(e,t,r,i,a,n)=>(e-1)*t+r+(i-1)*a+1-n,iU=(e,t,r,i,a)=>{let n=Math.floor(e/2);"SAME_UPPER"===t?(r[i]=n,r[a]=e-n):"SAME_LOWER"===t&&(r[i]=e-n,r[a]=n)},iq=(e,t)=>{let r=e.kernelShape.slice();if(0===e.kernelShape.length||0===e.kernelShape.reduce((e,t)=>e*t,1)){r.length=0;for(let e=2;e<t[1].dims.length;++e)r.push(t[1].dims[e])}let i="NHWC"===e.format;r.splice(0,0,t[1].dims[0]),r.splice(i?3:1,0,t[1].dims[1]);let a=e.pads.slice(),n=e.outputShape.slice(),s=e.outputPadding.slice(),o=t[0].dims,u=e.dilations.slice();0===u.reduce((e,t)=>e+t,0)&&(u=Array(t[0].dims.length-2).fill(1));let l=e.strides.slice();0===l.reduce((e,t)=>e+t,0)&&(l=Array(t[0].dims.length-2).fill(1)),((e,t,r,i,a,n,s,o,u,l)=>{let d=e.length-2,p=0===l.length;u.length<d&&u.push(...Array(d-u.length).fill(0));let c=e[0],h=t[o?3:1]*a;for(let a=0,c=e.length-d-!!o;a<d;++a,++c){let o=e[c],h=p?o*s[a]:l[a];iU(iP(o,s[a],n[a],t[c],r[a],h),i,n,a,a+d),p&&l.push(s[a]*(o-1)+u[a]+(t[c]-1)*r[a]+1-n[a]-n[a+d])}l.splice(0,0,c),l.splice(o?3:1,0,h)})(o,r,u,e.autoPad,e.group,a,l,i,s,n);let d=Object.assign({},e);return Object.assign(d,{kernelShape:r,pads:a,outputPadding:s,outputShape:n,dilations:u,strides:l}),d},iW=e=>{let t=ih(e),r=e.format,i=["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][typeof e.autoPad>"u"?0:e.autoPad],a=e.dilations,n=e.group,s=e.kernelShape,o=e.pads,u=e.strides,l=e.wIsConst();return{autoPad:i,format:r,dilations:a,group:n,kernelShape:s,outputPadding:e.outputPadding,outputShape:e.outputShape,pads:o,strides:u,wIsConst:l,...t,cacheKey:`${e.format};${t.activation};`}},iL=(e,t,r,i)=>{let a=e.kernelCustomData.wT??e.compute(tP(t[1],[2,3,0,1]),{inputs:[1],outputs:[r.wIsConst?-2:-1]})[0];r.wIsConst&&!e.kernelCustomData.wT&&(e.kernelCustomData.wT=a);let n=[t[0],a];3===t.length&&n.push(t[2]),e.compute(iM(n,r,i),{inputs:n})},iV=(e,t)=>{if(((e,t)=>{if(!e||2!==e.length&&3!==e.length)throw Error("Conv requires 2 or 3 inputs");if(4!==e[0].dims.length&&3!==e[0].dims.length)throw Error("currently only support 2-dimensional conv");if(e[0].dims.length!==e[1].dims.length)throw Error("filter does not have same dimension as input");if(e[0].dims["NHWC"===t.format?e[0].dims.length-1:1]!==e[1].dims[0])throw Error("FILTER_IN_CHANNEL should be equal to DATA_CHANNEL");let r=e[1].dims[1]*t.group;if(3===e.length&&(1!==e[2].dims.length||e[2].dims[0]!==r))throw Error("invalid bias");let i=e[0].dims.length-2;if(t.dilations.reduce((e,t)=>e+t,0)>0&&t.dilations.length!==i)throw Error(`dilations should be ${i}D`);if(t.strides.reduce((e,t)=>e+t,0)>0&&t.strides.length!==i)throw Error(`strides should be ${i}D`);if(t.pads.reduce((e,t)=>e+t,0)>0&&t.pads.length!==2*i)throw Error(`pads should be ${2*i}D`);if(t.outputPadding.length!==i&&0!==t.outputPadding.length)throw Error(`output_padding should be ${i}D`);if(t.kernelShape.reduce((e,t)=>e+t,0)>0&&0!==t.kernelShape.length&&t.kernelShape.length!==e[1].dims.length-2)throw Error("invalid kernel shape");if(0!==t.outputShape.length&&t.outputShape.length!==e[0].dims.length-2)throw Error("invalid output shape")})(e.inputs,t),3===e.inputs[0].dims.length){var r,i;let a,n,s,o,u,l,d,p;r=e,a="NHWC"===(i=t).format,n=[r.inputs[0].reshape(a?[r.inputs[0].dims[0],1,r.inputs[0].dims[1],r.inputs[0].dims[2]]:[r.inputs[0].dims[0],r.inputs[0].dims[1],1,r.inputs[0].dims[2]]),r.inputs[1].reshape([r.inputs[1].dims[0],r.inputs[1].dims[1],1,r.inputs[1].dims[2]])],3===r.inputs.length&&n.push(r.inputs[2]),(0===(s=i.kernelShape).length||0===s[0])&&(s=[r.inputs[1].dims[2]]),(0===(o=i.dilations).length||0===o[0])&&(o=[1]),(0===(u=i.strides).length||0===u[0])&&(u=[1]),0===(l=i.pads).length&&(l=[0,0]),l=[0,l[0],0,l[1]],u=[1].concat(u),o=[1].concat(o),s=[1].concat(s),d=[0].concat(d=i.outputPadding),p=iq({...i,pads:l,strides:u,dilations:o,kernelShape:s,outputPadding:d},n),iL(r,n,p,e=>a?[e[0],e[2],e[3]]:[e[0],e[1],e[3]])}else{let r=iq(t,e.inputs);iL(e,e.inputs,r)}}}),nj=M(()=>{"use strict";nf(),ny(),nx(),nk(),iG=(e,t)=>{var r,i,a,n;let s,o,u,l,d,p,c=e.inputs[0].dims,h=e.inputs[0].dataType,f=e.inputs[1];e.compute((r=h,i=c,a=f,n=t,s=e2.size(i),o=i.length,u=tA("input",r,o),l=tO("output",r,o),d=6===a.dataType?a.getInt32Array()[0]:Number(a.getBigInt64Array()[0]),p=e2.normalizeAxis(d,o),{name:"CumSum",shaderCache:{hint:n.cacheKey,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:i,dataType:r}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:[{type:12,data:s},{type:12,data:p},...tk(i,i)]}),getShaderSource:e=>{let t=` i32(${u.indicesGet("inputIndices","uniforms.axis")}) `,r=tC("uniforms.input_shape","uniforms.axis",o),i=n.reverse?t+(n.exclusive?" + 1":""):"0",a=n.reverse?r:t+(n.exclusive?"":" + 1");return`
                ${e.registerUniform("outputSize","u32").registerUniform("axis","u32").declareVariables(u,l)}
                ${e.mainStart()}
                  ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
                  var inputIndices = ${l.offsetToIndices("global_idx")};
                  var sum = ${l.type.value}(0);
                  let first : i32 = ${i};
                  let last : i32 = ${a};
                  for (var i : i32 = first; i < last; i++) {
                    ${u.indicesSet("inputIndices","uniforms.axis","u32(i)")};
                    sum = sum + ${u.getByIndices("inputIndices")};
                  }
                  ${l.setByOffset("global_idx","sum")};
                }`}}),{inputs:[0]})},iH=e=>{let t=1===e.exclusive,r=1===e.reverse;return tb({exclusive:t,reverse:r})}}),nK=M(()=>{"use strict";nf(),ny(),nx(),nk(),iF=(e,t)=>{var r,i;let a,n,s,o,u,l,d,p,c,h,f,m,g,y;(e=>{if(!e||1!==e.length)throw Error("DepthToSpace requires 1 input.");if(4!==e[0].dims.length)throw Error("DepthToSpace requires 4D input.")})(e.inputs),e.compute((r=e.inputs[0],d="NHWC"===(i=t).format,p=i.blocksize,c="DCR"===i.mode,d?([a,n,s,o]=r.dims,u=c?[a,n,s,p,p,o/p**2]:[a,n,s,o/p**2,p,p],l=c?[0,1,3,2,4,5]:[0,1,4,2,5,3]):([a,n,s,o]=[r.dims[0],r.dims[2],r.dims[3],r.dims[1]],u=c?[a,p,p,o/p**2,n,s]:[a,o/p**2,p,p,n,s],l=c?[0,3,4,1,5,2]:[0,1,4,2,5,3]),f=(h=r.reshape(u)).dims.length,m=r.dataType,g=tA("a",m,f),y=tO("output",m,f),{name:"DepthToSpace",shaderCache:{hint:`${r.dims};${i.blocksize};${i.mode}`,inputDependencies:["rank"]},getRunData:e=>{let t=d?[a,n*p,s*p,o/p**2]:[a,o/p**2,n*p,s*p],r=e2.size(t),i=h.dims,u=e2.sortBasedOnPerm(i,l);return{outputs:[{dims:t,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(r/64)},programUniforms:[{type:12,data:r},...tk(i,u)]}},getShaderSource:e=>`
  ${e.registerUniform("output_size","u32").declareVariables(g,y)}

  ${((e,t,r,i)=>{let a=[];a.push(`fn perm(i: ${i.type.indices}) -> ${r.type.indices} {
    var a: ${r.type.indices};`);for(let i=0;i<t;++i)a.push(r.indicesSet("a",e[i],`i[${i}]`));return a.push("return a;}"),a.join(`
`)})(l,f,g,y)}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

    let indices = ${y.offsetToIndices("global_idx")};
    let aIndices = perm(indices);

    ${y.setByOffset("global_idx",g.getByIndices("aIndices"))}
  }`}))},ij=e=>tb({blocksize:e.blocksize,mode:e.mode,format:e.format})}),nZ=M(()=>{"use strict";nf(),ny(),nx(),nk(),iQ="^"+(iZ="("+(iK="[a-zA-Z]|\\.\\.\\.")+")+")+"$",iX="^"+("("+iZ+",)*")+iZ+"$",iY=class{constructor(e=-1){this.symbolToIndices=new Map,this.inputIndex=e}addSymbol(e,t){let r=this.symbolToIndices.get(e);void 0===r?r=[t]:r.push(t),this.symbolToIndices.set(e,r)}},iJ=class{constructor(e,t){this.equation=t,this.hasEllipsis=!1,this.symbolToInfo=new Map,this.lhs=[],this.outputDims=[];let[r,i]=t.includes("->")?t.split("->",2):[t,""];if(!r.match(RegExp(iX)))throw Error("Invalid LHS term");if(r.split(",").forEach((t,r)=>{let i=e[r].dims.slice();if(!t.match(RegExp(iQ)))throw Error("Invalid LHS term");let a=this.processTerm(t,!0,i,r);this.lhs.push(a)}),""===i)i+=[...this.symbolToInfo.entries()].filter(([e,t])=>1===t.count||"..."===e).map(([e])=>e).join("");else if(!i.match(RegExp(iZ)))throw Error("Invalid RHS");i.match(RegExp(iK,"g"))?.forEach(e=>{if("..."===e)this.outputDims=this.outputDims.concat(this.ellipsisDims);else{let t=this.symbolToInfo.get(e);if(void 0===t)throw Error("Invalid RHS symbol");this.outputDims.push(t.dimValue)}}),this.rhs=this.processTerm(i,!1,this.outputDims)}addSymbol(e,t,r){let i=this.symbolToInfo.get(e);if(void 0!==i){if(i.dimValue!==t&&1!==i.count)throw Error("Dimension mismatch");i.count++,i.inputIndices.push(r)}else i={count:1,dimValue:t,inputIndices:[r]};this.symbolToInfo.set(e,i)}processTerm(e,t,r,i=-1){let a=r.length,n=!1,s=[],o=0;if(!e.match(RegExp(iQ))&&!t&&""!==e)throw Error("Invalid LHS term");let u=e.match(RegExp(iK,"g")),l=new iY(i);return u?.forEach((e,d)=>{if("..."===e){if(n)throw Error("Only one ellipsis is allowed per input term");n=!0;let e=a-u.length+1;if(e<0)throw Error("Ellipsis out of bounds");if(s=r.slice(o,o+e),this.hasEllipsis){if(this.ellipsisDims.length!==s.length||this.ellipsisDims.toString()!==s.toString())throw Error("Ellipsis dimensions mismatch")}else if(t)this.hasEllipsis=!0,this.ellipsisDims=s;else throw Error("Ellipsis must be specified in the LHS");for(let e=0;e<s.length;e++){let t=String.fromCharCode(48+e);l.addSymbol(t,d+e),this.addSymbol(t,r[o++],i)}}else l.addSymbol(e,d+(this.hasEllipsis?this.ellipsisDims.length-1:0)),this.addSymbol(e,r[o++],i)}),l}},i0=(e,t)=>{var r,i,a,n;let s,o,u,l,d=new iJ(e.inputs,t.equation),p=d.outputDims,c=e.inputs.map((e,t)=>e.dims);e.compute((r=c,i=e.inputs[0].dataType,a=d,n=p,s=r.map(e=>e.length).map((e,t)=>tA(`input${t}`,i,e)),o=e2.size(n),u=tO("output",i,n.length),l=[...a.symbolToInfo.keys()].filter(e=>!a.rhs.symbolToIndices.has(e)),{name:"Einsum",shaderCache:{hint:a.equation,inputDependencies:r.map(()=>"rank")},getRunData:()=>{let e=l.filter(e=>a.symbolToInfo.has(e)).map(e=>({type:12,data:a.symbolToInfo.get(e)?.dimValue||0}));e.push({type:12,data:o});let t=r.map((e,t)=>[...tk(e)]).reduce((e,t)=>e.concat(t),e);return t.push(...tk(n)),{outputs:[{dims:n,dataType:i}],dispatchGroup:{x:Math.ceil(o/64)},programUniforms:t}},getShaderSource:e=>{let t=[],r=[],i=[],n=[],o=[],d=a.symbolToInfo.size===a.rhs.symbolToIndices.size;a.symbolToInfo.forEach((e,l)=>{if(a.rhs.symbolToIndices.has(l)){let r=a.rhs.symbolToIndices.get(l)?.[0];void 0!==r&&a.lhs.forEach((i,a)=>{if(e.inputIndices.includes(a)){let e=i.symbolToIndices.get(l);if(void 0===e)throw Error("Invalid symbol error");e.forEach(e=>{t.push(`${s[a].indicesSet(`input${a}Indices`,e,u.indicesGet("outputIndices",r))}`)})}})}else a.lhs.forEach((t,i)=>{if(e.inputIndices.includes(i)){let e=t.symbolToIndices.get(l);if(void 0===e)throw Error("Invalid symbol error");e.forEach(e=>{r.push(`${s[i].indicesSet(`input${i}Indices`,e,`${l}`)}`)}),o.push(`prod *= ${s[i].getByIndices(`input${i}Indices`)};`)}}),i.push(`for(var ${l}: u32 = 0; ${l} < uniforms.${l+"_max"}; ${l}++) {`),n.push("}")});let p=d?[...t,`let sum = ${s.map((e,t)=>e.getByIndices(`input${t}Indices`)).join(" * ")};`]:[...t,"var sum = 0.0;",...i,...r,"var prod = 1.0;",...o,"sum += prod;",...n];return`
            ${e.registerUniforms(l.map(e=>({name:`${e+"_max"}`,type:"u32"}))).registerUniform("outputSize","u32").declareVariables(...s,u)}

            ${e.mainStart()}
            ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
            var outputIndices = ${u.offsetToIndices("global_idx")};
            ${s.map((e,t)=>`var input${t}Indices: ${s[t].type.indices};`).join(`
`)}
            ${p.join(`
`)};
            ${u.setByOffset("global_idx","sum")};
          }`}}))},i2=e=>{let t=e.equation.replace(/\s+/g,"");return tb({equation:t})}}),nQ=M(()=>{"use strict";nf(),ny(),nk(),i1=(e,t)=>{let r=e.length-t.length,i=[];for(let t=0;t<r;++t)i.push(e[t]);for(let a=0;a<t.length;++a)i.push(1===t[a]?e[a+r]:t[a]);return i},i3=e=>{var t;let r,i,a,n,s,o,u,l,d,p;(e=>{if(!e||2!==e.length)throw Error("Expand requires 2 input.");let t=e[0].dims,r=Array.from(e[1].getBigInt64Array(),Number),i=r.length<t.length?0:r.length-t.length,a=t.length<r.length?0:t.length-r.length;for(;i<r.length&&a<t.length;++i,++a)if(r[i]!==t[a]&&1!==r[i]&&1!==t[a])throw Error("Expand requires shape to be broadcastable to input")})(e.inputs),e.compute((n=(r=a=(t=e.inputs)[0].dims,i=Array.from(t[1].getBigInt64Array(),Number),r.length>i.length?i1(r,i):i1(i,r)),o=9===(s=t[0].dataType)||1===e2.size(a),u=9===s||a.length>0&&a[a.length-1]%4==0?4:1,l=o||n.length>0&&n[n.length-1]%4==0?4:1,p=[{type:12,data:d=Math.ceil(e2.size(n)/l)},...tk(a,n)],{name:"Expand",shaderCache:{hint:`${n.length};${u}${l}`,inputDependencies:["rank"]},getShaderSource:e=>{let t=tA("input",s,a.length,u),r=tO("output",s,n.length,l),i;if(9===s){let e=(e,i,a="")=>`
          let outputIndices${i} = ${r.offsetToIndices(`outputOffset + ${i}u`)};
          let offset${i} = ${t.broadcastedIndicesToOffset(`outputIndices${i}`,r)};
          let index${i} = offset${i} / 4u;
          let component${i} = offset${i} % 4u;
          ${e}[${i}] = ${a}(${t.getByOffset(`index${i}`)}[component${i}]);
        `;i=`
        let outputOffset = global_idx * ${l};
        var data = vec4<u32>(0);
        ${e("data",0,"u32")}
        ${e("data",1,"u32")}
        ${e("data",2,"u32")}
        ${e("data",3,"u32")}
        ${r.setByOffset("global_idx","data")}
      }`}else i=`
        let outputIndices = ${r.offsetToIndices(`global_idx * ${l}`)};
        let inputOffset = ${t.broadcastedIndicesToOffset("outputIndices",r)};
        let data = ${r.type.value}(${t.getByOffset(`inputOffset / ${u}`)});
        ${r.setByOffset("global_idx","data")}
      }`;return`
    ${e.registerUniform("vec_size","u32").declareVariables(t,r)}
    ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
    ${i}`},getRunData:()=>({outputs:[{dims:n,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:p})}),{inputs:[0]})}}),nX=M(()=>{"use strict";nf(),ny(),nk(),nO(),i4=e=>{var t;let r,i,a,n;e.inputs.length<2||0===e2.size(e.inputs[1].dims)?r0(e):e.compute((r=(t=e.inputs)[0].dataType,i=e2.size(t[0].dims),n=(a=e2.size(t[1].dims))%4==0,{name:"FastGeluWithBias",shaderCache:{hint:`${n}`,inputDependencies:["type","type"]},getShaderSource:e=>{let t=tA("x",r,[1],4),i=tA("bias",r,[1],4),a=tO("y",r,[1],4),s=e=>`
      let bias${e}_offset: u32 = (global_idx * 4 + ${e}) % uniforms.bias_size;
      let bias${e} = ${i.getByOffset(`bias${e}_offset / 4`)}[bias${e}_offset % 4];`,o=n?`
      let bias = ${i.getByOffset("global_idx % (uniforms.bias_size / 4)")};`:`${s(0)}${s(1)}${s(2)}${s(3)}
      let bias = ${t.type.value}(bias0, bias1, bias2, bias3);`;return`${e.registerUniforms([{name:"output_vec_size",type:"u32"},{name:"bias_size",type:"u32"}]).declareVariables(t,i,a)}

    ${rY(tx(r))}

    ${e.mainStart(t$)}
      ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_vec_size")}

      let x = ${t.getByOffset("global_idx")};
      ${o}
      let x_in = x + bias;
      ${a.setByOffset("global_idx",rJ("x_in"))}
    }`},getRunData:e=>({outputs:[{dims:e[0].dims,dataType:e[0].dataType}],programUniforms:[{type:12,data:Math.ceil(i/4)},{type:12,data:a}],dispatchGroup:{x:Math.ceil(i/t$/4)}})}))}}),nY=M(()=>{"use strict";nf(),ny(),nx(),nk(),i6=e=>tb({axis:e.axis}),i8=(e,t)=>{var r,i;let a,n,s,o,u,l,d,p,c;(e=>{if(!e||2!==e.length)throw Error("Gather requires 2 inputs.")})(e.inputs),e.compute((r=e.inputs,i=t,a=r[0].dims,n=r[1].dims,s=a.length,o=e2.normalizeAxis(i.axis,s),(u=a.slice(0)).splice(o,1,...n),l=a[o],d=9===r[0].dataType?4:1,c=[{type:12,data:p=Math.ceil(e2.size(u)/d)},{type:6,data:l},{type:12,data:o},...tk(r[0].dims,r[1].dims,u)],{name:"Gather",shaderCache:{hint:i.cacheKey,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:u,dataType:r[0].dataType}],dispatchGroup:{x:Math.ceil(p/64)},programUniforms:c}),getShaderSource:e=>{let t=tA("data",r[0].dataType,r[0].dims.length,d),i=tA("inputIndices",r[1].dataType,r[1].dims.length),a=tO("output",r[0].dataType,u.length,d),l=e=>{let r=n.length,a=`var indicesIndices${e}  = ${i.type.indices}(0);`;for(let t=0;t<r;t++)a+=`${r>1?`indicesIndices${e}[${t}]`:`indicesIndices${e}`} = ${u.length>1?`outputIndices${e}[uniforms.axis + ${t}]`:`outputIndices${e}`};`;a+=`
          var idx${e} = ${i.getByIndices(`indicesIndices${e}`)};
          if (idx${e} < 0) {
            idx${e} = idx${e} + uniforms.axisDimLimit;
          }
          var dataIndices${e} : ${t.type.indices};
        `;for(let t=0,i=0;t<s;t++)t===o?(a+=`${s>1?`dataIndices${e}[${t}]`:`dataIndices${e}`} = u32(idx${e});`,i+=r):(a+=`${s>1?`dataIndices${e}[${t}]`:`dataIndices${e}`} = ${u.length>1?`outputIndices${e}[${i}]`:`outputIndices${e}`};`,i++);return a},p;if(9===r[0].dataType){let e=(e,r,i="")=>`
          let outputIndices${r} = ${a.offsetToIndices(`outputOffset + ${r}u`)};
          ${l(r)};
          let offset${r} = ${t.indicesToOffset(`dataIndices${r}`)};
          let index${r} = offset${r} / 4u;
          let component${r} = offset${r} % 4u;
          ${e}[${r}] = ${i}(${t.getByOffset(`index${r}`)}[component${r}]);
        `;p=`
        let outputOffset = global_idx * ${d};
        var value = vec4<u32>(0);
        ${e("value",0,"u32")}
        ${e("value",1,"u32")}
        ${e("value",2,"u32")}
        ${e("value",3,"u32")}
        ${a.setByOffset("global_idx","value")}
      `}else p=`
      let outputIndices = ${a.offsetToIndices("global_idx")};
      ${l("")};
      let value = ${t.getByIndices("dataIndices")};
      ${a.setByOffset("global_idx","value")};
      `;return`
      ${e.registerUniform("outputSize","u32").registerUniform("axisDimLimit","i32").registerUniform("axis","u32").declareVariables(t,i,a)}
      ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
        ${p}
      }`}}))}}),nJ=M(()=>{"use strict";nf(),ny(),nk(),i5=(e,t)=>{var r,i,a,n,s,o;let u,l,d=e.inputs,p=d[0].dims,c=d[0].dataType,h=d[1].dims,f=h[h.length-1],m=e2.sizeToDimension(h,h.length-1),g=e2.sizeFromDimension(p,t.batchDims+f),y=e2.sizeToDimension(p,t.batchDims),_=e2.sizeFromDimension(p,t.batchDims),b=Array(f),$=g;for(let e=0;e<f;++e)b[f-1-e]=$,$*=p[t.batchDims+f-1-e];let v=(r=e,i=d[1],a=b,n=t.batchDims,s=p,u=[{type:12,data:o=m},{type:12,data:n},{type:12,data:s},{type:12,data:a},{type:12,data:m/y},{type:12,data:_},{type:12,data:f}],l=[o],u.push(...tk(i.dims,l)),r.compute({name:"computeSliceOffsets",shaderCache:{hint:`${s.length}_${a.length}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:l,dataType:r.inputs[1].dataType}],dispatchGroup:{x:Math.ceil(o/64)},programUniforms:u}),getShaderSource:e=>{let t=tA("indices_data",i.dataType,i.dims.length),r=tO("input_slice_offsets_data",12,1,1),n=[{name:"output_size",type:"u32"},{name:"batch_dims",type:"u32"},{name:"input_dims",type:"u32",length:s.length},{name:"sizes_from_slice_dims_data",type:"u32",length:a.length},{name:"num_slices_per_batch",type:"u32"},{name:"input_batch_stride",type:"u32"},{name:"num_slice_dims",type:"u32"}];return`
  ${e.registerUniforms(n).declareVariables(t,r)}
  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let batch_idx = global_idx / uniforms.num_slices_per_batch;
    let base_offset = batch_idx * uniforms.input_batch_stride;

    let slice_indices_base_offset = global_idx * uniforms.num_slice_dims;
    var relative_slice_offset = 0;
    for (var dim_idx = 0u; dim_idx < uniforms.num_slice_dims; dim_idx ++) {
      var index = i32(indices_data[dim_idx + slice_indices_base_offset].x);
      let input_dim_idx = uniforms.batch_dims + dim_idx;
      if (index < 0) {
        ${1===s.length?"index += i32(uniforms.input_dims);":"index += i32(uniforms.input_dims[input_dim_idx]);"}
      }
      ${1===a.length?"relative_slice_offset += index * i32(uniforms.sizes_from_slice_dims_data);":"relative_slice_offset += index * i32(uniforms.sizes_from_slice_dims_data[dim_idx]);"}
    }

    input_slice_offsets_data[global_idx] =  base_offset + u32(relative_slice_offset);
  }`}},{inputs:[i],outputs:[-1]})[0]),w=t.batchDims+f;if(w>p.length)throw Error("last dimension of indices must not be larger than rank of input tensor");let x=h.slice(0,-1).concat(p.slice(w)),k=e2.size(x),S=[{type:12,data:k},{type:12,data:g},...tk(d[0].dims,v.dims,x)];e.compute({name:"GatherND",shaderCache:{hint:t.cacheKey,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:x,dataType:c}],dispatchGroup:{x:Math.ceil(k/64)},programUniforms:S}),getShaderSource:e=>{let t=tA("data",d[0].dataType,d[0].dims.length),r=tA("slice_offsets",12,v.dims.length),i=tO("output",d[0].dataType,x.length);return`
          ${e.registerUniform("output_size","u32").registerUniform("slice_size","u32").declareVariables(t,r,i)}
            ${e.mainStart()}
            ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          let slice_offset = slice_offsets[global_idx / uniforms.slice_size];
          output[global_idx] = data[u32(slice_offset) + global_idx % uniforms.slice_size];
        }`}},{inputs:[d[0],v]})},i7=e=>({batchDims:e.batch_dims,cacheKey:""})}),n0=M(()=>{"use strict";nf(),ny(),nx(),nk(),i9=(e,t)=>{var r,i;let a,n,s,o,u,l,d,p,c,h;((e,t)=>{if(e.length<3||e.length>4)throw Error("GatherBlockQuantized requires 3 or 4 inputs.");let r=e2.normalizeAxis(t.quantizeAxis,e[0].dims.length),i=t.blockSize,a=e[0],n=e[2],s=4===e.length?e[3]:void 0;if(n.dims.length!==a.dims.length||!a.dims.map((e,t)=>t===r?Math.ceil(e/i)===n.dims[t]:e===n.dims[t]).reduce((e,t)=>e&&t,!0))throw Error("Scales must have the same rank as the input tensor and the dims should match except on gatherAxis.");if(s){if(s.dataType!==a.dataType)throw Error("Zero point must have the same data type as the input tensor.");if(s.dims.length!==n.dims.length||!s.dims.map((e,t)=>e===n.dims[t]).reduce((e,t)=>e&&t,!0))throw Error("Zero point must have the same rank as the input tensor and the dims should match except on quantizeAxis.")}})(e.inputs,t),e.compute((r=e.inputs,i=t,a=r[0].dims,n=r[1].dims,s=a.length,o=e2.normalizeAxis(i.gatherAxis,s),u=e2.normalizeAxis(i.quantizeAxis,s),(l=a.slice(0)).splice(o,1,...n),d=e2.size(l),p=r[2].dataType,c=22===r[0].dataType,h=[{type:12,data:d},{type:12,data:u},{type:12,data:o},{type:12,data:i.blockSize},...tk(...r.map((e,t)=>e.dims),l)],{name:"GatherBlockQuantized",shaderCache:{hint:`${i.cacheKey};${r.filter((e,t)=>1!==t).map(e=>e.dims.join("_")).join(";")}`,inputDependencies:Array.from({length:r.length},(e,t)=>"rank")},getRunData:()=>({outputs:[{dims:l,dataType:p}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:h}),getShaderSource:e=>{let t=tA("data",r[0].dataType,r[0].dims.length),i=tA("inputIndices",r[1].dataType,r[1].dims.length),s=tA("scales",r[2].dataType,r[2].dims.length),u=r.length>3?tA("zeroPoint",r[3].dataType,r[3].dims.length):void 0,d=tO("output",p,l.length),h=[t,i,s];return u&&h.push(u),`
        ${e.registerUniforms([{name:"output_size",type:"u32"},{name:"quantize_axis",type:"u32"},{name:"gather_axis",type:"u32"},{name:"block_size",type:"u32"}]).declareVariables(...h,d)}
        ${e.mainStart()}
        let output_indices = ${d.offsetToIndices("global_idx")};
        var indices_indices = ${i.type.indices}(0);
        ${n.length>1?`
          for (var i: u32 = 0; i < ${n.length}; i++) {
            let index = ${d.indicesGet("output_indices","uniforms.gather_axis + i")};
            ${i.indicesSet("indices_indices","i","index")};
          }`:`indices_indices = ${d.indicesGet("output_indices","uniforms.gather_axis")};`};
        var data_indices = ${t.type.indices}(0);
        for (var i: u32 = 0; i < uniforms.gather_axis; i++) {
          let index = ${d.indicesGet("output_indices","i")};
          ${t.indicesSet("data_indices","i","index")};
        }
        var index_from_indices = ${i.getByIndices("indices_indices")};
        if (index_from_indices < 0) {
          index_from_indices += ${a[o]};
        }
        ${t.indicesSet("data_indices","uniforms.gather_axis","u32(index_from_indices)")};
        for (var i = uniforms.gather_axis + 1; i < ${l.length}; i++) {
          let index = ${d.indicesGet("output_indices",`i + ${n.length} - 1`)};
          ${t.indicesSet("data_indices","i","index")};
        }
        let data_offset = ${t.indicesToOffset("data_indices")};
        let data_index = data_offset % 8;
        // Convert 4-bit packed data to 8-bit packed data.
        let packed_4bit_quantized_data = ${t.getByOffset("data_offset / 8")};
        let packed_8bit_quantized_data = (packed_4bit_quantized_data >> (4 * (data_index % 2))) & 0x0f0f0f0f;
        let quantized_data_vec = ${c?"unpack4xI8":"unpack4xU8"}(u32(packed_8bit_quantized_data));
        let quantized_data = quantized_data_vec[data_index / 2];
        var scale_indices = data_indices;
        let quantize_axis_index = ${s.indicesGet("data_indices","uniforms.quantize_axis")} / uniforms.block_size;
        ${s.indicesSet("scale_indices","uniforms.quantize_axis","quantize_axis_index")};
        var scale = ${s.getByIndices("scale_indices")};
        ${u?`
              let zero_point_indices = scale_indices;
              let zero_point_offset = ${u.indicesToOffset("zero_point_indices")};
              let zero_point_index = zero_point_offset % 8;
              let packed_4bit_zero_points = ${u.getByOffset("zero_point_offset / 8")};
              let packed_8bit_zero_points = (packed_4bit_zero_points >> (4 * (zero_point_index % 2))) & 0x0f0f0f0f;
              let zero_point_vec = ${c?"unpack4xI8":"unpack4xU8"}(u32(packed_8bit_zero_points));
              let zero_point = zero_point_vec[zero_point_index / 2];`:"var zero_point = 0"};
        let dequantized_data = ${tx(p)}(quantized_data - zero_point) * scale;
        ${d.setByOffset("global_idx","dequantized_data")};
    }`}}))},ae=e=>tb({blockSize:e.blockSize,gatherAxis:e.gatherAxis,quantizeAxis:e.quantizeAxis})}),n2=M(()=>{"use strict";nf(),ny(),nx(),nk(),at=e=>tb({axis:e.axis}),ar=(e,t)=>{var r,i;let a,n,s,o,u,l,d,p,c,h,f,m,g;(e=>{if(!e||2!==e.length)throw Error("GatherElements requires 2 inputs.");if(e[0].dims.length<1)throw Error("GatherElements requires that the data input be rank >= 1.");if(e[0].dims.length!==e[1].dims.length)throw Error(`GatherElements requires that the data input and
                     indices input tensors be of same rank.`)})(e.inputs),e.compute((r=e.inputs,i=t,a=r[0].dims,n=r[0].dataType,s=a.length,o=r[1].dims,u=r[1].dataType,d=a[l=e2.normalizeAxis(i.axis,s)],p=o.slice(0),c=e2.size(p),h=tA("input",n,s),f=tA("indicesInput",u,o.length),m=tO("output",n,p.length),(g=[{type:12,data:c},{type:6,data:d},{type:12,data:l}]).push(...tk(a,o,p)),{name:"GatherElements",shaderCache:{inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:p,dataType:r[0].dataType}],dispatchGroup:{x:Math.ceil(c/64)},programUniforms:g}),getShaderSource:e=>`
      ${e.registerUniform("outputSize","u32").registerUniform("axisDimLimit","i32").registerUniform("axis","u32").declareVariables(h,f,m)}
      ${e.mainStart()}
      ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

      let outputIndices = ${m.offsetToIndices("global_idx")};

      var idx = ${f.getByOffset("global_idx")};
      if (idx < 0) {
        idx = idx + uniforms.axisDimLimit;
      }
      var inputIndices = ${h.type.indices}(outputIndices);
      ${h.indicesSet("inputIndices","uniforms.axis","u32(idx)")};
      let value = ${h.getByIndices("inputIndices")};

      ${m.setByOffset("global_idx","value")};
  }`}))}}),n1=M(()=>{"use strict";nf(),ny(),nk(),ai=e=>({transA:e.transA,transB:e.transB,alpha:e.alpha,beta:e.beta,cacheKey:`${e.transA};${e.transB};${1===e.alpha}`}),aa=(e,t)=>{(e=>{if(!e)throw Error("Input is missing");if(e.length<2||e.length>3)throw Error("Invaid input number.");if(3===e.length&&e[2].dims.length>2)throw Error("Invalid input shape of C");if(e[0].dataType!==e[1].dataType||3===e.length&&e[0].dataType!==e[2].dataType)throw Error("Input types are mismatched")})(e.inputs),e.compute(((e,t)=>{let r=e[0].dims.slice(),i=e[1].dims.slice(),[a,n,s]=e3.getShapeOfGemmResult(r,t.transA,i,t.transB,3===e.length?e[2].dims:void 0),o=[a,n];if(!o)throw Error("Can't use gemm on the given tensors");let u=Math.ceil(n/16),l=Math.ceil(a/16),d=(e2.size(o),[{type:12,data:u},{type:12,data:a},{type:12,data:n},{type:12,data:s},{type:1,data:t.alpha},{type:1,data:t.beta}]),p=["type","type"];return 3===e.length&&(d.push(...tk(e[2].dims)),p.push("rank")),d.push(...tk(o)),{name:"GemmShared",shaderCache:{hint:`${t.cacheKey}`,inputDependencies:p},getRunData:()=>({outputs:[{dims:o,dataType:e[0].dataType}],dispatchGroup:{x:u*l},programUniforms:d}),getShaderSource:r=>{let i=tA("a",e[0].dataType,e[0].dims),a=tA("b",e[1].dataType,e[1].dims),n=null,s=[i,a];3===e.length&&(n=tA("c",e[2].dataType,e[2].dims.length),s.push(n));let u=tO("output",e[0].dataType,o.length);s.push(u);let l="",d="";t.transA&&t.transB?(d=`
      var col = tile_row_start + local_id.x;
      var row = k_start + local_id.y;
      if (col < uniforms.M && row < uniforms.K) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.M + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${i.type.value}(0);
      }

      col = k_start + local_id.x;
      row = tile_col_start + local_id.y;
      if (col < uniforms.K && row < uniforms.N) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.K + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${a.type.value}(0);
      }
      `,l="value += tile_a[k][local_id.y] * tile_b[local_id.x][k];"):t.transA&&!t.transB?(d=`
      var col = tile_row_start + local_id.x;
      var row = k_start + local_id.y;
      if (col < uniforms.M && row < uniforms.K) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.M + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${i.type.value}(0);
      }

      col = tile_col_start + local_id.x;
      row = k_start + local_id.y;
      if (col < uniforms.N && row < uniforms.K) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.N + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${a.type.value}(0);
      }
      `,l="value += tile_a[k][local_id.y] * tile_b[k][local_id.x];"):!t.transA&&t.transB?(d=`
      var col = k_start + local_id.x;
      var row = tile_row_start + local_id.y;
      if (col < uniforms.K && row < uniforms.M) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.K + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${i.type.value}(0);
      }

      col = k_start + local_id.x;
      row = tile_col_start + local_id.y;
      if (col < uniforms.K && row < uniforms.N) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.K + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${a.type.value}(0);
      }
      `,l="value += tile_a[local_id.y][k] * tile_b[local_id.x][k];"):t.transA||t.transB||(d=`
      var col = k_start + local_id.x;
      var row = tile_row_start + local_id.y;
      if (col < uniforms.K && row < uniforms.M) {
        tile_a[local_id.y][local_id.x] = a[row * uniforms.K + col];
      } else {
        tile_a[local_id.y][local_id.x] = ${i.type.value}(0);
      }

      col = tile_col_start + local_id.x;
      row = k_start + local_id.y;
      if (col < uniforms.N && row < uniforms.K) {
        tile_b[local_id.y][local_id.x] = b[row * uniforms.N + col];
      } else {
        tile_b[local_id.y][local_id.x] = ${a.type.value}(0);
      }
      `,l="value += tile_a[local_id.y][k] * tile_b[k][local_id.x];");let p=1===t.alpha?"":"value *= uniforms.alpha;";return`
  ${r.registerUniforms([{name:"num_tile_n",type:"u32"},{name:"M",type:"u32"},{name:"N",type:"u32"},{name:"K",type:"u32"},{name:"alpha",type:"f32"},{name:"beta",type:"f32"}]).declareVariables(...s)}
  var<workgroup> tile_a: array<array<${i.type.storage}, 16>, 16>;
  var<workgroup> tile_b: array<array<${a.type.storage}, 16>, 16>;
  ${r.mainStart([16,16,1])}
    let tile_col_start = (workgroup_index % uniforms.num_tile_n) * 16;
    let tile_row_start = (workgroup_index / uniforms.num_tile_n) * 16;
    let num_tiles = (uniforms.K - 1) / 16 + 1;
    var k_start = 0u;
    var value = ${u.type.value}(0);
    for (var t: u32 = 0u; t < num_tiles; t++) {
      ${d}
      k_start = k_start + 16;
      workgroupBarrier();

      for (var k: u32 = 0u; k < 16; k++) {
        ${l}
      }
      workgroupBarrier();
    }

    ${p}
    let m = tile_row_start + local_id.y;
    let n = tile_col_start + local_id.x;
    ${null!=n?`let cOffset = ${n.broadcastedIndicesToOffset("vec2(m, n)",u)}; value += ${u.type.value}(uniforms.beta) * ${n.getByOffset("cOffset")};`:""}
    if (m < uniforms.M && n < uniforms.N) {
      output[m * uniforms.N + n] = value;
    }
  }`}}})(e.inputs,t))}}),n3=M(()=>{"use strict";nf(),ny(),nx(),nk(),[an,as,ao,au]=[0,1,2,3],al=`
  fn gs_get_cubic_coeffs(x: f32) -> vec4<f32> {
    let cubic_alpha = -0.75f;
    let x_abs = abs(x);
    var coeffs: vec4<f32>;
    coeffs[0] = (((cubic_alpha * (x_abs + 1) - 5 * cubic_alpha) * (x_abs + 1) + 8 * cubic_alpha) * (x_abs + 1) - 4 * cubic_alpha);
    coeffs[1] = (((cubic_alpha + 2) * x_abs - (cubic_alpha + 3)) * x_abs * x_abs + 1);
    coeffs[2] = (((cubic_alpha + 2) * (1 - x_abs) - (cubic_alpha + 3)) * (1 - x_abs) * (1 - x_abs) + 1);
    coeffs[3] = (((cubic_alpha * (2 - x_abs) - 5 * cubic_alpha) * (2 - x_abs) + 8 * cubic_alpha) * (2 - x_abs) - 4 * cubic_alpha);
    return coeffs;
  }
`,ad=(e,t)=>{var r,i;let a,n,s,o,u,l,d;(e=>{if(4!==e[0].dims.length)throw Error("only 4-D tensor is supported.");if(e[0].dims.length!==e[1].dims.length)throw Error("input dimensions must be equal to grid dimensions");if(e[0].dims.length-2!==e[1].dims[e[1].dims.length-1])throw Error(`last dimension of grid must be equal to ${e[0].dims.length-2}`);if(e[0].dims[0]!==e[1].dims[0])throw Error("grid batch size must match input batch size")})(e.inputs),e.compute((r=e.inputs,i=t,a=tA("x",r[0].dataType,r[0].dims.length),n=[r[1].dims[0],r[1].dims[1],r[1].dims[2]],s=tA("grid",r[1].dataType,n.length,2),o=[r[0].dims[0],r[0].dims[1],r[1].dims[1],r[1].dims[2]],"NHWC"===i.format&&(o=[r[0].dims[0],r[1].dims[1],r[1].dims[2],r[0].dims[3]],[an,as,ao,au]=[0,3,1,2]),u=tO("output",r[0].dataType,o.length),l=a.type.value,d=[{type:12,data:e2.size(o)},...tk(r[0].dims,n,o)],{name:"GridSample",shaderCache:{hint:`${i.cacheKey}`,inputDependencies:["type","type"]},getRunData:e=>{let t=e2.size(o);return{outputs:[{dims:o,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(t/64)},programUniforms:d}},getShaderSource:e=>{let t,r,n,o,d,p,c,h,f;return`
  ${e.registerUniform("output_size","u32").declareVariables(a,s,u)}
  ${al}
  ${t=l,`
  fn gs_bicubic_interpolate(p: mat4x4<${t}>, x: f32, y: f32) -> ${t} {
    var v: vec4<f32>;
    var coeffs = gs_get_cubic_coeffs(x);
    for (var i = 0; i < 4; i++) {
      v[i] = coeffs[0] * p[i][0] + coeffs[1] * p[i][1] + coeffs[2] * p[i][2] + coeffs[3] * p[i][3];
    }
    coeffs = gs_get_cubic_coeffs(y);
    let pixel = ${t}(coeffs[0] * v[0] + coeffs[1] * v[1] + coeffs[2] * v[2] + coeffs[3] * v[3]);
    return pixel;
  }
`}
  ${r=i,`
  fn gs_denormalize(n: f32, length: i32) -> f32 {
    ${0===r.alignCorners?`
    // alignCorners: false => [-1, 1] to [-0.5, length - 0.5]
    return ((n + 1.0) * f32(length) - 1.0) / 2.0;
    `:`
    // alignCorners: true => [-1, 1] to [0, length - 1]
    return (n + 1.0) / 2.0 * (f32(length - 1));
    `}
  }
`}
  ${n=i,`
  ${"reflection"===n.paddingMode?`
      fn gs_reflect(x: i32, x_min: f32, x_max: f32) -> u32 {
        var dx = 0.0;
        var fx = f32(x);
        let range = x_max - x_min;
        if (fx < x_min) {
          dx = x_min - fx;
          let n = u32(dx / range);
          let r = dx - f32(n) * range;
          if (n % 2 == 0) {
            fx = x_min + r;
          } else {
            fx = x_max - r;
          }
        } else if (fx > x_max) {
          dx = fx - x_max;
          let n = u32(dx / range);
          let r = dx - f32(n) * range;
          if (n % 2 == 0) {
            fx = x_max - r;
          } else {
            fx = x_min + r;
          }
        }
        return u32(fx);
      }`:""}
`}
  ${o=a,d=l,p=i,`
  fn pixel_at_grid(r: i32, c: i32, H: i32, W: i32, batch: u32, channel: u32, border: vec4<f32>) -> ${d} {
     var pixel = ${d}(0);
     var indices = vec4<u32>(0);
     indices[${an}] = batch;
     indices[${as}] = channel;`+(()=>{switch(p.paddingMode){case"zeros":return`
          if (r >= 0 && r < H && c >=0 && c < W) {
            indices[${ao}] = u32(r);
            indices[${au}] = u32(c);
          } else {
            return ${d}(0);
          }
        `;case"border":return`
          indices[${ao}] = u32(clamp(r, 0, H - 1));
          indices[${au}] = u32(clamp(c, 0, W - 1));
        `;case"reflection":return`
          indices[${ao}] = gs_reflect(r, border[1], border[3]);
          indices[${au}] = gs_reflect(c, border[0], border[2]);
        `;default:throw Error(`padding mode ${p.paddingMode} is not supported`)}})()+`
    return ${o.getByIndices("indices")};
  }
`}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let H_in = i32(uniforms.x_shape[${ao}]);
      let W_in = i32(uniforms.x_shape[${au}]);

      ${0===i.alignCorners?`
      let x_min = -0.5;
      let x_max = f32(W_in) - 0.5;
      let y_min = -0.5;
      let y_max = f32(H_in) - 0.5;
      `:`
      let x_min = 0.0;
      let x_max = f32(W_in) - 1.0;
      let y_min = 0.0;
      let y_max = f32(H_in) - 1.0;
      `};
      let border = vec4<f32>(x_min, y_min, x_max, y_max);

      let indices = ${u.offsetToIndices("global_idx")};
      var grid_indices = vec3<u32>(indices[${an}], indices[${ao}], indices[${au}]);
      let nxy = ${s.getByIndices("grid_indices")};
      var x = gs_denormalize(f32(nxy[0]), W_in);
      var y = gs_denormalize(f32(nxy[1]), H_in);

      ${c=u,h=l,f=i,(()=>{switch(f.mode){case"nearest":return`
          let result = pixel_at_grid(i32(round(y)), i32(round(x)), H_in, W_in, indices[${an}], indices[${as}], border);
        `;case"bilinear":return`
          let x1 = i32(floor(x));
          let y1 = i32(floor(y));
          let x2 = x1 + 1;
          let y2 = y1 + 1;

          let p11 = pixel_at_grid(y1, x1, H_in, W_in, indices[${an}], indices[${as}], border);
          let p12 = pixel_at_grid(y1, x2, H_in, W_in, indices[${an}], indices[${as}], border);
          let p21 = pixel_at_grid(y2, x1, H_in, W_in, indices[${an}], indices[${as}], border);
          let p22 = pixel_at_grid(y2, x2, H_in, W_in, indices[${an}], indices[${as}], border);

          let dx2 = ${h}(f32(x2) - x);
          let dx1 = ${h}(x - f32(x1));
          let dy2 = ${h}(f32(y2) - y);
          let dy1 = ${h}(y - f32(y1));
          let result = dy2 * (dx2 * p11 + dx1 * p12) + dy1 * (dx2 * p21 + dx1 * p22);
        `;case"bicubic":return`
          let x0 = i32(floor(x)) - 1;
          let y0 = i32(floor(y)) - 1;
          var p: mat4x4<${h}>;
          for (var h = 0; h < 4; h++) {
            for (var w = 0; w < 4; w++) {
              p[h][w] = pixel_at_grid(h + y0, w + x0, H_in, W_in, indices[${an}], indices[${as}], border);
            }
          }

          let dx = x - f32(x0 + 1);
          let dy = y - f32(y0 + 1);
          let result = gs_bicubic_interpolate(p, dx, dy);
        `;default:throw Error(`mode ${f.mode} is not supported`)}})()+`${c.setByOffset("global_idx","result")}`}
  }`}}))},ap=e=>tb({alignCorners:e.align_corners,mode:e.mode,paddingMode:e.padding_mode,format:e.format})}),n4=M(()=>{"use strict";nf(),ny(),nx(),nv(),nC(),nk(),nS(),ac=(e,t)=>e.length>t&&e[t].dims.length>0?e[t]:void 0,ah=e=>tb({...e}),af=tb({perm:[0,2,1,3]}),am=(e,t,r,i,a,n,s,o)=>{var u,l,d,p,c,h,f;let m,g,y,_=n;if(!(s&&e2.size(s.dims)>0))return 3===n.dims.length&&(_=n.reshape([t,i,r,a])),1===r||1===i?_:e.compute(tP(_,af.perm),{inputs:[_],outputs:[-1]})[0];if(1===i)throw Error("AddBiasReshape is not implemented. Please export your model with packed QKV or KV");return _=(u=e,l=n,d=s,p=t,c=i,h=r*a,f=o,m=[p,c,h],y=[{type:12,data:g=e2.size(m)},{type:12,data:f},{type:12,data:h}],_=u.compute({name:"MultiHeadAttentionAddBias",shaderCache:{inputDependencies:["type","type"]},getRunData:()=>({outputs:[{dims:m,dataType:l.dataType,gpuDataType:0}],dispatchGroup:{x:Math.ceil(g/64)},programUniforms:y}),getShaderSource:e=>{let t=tO("qkv_with_bias",l.dataType,m),r=tA("qkv",l.dataType,m),i=tA("bias",d.dataType,m);return`
  ${e.registerUniforms([{name:"output_size",type:"u32"},{name:"bias_offset",type:"u32"},{name:"hidden_size",type:"u32"}]).declareVariables(r,i,t)}
  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let bias_offset_idx = (global_idx % uniforms.hidden_size) + uniforms.bias_offset;

    qkv_with_bias[global_idx] = qkv[global_idx] + bias[bias_offset_idx];
  }`}},{inputs:[l,d],outputs:[-1]})[0]).reshape([t,i,r,a]),1===r||1===i?_:e.compute(tP(_,af.perm),{inputs:[_],outputs:[-1]})[0]},ag=(e,t)=>{let r=((e,t)=>{let r,i=e[0],a=ac(e,1),n=ac(e,2),s=ac(e,3),o=ac(e,4),u=ac(e,5),l=ac(e,6),d=ac(e,7);if(3!==i.dims.length&&5!==i.dims.length)throw Error("Input query is expected to have 3 or 5 dimensions");let p=i.dims[0],c=i.dims[1],h=3===i.dims.length?i.dims[2]:t.numHeads*i.dims[4],f=c,m=0,g=0,y=Math.floor(h/t.numHeads);if(l&&d&&e2.size(l.dims)&&e2.size(d.dims)){if(4!==l.dims.length)throw Error('Input "past_key" is expected to have 4 dimensions');if(l.dims[0]!==p||l.dims[1]!==t.numHeads||l.dims[3]!==y)throw Error('Input "past_key" shape (batch_size, num_heads, past_sequence_length, head_size)');if(d.dims[0]!==p||d.dims[1]!==t.numHeads||d.dims[3]!==y)throw Error('Input "past_value" shape (batch_size, num_heads, past_sequence_length, head_size)');if(l.dims[2]!==d.dims[2])throw Error('Input "past_key" and "past_value" shall have same dim 2 (past_sequence_length)');if(4!==d.dims.length)throw Error('Input "past_value" is expected to have 4 dimensions');m=l.dims[2],g=l.dims[2]}else if(l&&e2.size(l.dims)||d&&e2.size(d.dims))throw Error('Input "past_key" and "past_value" shall be both present or both absent');if(a&&e2.size(a.dims)>0){if(3!==i.dims.length)throw Error('Input "query" is expected to have 3 dimensions when key is given');if(a.dims.length<3||a.dims.length>5)throw Error('Input "key" is expected to have 3, 4, or 5 dimensions');if(i.dims[0]!==a.dims[0])throw Error('Input "query" and "key" shall have same dim 0 (batch size)');if(3===a.dims.length){if(a.dims[2]!==i.dims[2])throw Error('Input "query" and "key" shall have same dim 2 (hidden_size)');r=2,f=a.dims[1]}else if(5===a.dims.length){if(a.dims[2]!==t.numHeads||2!==a.dims[3]||a.dims[4]!==y)throw Error('Expect "key" shape (batch_size, kv_sequence_length, num_heads, 2, head_size) for packed kv');if(n)throw Error('Expect "value" be none when "key" has packed kv format.');r=5,f=a.dims[1]}else{if(a.dims[1]!==t.numHeads||a.dims[3]!==y)throw Error('Expect "key" shape (batch_size, num_heads, kv_sequence_length, head_size) for past_key');r=0,f=a.dims[2]}}else{if(5!==i.dims.length)throw Error('Input "query" is expected to have 5 dimensions when key is empty');if(i.dims[2]!==t.numHeads||3!==i.dims[3])throw Error('Expect "query" shape (batch_size, kv_sequence_length, num_heads, 3, head_size) for packed kv');r=3}if(s&&e2.size(s.dims)>0){if(1!==s.dims.length)throw Error('Input "bias" is expected to have 1 dimension');if(a&&5===a.dims.length&&2===a.dims[3])throw Error("bias is not allowed for packed kv.")}let _=m+f,b=0;if(o&&e2.size(o.dims)>0){b=8;let e=o.dims;throw 1===e.length?e[0]===p?b=1:e[0]===3*p+2&&(b=3):2===e.length&&e[0]===p&&e[1]===_&&(b=5),8===b?Error('Input "key_padding_mask" shape shall be (batch_size) or (batch_size, total_sequence_length)'):Error("Mask not supported")}let $=!1,v=h;if(n&&e2.size(n.dims)>0){if(3!==n.dims.length&&4!==n.dims.length)throw Error('Input "value" is expected to have 3 or 4 dimensions');if(i.dims[0]!==n.dims[0])throw Error('Input "query" and "value" shall have same dim 0 (batch_size)');if(3===n.dims.length){if(f!==n.dims[1])throw Error('Input "key" and "value" shall have the same dim 1 (kv_sequence_length)');v=n.dims[2]}else{if(f!==n.dims[2])throw Error('Input "key" and "value" shall have the same dim 2 (kv_sequence_length)');v=n.dims[1]*n.dims[3],$=!0}}if(o&&e2.size(o.dims)>0)throw Error("Key padding mask is not supported");if(u&&e2.size(u.dims)>0){if(4!==u.dims.length)throw Error('Input "attention_bias" is expected to have 4 dimensions');if(u.dims[0]!==p||u.dims[1]!==t.numHeads||u.dims[2]!==c||u.dims[3]!==_)throw Error('Expect "attention_bias" shape (batch_size, num_heads, sequence_length, total_sequence_length)')}return{batchSize:p,sequenceLength:c,pastSequenceLength:m,kvSequenceLength:f,totalSequenceLength:_,maxSequenceLength:g,inputHiddenSize:0,hiddenSize:h,vHiddenSize:v,headSize:y,vHeadSize:Math.floor(v/t.numHeads),numHeads:t.numHeads,isUnidirectional:!1,pastPresentShareBuffer:!1,maskFilterValue:t.maskFilterValue,maskType:b,scale:t.scale,broadcastResPosBias:!1,passPastInKv:$,qkvFormat:r}})(e.inputs,t),i=e.inputs[0],a=ac(e.inputs,1),n=ac(e.inputs,2),s=ac(e.inputs,3),o=ac(e.inputs,4),u=ac(e.inputs,5),l=ac(e.inputs,6),d=ac(e.inputs,7);if(5===i.dims.length)throw Error("Packed QKV is not implemented");if(a?.dims.length===5)throw Error("Packed KV is not implemented");let p=a&&n&&4===a.dims.length&&4===n.dims.length,c=am(e,r.batchSize,r.numHeads,r.sequenceLength,r.headSize,i,s,0);if(p)return rh(e,c,a,n,o,void 0,l,d,u,r);if(!a||!n)throw Error("key and value must be provided");let h=am(e,r.batchSize,r.numHeads,r.kvSequenceLength,r.headSize,a,s,r.hiddenSize),f=am(e,r.batchSize,r.numHeads,r.kvSequenceLength,r.vHeadSize,n,s,2*r.hiddenSize);rh(e,c,h,f,o,void 0,l,d,u,r)}}),n6=M(()=>{"use strict";nf(),ny(),nx(),nk(),ay=(e,t)=>{let r=e[0].dims,i=e2.size(r),a=e[0].dataType,n=e2.normalizeAxis(t.axis,r.length),s=Array(t.numOutputs),o=tA("input",a,r.length),u=Array(t.numOutputs),l=[],d=[],p=0,c=[{type:12,data:i}];for(let i=0;i<t.numOutputs;i++){p+=t.splitSizes[i],u[i]=p;let o=r.slice();o[n]=t.splitSizes[i],d.push(o),s[i]=tO(`output${i}`,a,o.length),l.push({dims:d[i],dataType:e[0].dataType})}return c.push({type:12,data:u},...tk(r,...d)),{name:"Split",shaderCache:{hint:t.cacheKey,inputDependencies:["rank"]},getShaderSource:e=>{let t;return`
  ${e.registerUniform("input_size","u32").registerUniform("size_in_split_axis","u32",u.length).declareVariables(o,...s)}
  ${t=u.length,`
fn calculateOutputIndex(index: u32) -> u32 {
    for (var i: u32 = 0u; i < ${t}u; i += 1u ) {
    if (index < ${tC("uniforms.size_in_split_axis","i",t)}) {
        return i;
    }
    }
    return ${t}u;
}`}
  ${(e=>{let t=e.length,r=[];for(let i=0;i<t;++i){let a=e[i].setByIndices("indices","input[global_idx]");1===t?r.push(a):0===i?r.push(`if (output_number == ${i}u) { ${a} }`):i===t-1?r.push(`else { ${a} }`):r.push(`else if (output_number == ${i}) { ${a} }`)}return`
      fn writeBufferData(output_number: u32, indices: ${e[0].type.indices}, global_idx: u32) {
        ${r.join(`
`)}
      }`})(s)}

  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.input_size")}

    var indices = ${o.offsetToIndices("global_idx")};
    var index = ${o.indicesGet("indices",n)};
    let output_number = calculateOutputIndex(index);
    if (output_number != 0) {
      index -= ${tC("uniforms.size_in_split_axis","output_number - 1u",u.length)};
      ${o.indicesSet("indices",n,"index")};
    }
    writeBufferData(output_number, indices, global_idx);
  }`},getRunData:()=>({outputs:l,dispatchGroup:{x:Math.ceil(i/64)},programUniforms:c})}},a_=(e,t)=>{let r,i;var a,n,s=e.inputs;if(!s||s.length<1)throw Error("too few inputs");let o=1===e.inputs.length?t:(a=e.inputs,r=[],i=(n=t).numOutputs,a[1].dims[0]>0&&(a[1].getBigInt64Array().forEach(e=>r.push(Number(e))),i=r.length),tb({numOutputs:i,axis:n.axis,splitSizes:r}));e.compute(ay(e.inputs,o),{inputs:[0]})},ab=e=>{let t=e.axis,r=e.splitSizes,i=e.numOutputs<0?r.length:e.numOutputs;if(i!==r.length)throw Error("numOutputs and splitSizes lengh must be equal");return tb({axis:t,numOutputs:i,splitSizes:r})}}),n8=M(()=>{"use strict";nf(),ny(),nx(),nk(),a$=(e,t)=>{let{interleaved:r,numHeads:i,rotaryEmbeddingDim:a,scale:n}=t,s=e[0].dims[0],o=e2.sizeFromDimension(e[0].dims,1),u=e[0].dims[e[0].dims.length-2],l=o/u,d=e[2].dims[1],p=0===a?2*d:l/i,c=[s,u,l/p,p-d],h=e2.computeStrides(c),f=[{type:1,data:n},{type:12,data:c},{type:12,data:h},...3===e[0].dims.length?Array({type:12,data:[o,l,p,1]}):[],...4===e[0].dims.length?Array({type:12,data:[o,p,u*p,1]}):[],...tk(e[0].dims,e[1].dims,e[2].dims,e[3].dims,e[0].dims)];return{name:"RotaryEmbedding",shaderCache:{hint:tb({interleaved:r}).cacheKey,inputDependencies:["rank","rank","rank","rank"]},getShaderSource:t=>{let i=tA("input",e[0].dataType,e[0].dims.length),a=tA("position_ids",e[1].dataType,e[1].dims.length),n=tA("cos_cache",e[2].dataType,e[2].dims.length),s=tA("sin_cache",e[3].dataType,e[3].dims.length),o=tO("output",e[0].dataType,e[0].dims.length);return t.registerUniforms([{name:"scale",type:"f32"},{name:"global_shape",type:"u32",length:c.length},{name:"global_strides",type:"u32",length:h.length},{name:"input_output_strides",type:"u32",length:h.length}]),`
        ${t.declareVariables(i,a,n,s,o)}

        ${t.mainStart(t$)}
          let half_rotary_emb_dim = uniforms.${n.name}_shape[1];
          let bsnh = global_idx / uniforms.global_strides % uniforms.global_shape;
          let size = uniforms.global_shape[0] * uniforms.global_strides[0];
          ${t.guardAgainstOutOfBoundsWorkgroupSizes("size")}

          if (bsnh[3] < half_rotary_emb_dim) {
            let position_ids_idx =
                ${a.broadcastedIndicesToOffset("bsnh.xy",tO("",a.type.tensor,2))};
            let position_id =
                u32(${a.getByOffset("position_ids_idx")}) + select(0, bsnh[1], position_ids_idx == 0);
            let i = dot(bsnh, uniforms.input_output_strides) + select(0, bsnh[3], ${r});
            let j = i + select(half_rotary_emb_dim, 1, ${r});
            let re = ${i.getByOffset("i")} * ${n.get("position_id","bsnh[3]")} -
                ${i.getByOffset("j")} * ${s.get("position_id","bsnh[3]")};
            ${o.setByOffset("i","re")}
            let im = ${i.getByOffset("i")} * ${s.get("position_id","bsnh[3]")} +
                ${i.getByOffset("j")} * ${n.get("position_id","bsnh[3]")};
            ${o.setByOffset("j","im")}
          } else {
            let k = dot(bsnh, uniforms.input_output_strides) + half_rotary_emb_dim;
            ${o.setByOffset("k",i.getByOffset("k"))}
          }
        }`},getRunData:()=>({outputs:[{dims:e[0].dims,dataType:e[0].dataType}],dispatchGroup:{x:Math.ceil(e2.size(c)/t$)},programUniforms:f})}},av=(e,t)=>{((e,t)=>{let[r,i,a,n]=e,{numHeads:s,rotaryEmbeddingDim:o}=t;if(3!==r.dims.length&&4!==r.dims.length)throw Error(`Input 'x' is expected to have 3 or 4 dimensions, got ${r.dims.length}`);if(!e2.areEqual(i.dims,[])&&!e2.areEqual(i.dims,[1])&&2!==i.dims.length)throw Error(`Input 'position_ids' is expected to have 0, 1, or 2 dimensions, got ${i.dims.length}`);if(2!==a.dims.length)throw Error(`Input 'cos_cache' is expected to have 2 dimensions, got ${a.dims.length}`);if(2!==n.dims.length)throw Error(`Input 'sin_cache' is expected to have 2 dimensions, got ${n.dims.length}`);if(!e2.areEqual(a.dims,n.dims))throw Error("Inputs 'cos_cache' and 'sin_cache' are expected to have the same shape");if(o>0&&0===s)throw Error("num_heads must be provided if rotary_embedding_dim is specified");let u=r.dims[0],l=r.dims[r.dims.length-2],d=a.dims[0],p=e2.sizeFromDimension(r.dims,1)/l,c=0===o?2*a.dims[1]:p/s;if(o>c)throw Error("rotary_embedding_dim must be less than or equal to head_size");if(2===i.dims.length){if(u!==i.dims[0])throw Error(`Input 'position_ids' dimension 0 should be of size batch_size, got ${i.dims[0]}`);if(l!==i.dims[1])throw Error(`Input 'position_ids' dimension 1 should be of size sequence_length, got ${i.dims[1]}`)}if(c/2!==a.dims[1]&&o/2!==a.dims[1])throw Error(`Input 'cos_cache' dimension 1 should be same as head_size / 2 or rotary_embedding_dim / 2, got ${a.dims[1]}`);if(l>d)throw Error("Updating cos_cache and sin_cache in RotaryEmbedding is not currently supported")})(e.inputs,t),e.compute(a$(e.inputs,t))}}),n5=M(()=>{"use strict";nx(),nf(),nC(),n4(),n6(),nS(),n8(),nk(),aw=tb({perm:[0,2,1,3]}),ax=(e,t,r)=>{let i=t,a=r.kvNumHeads;return 3===t.dims.length&&0!==r.kvSequenceLength&&(i=t.reshape([r.batchSize,r.kvSequenceLength,a,r.headSize]),i=e.compute(tP(i,aw.perm),{inputs:[i],outputs:[-1]})[0]),i},ak=(e,t)=>{let r=((e,t)=>{if(t.doRotary&&e.length<=7)throw Error("cos_cache and sin_cache inputs are required if do_rotary is specified");let r=e[0],i=e[1],a=e[2],n=e[3],s=e[4];if(0!==t.doRotary&&e.length<=7)throw Error("cos_cast and sin_cache are expected if do_rotary attribute is non-zero");if(-1!==t.localWindowSize)throw Error("Local attention is not supported");if(0!==t.softcap)throw Error("Softcap is not supported");if(0!==t.rotaryInterleaved)throw Error("Rotary interleaved is not supported");if(t.smoothSoftmax)throw Error("Smooth softmax is not supported");if(3!==r.dims.length&&5!==r.dims.length)throw Error("Input query is expected to have 3 or 5 dimensions");let o=r.dims[0],u=r.dims[1],l=3===r.dims.length?r.dims[2]:t.numHeads*r.dims[4],d=u,p=0,c=!i||0===i.dims.length,h=Math.floor(c?l/(t.numHeads+2*t.kvNumHeads):l/t.numHeads);c&&(l=h*t.numHeads);let f=n&&0!==n.dims.length,m=s&&0!==s.dims.length;if(f&&4===n.dims.length&&n.dims[0]===o&&n.dims[1]!==t.kvNumHeads&&n.dims[2]===t.kvNumHeads&&n.dims[3]===h)throw Error("BSNH pastKey/pastValue is not supported");if(f&&m){if(4!==n.dims.length)throw Error('Input "past_key" is expected to have 4 dimensions');if(4!==s.dims.length)throw Error('Input "past_value" is expected to have 4 dimensions');p=n.dims[2]}else if(f||m)throw Error('Input "past_key" and "past_value" shall be both present or both absent');let g=1;if(i&&i.dims.length>0){if(3!==r.dims.length)throw Error('Input "query" is expected to have 3 dimensions when key is given');if(i.dims.length<3||i.dims.length>5)throw Error('Input "key" is expected to have 3, 4, or 5 dimensions');if(r.dims[0]!==i.dims[0])throw Error('Input "query" and "key" shall have same dim 0 (batch size)');if(3===i.dims.length){if(r.dims[2]%i.dims[2]!=0)throw Error('Dimension 2 of "query" should be a multiple of "key"');d=i.dims[1]}else if(5===i.dims.length){if(i.dims[2]!==t.numHeads||2!==i.dims[3]||i.dims[4]!==h)throw Error('Expect "key" shape (batch_size, kv_sequence_length, num_heads, 2, head_size) for packed kv');if(a)throw Error('Expect "value" be none when "key" has packed kv format.');d=i.dims[1]}else{if(i.dims[1]!==t.numHeads||i.dims[3]!==h)throw Error('Expect "key" shape (batch_size, num_heads, kv_sequence_length, head_size) for past_key');d=i.dims[2]}}else{if(3!==r.dims.length&&5!==r.dims.length)throw Error('Input "query" is expected to have 3 or 5 dimensions when key is empty');if(5===r.dims.length&&(r.dims[2]!==t.numHeads||3!==r.dims[3]))throw Error('Expect "query" shape (batch_size, kv_sequence_length, num_heads, 3, head_size) for packed kv');g=3}let y=!1,_=t.kvNumHeads?h*t.kvNumHeads:l;if(a&&a.dims.length>0){if(3!==a.dims.length&&4!==a.dims.length)throw Error('Input "value" is expected to have 3 or 4 dimensions');if(r.dims[0]!==a.dims[0])throw Error('Input "query" and "value" shall have same dim 0 (batch_size)');if(3===a.dims.length){if(d!==a.dims[1])throw Error('Input "key" and "value" shall have the same dim 1 (kv_sequence_length)');_=a.dims[2]}else{if(d!==a.dims[2])throw Error('Input "past_key" and "past_value" shall have the same dim 2 (kv_sequence_length)');_=a.dims[1]*a.dims[3],y=!0}}let b=e.length>4?e[5]:void 0;if(b&&1!==b.dims.length&&b.dims[0]!==o)throw Error('Input "seqlens" is expected to have 1 dimension and the same dim 0 as batch_size');return{batchSize:o,sequenceLength:u,pastSequenceLength:p,kvSequenceLength:d,totalSequenceLength:-1,maxSequenceLength:-1,inputHiddenSize:0,hiddenSize:l,vHiddenSize:_,headSize:h,vHeadSize:Math.floor(_/t.kvNumHeads),numHeads:t.numHeads,kvNumHeads:t.kvNumHeads,nReps:t.numHeads/t.kvNumHeads,pastPresentShareBuffer:!1,maskType:0,scale:t.scale,broadcastResPosBias:!1,passPastInKv:y,qkvFormat:g}})(e.inputs,t);if(5===e.inputs[0].dims.length)throw Error("Packed QKV is not implemented");if(e.inputs[1]?.dims.length===5)throw Error("Packed KV is not implemented");let i=e.inputs[0],a=e.inputs[1]&&e.inputs[1].dims.length>0?e.inputs[1]:void 0,n=e.inputs[2]&&e.inputs[2].dims.length>0?e.inputs[2]:void 0,s=e.inputs[3]&&0!==e.inputs[3].dims.length?e.inputs[3]:void 0,o=e.inputs[4]&&0!==e.inputs[4].dims.length?e.inputs[4]:void 0,u=e.inputs.length>4?e.inputs[5]:void 0,l=e.inputs.length>5?e.inputs[6]:void 0,d=r.kvNumHeads?r.kvNumHeads:r.numHeads,p=tb({axis:2,numOutputs:3,splitSizes:[r.numHeads*r.headSize,d*r.headSize,d*r.headSize]}),[c,h,f]=a||n?[i,a,n]:e.compute(ay([i],p),{inputs:[i],outputs:[-1,-1,-1]}),m,g;if(t.doRotary){var y,_,b,$;let i,a,n,s=e.compute((y=r.batchSize,_=r.sequenceLength,b=u,$=l,i=[y*_],n=[{type:12,data:a=y*_},{type:12,data:_},{type:12,data:y}],{name:"GeneratePositionIds",shaderCache:{hint:`${y};${_}`,inputDependencies:["type","type"]},getRunData:()=>({outputs:[{dims:i,dataType:7}],dispatchGroup:{x:Math.ceil(a/64)},programUniforms:n}),getShaderSource:e=>{let t=tA("seq_lens",b.dataType,b.dims),r=tA("total_seq_lens",$.dataType,$.dims),a=tO("pos_ids",7,i);return`
  ${e.registerUniforms([{name:"output_size",type:"u32"},{name:"sequence_length",type:"u32"},{name:"batch_size",type:"u32"}]).declareVariables(t,r,a)}
  ${e.mainStart()}
    ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
    let total_sequence_length = u32(${r.getByOffset("0")});
    let is_subsequent_prompt = uniforms.sequence_length > 1 && uniforms.sequence_length != total_sequence_length;
    let is_first_prompt = !is_subsequent_prompt && uniforms.sequence_length == total_sequence_length;
    let batch_idx = global_idx / uniforms.sequence_length;
    let sequence_idx = i32(global_idx % uniforms.sequence_length);
    var pos_id: i32 = 0;
    let seqlen = ${t.getByOffset("batch_idx")};
    let total_seqlen = seqlen + 1;
    if (is_first_prompt) {
      if (sequence_idx < total_seqlen) {
        pos_id = sequence_idx;
      } else {
        pos_id = 1;
      }
      ${a.setByOffset("global_idx","pos_id")}
    } else if (is_subsequent_prompt) {
      let past_seqlen = total_seqlen - i32(uniforms.sequence_length);
      if (past_seqlen + sequence_idx < total_seqlen) {
        pos_id = past_seqlen + sequence_idx;
      } else {
        pos_id = 1;
      }
      ${a.setByOffset("global_idx","pos_id")}
    } else if (global_idx < uniforms.batch_size) {
      ${a.setByOffset("global_idx","seqlen")}
    };
  }
  `}}),{inputs:[u,l],outputs:[-1]})[0],o=e.inputs[7],d=e.inputs[8],p=tb({interleaved:0!==t.rotaryInterleaved,numHeads:r.numHeads,rotaryEmbeddingDim:0,scale:t.scale}),f=[c,s,o,d],v=[-1];m=e.compute(a$(f,p),{inputs:f,outputs:v})[0],f.splice(0,1,h);let w=tb({interleaved:0!==t.rotaryInterleaved,numHeads:r.kvNumHeads,rotaryEmbeddingDim:0,scale:t.scale});g=e.compute(a$(f,w),{inputs:f,outputs:v})[0]}let v=am(e,r.batchSize,r.numHeads,r.sequenceLength,r.headSize,t.doRotary?m:c,void 0,0),w=ax(e,t.doRotary?g:h,r),x=ax(e,f,r);rh(e,v,w,x,void 0,void 0,s,o,void 0,r,u,l)}}),n7=M(()=>{"use strict";nf(),ny(),nS(),nk(),aS=(e,t,r,i,a,n,s,o)=>{let u=tS(n),l=1===u?"f32":`vec${u}f`,d=1===u?"vec2f":`mat2x${u}f`,p=a*s,c=64;1===p&&(c=256);let h=[a,s,n/u],f=[a,s,2],m=[];return m.push(...tk(h,f)),e.compute({name:"InstanceNormComputeChannelScaleShift",shaderCache:{hint:`${u};${o};${c}`,inputDependencies:["rank","type","type"]},getRunData:()=>({outputs:[{dims:f,dataType:1}],dispatchGroup:{x:p},programUniforms:m}),getShaderSource:e=>{let a=tA("x",t.dataType,3,u),n=[a,tA("scale",r.dataType,r.dims),tA("bias",i.dataType,i.dims),tO("output",1,3,2)];return`
  var<workgroup> workgroup_shared : array<${d}, ${c}>;
  const workgroup_size = ${c}u;
  ${e.declareVariables(...n)}
  ${e.mainStart(c)}
    let batch = workgroup_index / uniforms.x_shape[1];
    let channel = workgroup_index % uniforms.x_shape[1];
    let hight = uniforms.x_shape[2];
    // initialize workgroup memory
    var sum = ${l}(0);
    var squared_sum = ${l}(0);
    for (var h = local_idx; h < hight; h += workgroup_size) {
      let value = ${l}(${a.get("batch","channel","h")});
      sum += value;
      squared_sum += value * value;
    }
    workgroup_shared[local_idx] = ${d}(sum, squared_sum);
    workgroupBarrier();

    for (var currSize = workgroup_size >> 1;  currSize > 0; currSize = currSize >> 1) {
      if (local_idx < currSize) {
        workgroup_shared[local_idx] = workgroup_shared[local_idx] + workgroup_shared[local_idx + currSize];
      }
      workgroupBarrier();
    }
    if (local_idx == 0) {
      let sum_final = ${tE("workgroup_shared[0][0]",u)} / f32(hight * ${u});
      let squared_sum_final = ${tE("workgroup_shared[0][1]",u)} / f32(hight * ${u});

      let inv_std_dev = inverseSqrt(squared_sum_final - sum_final * sum_final + f32(${o}));
      let channel_scale = inv_std_dev * f32(scale[channel]);
      let channel_shift = f32(bias[channel]) - sum_final * channel_scale;
      output[workgroup_index] = vec2f(channel_scale, channel_shift);
    }
  }`}},{inputs:[t,r,i],outputs:[-1]})[0]},aT=(e,t)=>{var r,i,a;let n,s,o,u,l,d,p,c,h;"NHWC"===t.format?((e,t,r)=>{let i=t[0].dims,a=i[0],n=i[i.length-1],s=e2.sizeFromDimension(i,1)/n,o=tS(n),u=e2.size(i)/o,l=[{type:12,data:s},{type:12,data:Math.floor(n/o)}],d=!1,p=[0,i.length-1];for(let e=0;e<i.length-2;e++)d=d||1!==i[e+1],p.push(e+1);let c=(d=d&&1!==i[i.length-1])?e.compute(tP(e.inputs[0],p),{inputs:[e.inputs[0]],outputs:[-1]})[0]:e.inputs[0].reshape(Array.from({length:i.length},(e,t)=>i[p[t]])),h=aS(e,c,t[1],t[2],a,s,n,r.epsilon);e.compute({name:"InstanceNormalizationNHWC",shaderCache:{hint:`${o}`,inputDependencies:["type","type"]},getRunData:()=>({outputs:[{dims:i,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(u/64)},programUniforms:l}),getShaderSource:e=>{let r=tw(t[0].dataType),a=1===o?"vec2f":`mat${o}x2f`,n=e=>{let t=0===e?"x":"y",i=1===o?"f32":`vec${o}f`;switch(o){case 1:return`${r}(${i}(scale.${t}))`;case 2:return`vec2<${r}>(${i}(scale[0].${t}, scale[1].${t}))`;case 4:return`vec4<${r}>(${i}(scale[0].${t}, scale[1].${t}, scale[2].${t}, scale[3].${t}))`;default:throw Error(`Not supported compoents ${o}`)}},s=tA("input",t[0].dataType,t[0].dims,o),u=tO("output",t[0].dataType,i,o);return`
  @group(0) @binding(0) var<storage, read> input : array<${s.type.storage}>;
  @group(0) @binding(1) var<storage, read> scale_input : array<${a}>;
  @group(0) @binding(2) var<storage, read_write> output : array<${u.type.storage}>;
  struct Uniforms {H: u32, C : u32};
  @group(0) @binding(3) var<uniform> uniforms: Uniforms;

  ${e.mainStart()}
    let current_image_number = global_idx / (uniforms.C * uniforms.H);
    let current_channel_number = global_idx % uniforms.C;

    let scale_offset = current_image_number * uniforms.C + current_channel_number;
    let scale = scale_input[scale_offset];
    output[global_idx] = fma(input[global_idx], ${n(0)}, ${n(1)});
  }`}},{inputs:[t[0],h]})})(e,e.inputs,t):(r=e,i=e.inputs,a=t,s=(n=i[0].dims)[0],o=n[1],u=e2.sizeFromDimension(n,2),l=tS(u),d=e2.size(n)/l,p=aS(r,i[0],i[1],i[2],s,u,o,a.epsilon),c=[s,o,u/l],h=[s,o],r.compute({name:"InstanceNormalization",shaderCache:{hint:`${l}`,inputDependencies:["type","none"]},getRunData:()=>({outputs:[{dims:n,dataType:i[0].dataType}],dispatchGroup:{x:Math.ceil(d/64)},programUniforms:[{type:12,data:d},...tk(c,h,c)]}),getShaderSource:e=>{let t=tA("x",i[0].dataType,c.length,l),r=tA("scale_shift",1,h.length,2),a=tO("output",i[0].dataType,c.length,l),n=[t,r,a];return`
  ${e.registerUniform("output_size","u32").declareVariables(...n)}
  ${e.mainStart()}
  ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let outputIndices = ${a.offsetToIndices("global_idx")};
      let batch = outputIndices[0];
      let channel = outputIndices[1];
      let scale_shift = ${r.getByIndices("vec2<u32>(batch, channel)")};
      let value = ${t.getByOffset("global_idx")} * ${a.type.value}(scale_shift.x) + ${a.type.value}(scale_shift.y);
      ${a.setByOffset("global_idx","value")};
  }`}},{inputs:[i[0],p]}))}}),n9=M(()=>{"use strict";nf(),ny(),nk(),aI=(e,t)=>{(e=>{if(!e||e.length<2)throw Error("layerNorm requires at least 2 inputs.")})(e.inputs),e.compute(((e,t,r)=>{let i=t.simplified,a=e[0].dims,n=e[1],s=!i&&e[2],o=e2.normalizeAxis(t.axis,a.length),u=e2.sizeToDimension(a,o),l=e2.sizeFromDimension(a,o),d=e2.size(n.dims),p=s?e2.size(s.dims):0;if(d!==l||s&&p!==l)throw Error(`Size of X.shape()[axis:] == ${l}.
       Size of scale and bias (if provided) must match this.
       Got scale size of ${d} and bias size of ${p}`);let c=[];for(let e=0;e<a.length;++e)e<o?c.push(a[e]):c.push(1);let h=tS(l),f=["type","type"],m=[{type:12,data:u},{type:1,data:l},{type:12,data:Math.floor(l/h)},{type:1,data:t.epsilon}];s&&f.push("type");let g=r>1,y=r>2,_=[{dims:a,dataType:e[0].dataType}];return g&&_.push({dims:c,dataType:1}),y&&_.push({dims:c,dataType:1}),{name:"LayerNormalization",shaderCache:{hint:`${h};${r};${i}`,inputDependencies:f},getRunData:()=>({outputs:_,dispatchGroup:{x:Math.ceil(u/64)},programUniforms:m}),getShaderSource:t=>{let r=tw(e[0].dataType),o=[tA("x",e[0].dataType,e[0].dims,h),tA("scale",n.dataType,n.dims,h)];return s&&o.push(tA("bias",s.dataType,s.dims,h)),o.push(tO("output",e[0].dataType,a,h)),g&&o.push(tO("mean_data_output",1,c)),y&&o.push(tO("inv_std_output",1,c)),`
  ${t.registerUniforms([{name:"norm_count",type:"u32"},{name:"norm_size",type:"f32"},{name:"norm_size_vectorized",type:"u32"},{name:"epsilon",type:"f32"}]).declareVariables(...o)}
  ${t.mainStart()}
    ${t.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.norm_count")}
    let offset = global_idx * uniforms.norm_size_vectorized;
    var mean_vector = ${tT("f32",h)};
    var mean_square_vector = ${tT("f32",h)};

    for (var h: u32 = 0u; h < uniforms.norm_size_vectorized; h++) {
      let value = ${tI(r,h,"x[h + offset]")};
      mean_vector += value;
      mean_square_vector += value * value;
    }
    let mean = ${tE("mean_vector",h)} / uniforms.norm_size;
    let inv_std_dev = inverseSqrt(${tE("mean_square_vector",h)} / uniforms.norm_size ${i?"":"- mean * mean"} + uniforms.epsilon);

    for (var j: u32 = 0; j < uniforms.norm_size_vectorized; j++) {
      let f32input = ${tI(r,h,"x[j + offset]")};
      let f32scale = ${tI(r,h,"scale[j]")};
      output[j + offset] = ${o[0].type.value}((f32input ${i?"":"- mean"}) * inv_std_dev * f32scale
        ${s?`+ ${tI(r,h,"bias[j]")}`:""}
      );
    }

    ${g?"mean_data_output[global_idx] = mean":""};
    ${y?"inv_std_output[global_idx] = inv_std_dev":""};
  }`}}})(e.inputs,t,e.outputCount))}}),se=M(()=>{"use strict";ny(),nU(),nq(),aE=e=>{var t=e.inputs;if(!t||2!==t.length)throw Error("MatMul requires 2 inputs.");if(t[0].dims[t[0].dims.length-1]!==t[1].dims[t[1].dims.length-2])throw Error("shared dimension does not match.");let r=e0.calcShape(e.inputs[0].dims,e.inputs[1].dims,!0);if(!r)throw Error("Can't use matmul on the given tensors");let i=r[r.length-1],a=e.inputs[0].dims[e.inputs[0].dims.length-1];if(i<8&&a<8)e.compute(ib(e.inputs,{activation:""},r));else{let t=r[r.length-2],n=e2.size(e.inputs[0].dims.slice(0,-2)),s=e2.size(e.inputs[1].dims.slice(0,-2));if(1!==n&&1===t&&1===s){let t=e.inputs[0].reshape([1,n,a]),s=e.inputs[1].reshape([1,a,i]),o=[1,n,i],u=[t,s];e.compute(ix(u,{activation:""},r,o),{inputs:u})}else e.compute(ix(e.inputs,{activation:""},r))}}}),st=M(()=>{"use strict";nf(),ny(),nx(),nk(),aC=(e,t)=>{var r,i,a,n;let s,o,u,l,d,p,c,h,f,m,g,y,_,b,$,v,w,x,k,S,T,I,E,C,z,A,O,R,B,N,D,M,P,U,q,W,L,V,G,H,F;((e,t)=>{if(e.length<3||e.length>4)throw Error("MatMulNBits requires 3 or 4 inputs");let r=e[0],i=r.dims.length;if(r.dims[i-1]!==t.k)throw Error("The last dim of input shape does not match the k value");let a=Math.floor((t.k+t.blockSize-1)/t.blockSize),n=t.blockSize/8*t.bits,s=e[1];if(!e2.areEqual(s.dims,[t.n,a,n]))throw Error("The second inputs must be 3D tensor with shape N X nBlocksPerCol X blobSize");let o=e[2].dims;if(e2.size(o)!==t.n*a)throw Error("scales input size error.");if(4===e.length){let r=e[3].dims,i=t.bits>4?t.n*a:t.n*Math.floor((a+1)/2);if(e2.size(r)!==i)throw Error("zeroPoints input size error.")}})(e.inputs,t),32===t.blockSize&&e.adapterInfo.isVendor("intel")&&e.adapterInfo.isArchitecture("gen-12lp")?e.compute((r=e.inputs,i=t,o=(s=r[0].dims).length,u=s[o-2],l=i.k,d=i.n,p=s.slice(0,o-2),c=e2.size(p),h=r[1].dims[2]/4,f=r[0].dataType,m=tS(i.k),g=tS(h),y=p.concat([u,d]),v=($=(b=128/(_=d%8==0?8:d%4==0?4:1))*g*8)/m,w=$/i.blockSize,x=e2.size(y)/_,k=[],S=[c,u,l/m],(T=e2.convertShape(r[1].dims).slice()).splice(-1,1,h/g),k.push(...tk(S)),k.push(...tk(T)),k.push(...tk(r[2].dims)),4===r.length&&k.push(...tk(e2.convertShape(r[3].dims))),I=[c,u,d],k.push(...tk(I)),{name:"BlockwiseMatMulNBits32",shaderCache:{hint:`${i.blockSize};${m};${g};${b};${_}`,inputDependencies:Array(r.length).fill("rank")},getRunData:()=>({outputs:[{dims:y,dataType:f}],dispatchGroup:{x:x},programUniforms:k}),getShaderSource:e=>{let t=S.length,a=tA("a",r[0].dataType,t,m),n=tA("b",12,T.length,g),s=tA("scales",r[2].dataType,r[2].dims.length),o=[a,n,s],u=4===r.length?tA("zero_points",12,r[3].dims.length):void 0;u&&o.push(u);let l=I.length,d=tO("output",r[0].dataType,l),p=tw(r[0].dataType);return`
        var<workgroup> sub_a: array<${a.type.value}, ${v}>;
        var<workgroup> inter_results: array<array<${d.type.value}, ${b}>, ${_}>;
        ${e.declareVariables(...o,d)}
        ${e.mainStart([b,_,1])}
          let output_indices = ${d.offsetToIndices(`workgroup_index * ${_}`)};
          let col = output_indices[2];
          let row = output_indices[1];
          let batch = output_indices[0];
          let n_blocks_per_col = uniforms.b_shape[1];
          let num_tiles =  (n_blocks_per_col - 1) / ${w} + 1;

          // Loop over shared dimension.
          for (var tile: u32 = 0; tile < num_tiles; tile += 1) {
            let a_col_start = tile * ${v};
            // load one tile A data into shared memory.
            for (var a_offset = local_idx; a_offset < ${v}; a_offset += 128)
            {
              let a_col = a_col_start + a_offset;
              if (a_col < uniforms.a_shape[2])
              {
                sub_a[a_offset] = ${a.getByIndices(`${a.type.indices}(batch, row, a_col)`)};
              } else {
                sub_a[a_offset] = ${a.type.value}(0);
              }
            }
            workgroupBarrier();

            // each thread process one block
            let b_row = col + local_id.y;
            let block = tile * ${w} + local_id.x;
            ${u?`
            let zero_point_bytes_per_col = (n_blocks_per_col + 1) / 2;
            let zero_point_byte_count = b_row * zero_point_bytes_per_col + (block >> 0x1u);
            let zero_point_word_index = zero_point_byte_count >> 0x2u;
            let zero_point_byte_offset = zero_point_byte_count & 0x3u;
            let zero_point_nibble_offset: u32 = block & 0x1u;
            let zero_point_bits_offset = (zero_point_byte_offset << 3) + (zero_point_nibble_offset << 2);
            let zero_point_word = ${u.getByOffset("zero_point_word_index")} >> zero_point_bits_offset;
            let zero_point = ${p}((zero_point_word) & 0xFu);`:`
            // The default zero point is 8 for unsigned 4-bit quantization.
            let zero_point = ${p}(8);`}
            let scale = ${s.getByOffset("b_row * n_blocks_per_col + block")};
            let b_data = ${n.getByIndices(`${n.type.indices}(b_row, block, 0)`)};
            var word_offset = local_id.x * ${i.blockSize/m};
            for (var i: u32 = 0; i < ${g}; i++) {
              ${(()=>{switch(m){case 1:return`
          let a_data0 = vec4<${p}>(sub_a[word_offset], sub_a[word_offset + 1], sub_a[word_offset + 2], sub_a[word_offset + 3]);
          let a_data1 = vec4<${p}>(sub_a[word_offset + 4], sub_a[word_offset + 5], sub_a[word_offset + 6], sub_a[word_offset + 7]);`;case 2:return`
          let a_data0 = vec4<${p}>(sub_a[word_offset], sub_a[word_offset + 1]);
          let a_data1 = vec4<${p}>(sub_a[word_offset + 2], sub_a[word_offset + 3]);`;case 4:return`
          let a_data0 = sub_a[word_offset];
          let a_data1 = sub_a[word_offset + 1];`;default:throw Error(`${m}-component is not supported.`)}})()}
              let b_value = ${1===g?"b_data":"b_data[i]"};
              let b_value_lower = unpack4xU8(b_value & 0x0F0F0F0Fu);
              let b_value_upper = unpack4xU8((b_value >> 4) & 0x0F0F0F0Fu);
              let b_quantized_values = mat2x4<${p}>(${Array.from({length:4},(e,t)=>`${p}(b_value_lower[${t}]), ${p}(b_value_upper[${t}])`).join(", ")});
              let b_dequantized_values = (b_quantized_values - mat2x4<${p}>(${Array(8).fill("zero_point").join(",")})) * scale;
              inter_results[local_id.y][local_id.x] += ${Array.from({length:2},(e,t)=>`dot(a_data${t}, b_dequantized_values[${t}])`).join(" + ")};
              word_offset += ${8/m};
            }
            workgroupBarrier();
          }

          if (local_idx < ${_}) {
            var output_value: ${d.type.value} = ${d.type.value}(0);
            for (var b = 0u; b < ${b}; b++) {
              output_value += inter_results[local_idx][b];
            }
            if (col + local_idx < uniforms.output_shape[2])
            {
              ${d.setByIndices(`${d.type.indices}(batch, row, col + local_idx)`,"output_value")}
            }
          }
        }`}})):e.compute((a=e.inputs,n=t,C=(E=a[0].dims).length,z=E[C-2],A=n.k,O=n.n,R=E.slice(0,C-2),B=e2.size(R),N=a[1].dims[2]/4,D=a[0].dataType,M=tS(n.k),P=tS(N),U=tS(O),q=R.concat([z,O]),W=z>1&&O/U%2==0?2:1,L=e2.size(q)/U/W,V=[],G=[B,z,A/M],(H=e2.convertShape(a[1].dims).slice()).splice(-1,1,N/P),V.push(...tk(G)),V.push(...tk(H)),V.push(...tk(a[2].dims)),4===a.length&&V.push(...tk(e2.convertShape(a[3].dims))),F=[B,z,O/U],V.push(...tk(F)),{name:"MatMulNBits",shaderCache:{hint:`${n.blockSize};${n.bits};${M};${P};${U};${W};64`,inputDependencies:Array(a.length).fill("rank")},getRunData:()=>({outputs:[{dims:q,dataType:D}],dispatchGroup:{x:L},programUniforms:V}),getShaderSource:e=>{let t=G.length,r=tA("a",a[0].dataType,t,M),i=tA("b",12,H.length,P),s=tA("scales",a[2].dataType,a[2].dims.length),o=[r,i,s],u=4===a.length?tA("zero_points",12,a[3].dims.length):void 0;u&&o.push(u);let l=F.length,d=tO("output",a[0].dataType,l,U),p=tw(a[0].dataType),c=(()=>{switch(M){case 1:return`array<${p}, 8>`;case 2:return`mat4x2<${p}>`;case 4:return`mat2x4<${p}>`;default:throw Error(`${M}-component is not supported.`)}})();return`
        var<workgroup> workgroup_shared: array<${d.type.value}, ${64*W}>;
        ${e.declareVariables(...o,d)}
        ${e.mainStart([64,1,1])}
          let output_indices = ${d.offsetToIndices(`(global_idx / 64) * ${W}`)};
          let col = output_indices[2];
          let row = output_indices[1];
          let batch = output_indices[0];
          let nBlocksPerCol = uniforms.b_shape[1];

          for (var block = local_id.x; block < nBlocksPerCol; block += 64) {
            //process one block
            var word_offset: u32 = block * ${n.blockSize/M};
            ${(()=>{let e=`
            var col_index = col * ${U};
            ${u?`
            let zero_point_bytes_per_col = (nBlocksPerCol + 1) / 2;
            var zero_point_byte_count: u32;
            var zero_point_word_index: u32;
            var zero_point_byte_offset: u32;
            let zero_point_nibble_offset: u32 = block & 0x1u;
            var zero_point_bits_offset: u32;
            var zero_point_word: u32;`:`
            // The default zero point is 8 for unsigned 4-bit quantization.
            let zero_point = ${p}(8);`}
            `;for(let t=0;t<U*W;t++)e+=`
            let scale${t} = ${s.getByOffset("col_index * nBlocksPerCol + block")};
            ${u?`
            zero_point_byte_count = col_index * zero_point_bytes_per_col + (block >> 0x1u);
            zero_point_word_index = zero_point_byte_count >> 0x2u;
            zero_point_byte_offset = zero_point_byte_count & 0x3u;
            zero_point_bits_offset = (zero_point_byte_offset << 3) + (zero_point_nibble_offset << 2);
            zero_point_word = ${u.getByOffset("zero_point_word_index")} >> zero_point_bits_offset;
            let zero_point${t} = ${p}((zero_point_word) & 0xFu);`:""}
            col_index += 1;`;return e})()}
            for (var word: u32 = 0; word < ${N}; word += ${P}) {
              ${(()=>{let e=`col_index = col * ${U};`;for(let t=0;t<U*W;t++)e+=`
            let b${t}_data = ${i.getByIndices(`${i.type.indices}(col_index, block, word)`)};
            col_index += 1;`;return e+`
            var b_value: u32;
            let b_mask: u32 = 0x0F0F0F0Fu;
            var b_value_lower: vec4<u32>;
            var b_value_upper: vec4<u32>;
            var b_quantized_values: ${c};
            var b_dequantized_values: ${c};`})()}
              for (var i: u32 = 0; i < ${P}; i++) {
                ${(()=>{let e=`
          // reuse a data
            var input_offset = ${r.indicesToOffset(`${r.type.indices}(batch, row, word_offset)`)};
            var a_data: ${c};
            for (var j: u32 = 0; j < ${8/M}; j++) {
              a_data[j] = ${r.getByOffset("input_offset")};
              input_offset++;
            }
          `;for(let t=0;t<U*W;t++)e+=`
            b_value = ${1===P?`b${t}_data`:`b${t}_data[i]`};
            b_value_lower = unpack4xU8(b_value & b_mask);
            b_value_upper = unpack4xU8((b_value >> 4) & b_mask);
            b_quantized_values = ${c}(${Array.from({length:4},(e,t)=>`${p}(b_value_lower[${t}]), ${p}(b_value_upper[${t}])`).join(", ")});
            b_dequantized_values = ${1===M?`${c}(${Array.from({length:8},(e,r)=>`(b_quantized_values[${r}] - ${u?`zero_point${t}`:"zero_point"}) * scale${t}`).join(", ")});`:`(b_quantized_values - ${c}(${Array(8).fill(`${u?`zero_point${t}`:"zero_point"}`).join(",")})) * scale${t};`};
            workgroup_shared[local_id.x * ${W} + ${Math.floor(t/U)}]${U>1?`[${t%U}]`:""} += ${Array.from({length:8/M},(e,t)=>`${1===M?`a_data[${t}] * b_dequantized_values[${t}]`:`dot(a_data[${t}], b_dequantized_values[${t}])`}`).join(" + ")};
          `;return e})()}
                word_offset += ${8/M};
              }
            }
          }
          workgroupBarrier();

          if (local_id.x < ${W}) {
            var output_value: ${d.type.value} = ${d.type.value}(0);
            var workgroup_shared_offset: u32 = local_id.x;
            for (var b: u32 = 0u; b < 64u; b++) {
              output_value += workgroup_shared[workgroup_shared_offset];
              workgroup_shared_offset += ${W};
            }
            ${d.setByIndices(`${d.type.indices}(batch, row, col + local_id.x)`,"output_value")};
          }
        }`}}))},az=e=>tb(e)}),sr=M(()=>{"use strict";nf(),ny(),nk(),aA=(e,t)=>{let r,i,a,n;var s,o,u=e.inputs;if(!u||u.length<1)throw Error("Too few inputs");if(1!==u[0].dataType&&10!==u[0].dataType)throw Error("Input type must be float or float16.");if(u.length>=2){let e=2*u[0].dims.length===u[1].dims[0];if(4===u.length&&(e=2*u[3].dims[0]===u[1].dims[0]),!e)throw Error("The pads should be a 1D tensor of shape [2 * input_rank] or [2 * num_axes].")}let l=((e,t)=>{if(!(e.length>1))return t;{let r=e[1].getBigInt64Array(),i=e.length>=3&&e[2].data?10===e[2].dataType?e[2].getUint16Array()[0]:e[2].getFloat32Array()[0]:0,a=e[0].dims.length,n=new Int32Array(2*a).fill(0);if(e.length>=4){let t=e[3].getBigInt64Array();for(let e=0;e<t.length;e++)n[Number(t[e])]=Number(r[e]),n[Number(t[e])+a]=Number(r[e+t.length])}else r.forEach((e,t)=>n[Number(t)]=Number(e));let s=[];return n.forEach(e=>s.push(e)),{mode:t.mode,value:i,pads:s}}})(e.inputs,t);e.compute((s=e.inputs,o=l,r=e2.padShape(s[0].dims.slice(),o.pads),i=s[0].dims,a=[{type:12,data:e2.size(r)},{type:6,data:o.pads}],n=s.length>=3&&s[2].data,0===o.mode&&a.push({type:n?s[2].dataType:1,data:o.value}),a.push(...tk(s[0].dims,r)),{name:"Pad",shaderCache:{hint:`${o.mode}${n}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:r,dataType:s[0].dataType}],dispatchGroup:{x:Math.ceil(e2.size(r)/64)},programUniforms:a}),getShaderSource:e=>{let t=tO("output",s[0].dataType,r.length),a=tA("x",s[0].dataType,i.length),u=a.type.value,l=((e,t,r)=>{switch(r.mode){case 0:var i=e,a=t,n=r.pads.length;let s="";for(let e=a-1;e>=0;--e)s+=`
            k = i32(${i.indicesGet("indices",e)}) - ${tC("uniforms.pads",e,n)};
            if (k < 0) {
              break;
            }
            if (k >= i32(${tC("uniforms.x_shape",e,a)})) {
              break;
            }
            offset += k * i32(${tC("uniforms.x_strides",e,a)});
        `;return`
          value = ${i.type.value}(uniforms.constant_value);
          for (var i = 0; i < 1; i++) {
            var offset = 0;
            var k = 0;
            ${s}
            value = x[offset];
          }
      `;case 1:var o=e,u=t,l=r.pads.length;let d="";for(let e=u-1;e>=0;--e)d+=`
                k = i32(${o.indicesGet("indices",e)}) - ${tC("uniforms.pads",e,l)};
                if (k < 0) {
                  k = -k;
                }
                {
                  let _2n_1 = 2 * (i32(${tC("uniforms.x_shape",e,u)}) - 1);
                  k = k % _2n_1;
                  if(k >= i32(${tC("uniforms.x_shape",e,u)})) {
                    k = _2n_1 - k;
                  }
                }
                offset += k * i32(${tC("uniforms.x_strides",e,u)});
            `;return`
              var offset = 0;
              var k = 0;
              ${d}
              value = x[offset];
          `;case 2:var p=e,c=t,h=r.pads.length;let f="";for(let e=c-1;e>=0;--e)f+=`
                k = i32(${p.indicesGet("indices",e)}) - ${tC("uniforms.pads",e,h)};
                if (k < 0) {
                  k = 0;
                }
                if (k >= i32(${tC("uniforms.x_shape",e,c)})) {
                  k = i32(${tC("uniforms.x_shape",e,c)}) - 1;
                }
                offset += k * i32(${tC("uniforms.x_strides",e,c)});
            `;return`
              var offset = 0;
              var k = 0;
              ${f}
              value = x[offset];
          `;case 3:var m=e,g=t,y=r.pads.length;let _="";for(let e=g-1;e>=0;--e)_+=`
                k = i32(${m.indicesGet("indices",e)}) - ${tC("uniforms.pads",e,y)};
                if (k < 0)  {
                  k += i32(${tC("uniforms.x_shape",e,g)}]);
                }
                if (k >= i32(${tC("uniforms.x_shape",e,g)})) {
                  k -= i32(${tC("uniforms.x_shape",e,g)});
                }
                offset += k * i32(${tC("uniforms.x_strides",e,g)});
            `;return`
              var offset = 0;
              var k = 0;
              ${_}
              value = x[offset];
          `;default:throw Error("Invalid mode")}})(t,i.length,o),d=[{name:"output_size",type:"u32"},{name:"pads",type:"i32",length:o.pads.length}];return 0===o.mode&&d.push({name:"constant_value",type:n?u:"f32"}),`
            ${e.registerUniforms(d).declareVariables(a,t)}
            ${e.mainStart()}
            ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}

            let indices = ${t.offsetToIndices("global_idx")};

            var value = ${u}(0);
            ${l}
            output[global_idx] = value;
        }`}}),{inputs:[0]})}}),si=M(()=>{"use strict";en(),nf(),ny(),nk(),aO=e=>{if(h.webgpu.validateInputContent&&(!e||1!==e.length))throw Error("Pool ops requires 1 input.")},aR=(e,t,r)=>{let i="NHWC"===t.format,a=e.dims.slice();i&&a.splice(1,0,a.pop());let n=Object.hasOwnProperty.call(t,"dilations"),s=t.kernelShape.slice(),o=t.strides.slice(),u=n?t.dilations.slice():[],l=t.pads.slice();e1.adjustPoolAttributes(r,a,s,o,u,l);let d=e1.computePoolOutputShape(r,a,o,u,s,l,t.autoPad),p=Object.assign({},t);n?Object.assign(p,{kernelShape:s,strides:o,pads:l,dilations:u,cacheKey:t.cacheKey}):Object.assign(p,{kernelShape:s,strides:o,pads:l,cacheKey:t.cacheKey});let c=d.slice();return c.push(c.splice(1,1)[0]),[p,i?c:d]},aB=(e,t)=>{let r="NHWC"===t.format,i=[{type:12,data:e2.size(e)},{type:12,data:e2.size(t.kernelShape)}],a=[{name:"outputSize",type:"u32"},{name:"kernelSize",type:"u32"}];if(t.kernelShape.length<=2){let e=t.kernelShape[t.kernelShape.length-1],r=t.strides[t.strides.length-1],n=t.pads[t.pads.length/2-1],s=t.pads[t.pads.length-1],o=!!(n+s);i.push({type:12,data:e},{type:12,data:r},{type:12,data:n},{type:12,data:s}),a.push({name:"kw",type:"u32"},{name:"sw",type:"u32"},{name:"pwStart",type:"u32"},{name:"pwEnd",type:"u32"});let u=!1;if(2===t.kernelShape.length){let e=t.kernelShape[t.kernelShape.length-2],r=t.strides[t.strides.length-2],n=t.pads[t.pads.length/2-2],s=t.pads[t.pads.length-2];u=!!(n+s),i.push({type:12,data:e},{type:12,data:r},{type:12,data:n},{type:12,data:s}),a.push({name:"kh",type:"u32"},{name:"sh",type:"u32"},{name:"phStart",type:"u32"},{name:"phEnd",type:"u32"})}return[i,a,!0,o,u]}{if(r)throw Error("Pooling with kernelShape.length > 2 is not supported for NHWC format.");let e=e2.computeStrides(t.kernelShape);return i.push({type:12,data:e},{type:12,data:t.pads},{type:12,data:t.strides}),a.push({name:"kernelStrides",type:"u32",length:e.length},{name:"pads",type:"u32",length:t.pads.length},{name:"strides",type:"u32",length:t.strides.length}),[i,a,!!t.pads.reduce((e,t)=>e+t),!1,!1]}},aN=(e,t,r,i,a,n,s,o,u,l,d,p)=>{let c="NHWC"===a.format,h=t.type.value,f=tO("output",t.type.tensor,i);if(a.kernelShape.length<=2){let i="",l="",m="",g=r-(c?2:1);if(i=d?`
                for (var i: u32 = 0u; i < uniforms.kw; i++) {
                  xIndices[${g}] = indices[${g}] * uniforms.sw - uniforms.pwStart + i;
                  if (xIndices[${g}] < 0 || xIndices[${g}]
                      >= uniforms.x_shape[${g}]) {
                    pad++;
                    continue;
                  }
                  let x_val = x[${t.indicesToOffset("xIndices")}];
                  ${n}
                }`:`
                for (var i: u32 = 0u; i < uniforms.kw; i++) {
                  xIndices[${g}] = indices[${g}] * uniforms.sw - uniforms.pwStart + i;
                  let x_val = x[${t.indicesToOffset("xIndices")}];
                  ${n}
                }`,2===a.kernelShape.length){let e=r-(c?3:2);l=p?`
                for (var j: u32 = 0u; j < uniforms.kh; j++) {
                  xIndices[${e}] = indices[${e}] * uniforms.sh - uniforms.phStart + j;
                  if (xIndices[${e}] < 0 || xIndices[${e}] >= uniforms.x_shape[${e}]) {
                    pad += i32(uniforms.kw);
                    continue;
                  }
              `:`
                for (var j: u32 = 0u; j < uniforms.kh; j++) {
                  xIndices[${e}] = indices[${e}] * uniforms.sh - uniforms.phStart + j;
                `,m=`
              }
            `}return`
            ${e.registerUniforms(u).declareVariables(t,f)}

            ${e.mainStart()}
              ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}

              let indices = ${f.offsetToIndices("global_idx")};
              var xIndices = ${f.offsetToIndices("global_idx")};

              var value = ${h}(${o});
              var pad = 0;
              ${l}
              ${i}
              ${m}
              ${s}

              output[global_idx] = value;
            }`}{if(c)throw Error("Pooling with kernelShape.length > 2 is not supported for NHWC format.");let i=a.kernelShape.length,d=a.pads.length,p="";return p=l?`
                if (xIndices[j] >= uniforms.x_shape[j]) {
                  pad++;
                  isPad = true;
                  break;
                }
              }
              if (!isPad) {
                let x_val = x[${t.indicesToOffset("xIndices")}];
                ${n}
              }`:`
              }
              let x_val = x[${t.indicesToOffset("xIndices")}];
              ${n}
            `,`
            ${e.registerUniforms(u).declareVariables(t,f)}

            ${e.mainStart()}
              ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
              let indices = ${f.offsetToIndices("global_idx")};
              var xIndices = ${f.offsetToIndices("global_idx")};

              var offsets: array<u32, ${i}>;

              var value = ${h}(${o});
              var pad = 0;
              var isPad = false;

              for (var i: u32 = 0u; i < uniforms.kernelSize; i++) {
                var offset = i;
                for (var j = 0u; j < ${i-1}u; j++) {
                  offsets[j] = offset / ${tC("uniforms.kernelStrides","j",i)};
                  offset -= offsets[j] * ${tC("uniforms.kernelStrides","j",i)};
                }
                offsets[${i-1}] = offset;

                isPad = false;
                for (var j = ${r-i}u; j < ${r}u; j++) {
                  xIndices[j] = indices[j] * ${tC("uniforms.strides",`j - ${r-i}u`,i)}
                    + offsets[j - ${r-i}u] - ${tC("uniforms.pads","j - 2u",d)};
                  ${p}
              }
              ${s}

              output[global_idx] = value;
            }`}},aD=e=>`${e.format};${e.ceilMode};${e.autoPad};${e.kernelShape.length}`,aM=e=>({format:e.format,autoPad:["NOTSET","VALID","SAME_UPPER","SAME_LOWER"][e.auto_pad],ceilMode:e.ceil_mode,kernelShape:e.kernel_shape,strides:e.strides,pads:e.pads}),aP=(e,t,r,i)=>{let[a,n]=aR(t,i,r),s=tA("x",t.dataType,t.dims.length),o=s.type.value,u="";a.countIncludePad?u+=`value /= ${o}(uniforms.kernelSize);`:u+=`value /= ${o}(i32(uniforms.kernelSize) - pad);`;let[l,d,p,c,h]=aB(n,a);return l.push(...tk(t.dims,n)),{name:e,shaderCache:{hint:`${i.cacheKey};${p};${c};${h}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:n,dataType:t.dataType}],dispatchGroup:{x:Math.ceil(e2.size(n)/64)},programUniforms:l}),getShaderSource:e=>aN(e,s,t.dims.length,n.length,a,"value += x_val;",u,0,d,p,c,h)}},aU=e=>{let t,r=0!==e.count_include_pad,i=aM(e);if(0!==i.ceilMode)throw Error("using ceil() in shape computation is not yet supported for AveragePool");let a={countIncludePad:r,...i,cacheKey:""};return{...a,cacheKey:(t=a,`${aD(t)};${t.countIncludePad}`)}},aq=(e,t)=>{aO(e.inputs),e.compute(aP("AveragePool",e.inputs[0],!1,t))},aW={autoPad:"",ceilMode:0,countIncludePad:!1,kernelShape:[],strides:[],pads:[],storageOrder:0,dilations:[]},aL=e=>{let t=e.format;return{format:t,...aW,cacheKey:t}},aV=(e,t)=>{aO(e.inputs),e.compute(aP("GlobalAveragePool",e.inputs[0],!0,t))},aG=(e,t,r,i)=>{let[a,n]=aR(t,i,r),s=`
      value = max(x_val, value);
    `,o=tA("x",t.dataType,t.dims.length),[u,l,d,p,c]=aB(n,a);return u.push(...tk(t.dims,n)),{name:e,shaderCache:{hint:`${i.cacheKey};${d};${p};${c}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:n,dataType:t.dataType}],dispatchGroup:{x:Math.ceil(e2.size(n)/64)},programUniforms:u}),getShaderSource:e=>aN(e,o,t.dims.length,n.length,a,s,"",10===t.dataType?-65504:-1e5,l,d,p,c)}},aH=(e,t)=>{aO(e.inputs),e.compute(aG("MaxPool",e.inputs[0],!1,t))},aF=e=>{let t,r=e.storage_order,i=e.dilations,a=aM(e);if(0!==r)throw Error("column major storage order is not yet supported for MaxPool");if(0!==a.ceilMode)throw Error("using ceil() in shape computation is not yet supported for MaxPool");let n={storageOrder:r,dilations:i,...a,cacheKey:""};return{...n,cacheKey:(t=n,`${aD(t)};${t.storageOrder};${t.dilations}`)}},aj=e=>{let t=e.format;return{format:t,...aW,cacheKey:t}},aK=(e,t)=>{aO(e.inputs),e.compute(aG("GlobalMaxPool",e.inputs[0],!0,t))}}),sa=M(()=>{"use strict";nf(),ny(),nx(),nk(),aZ=(e,t)=>{var r,i;let a,n,s,o,u,l,d,p,c,h,f,m,g,y,_,b,$,v,w,x,k,S,T;((e,t)=>{if(e.length<2||e.length>3)throw Error("DequantizeLinear requires 2 or 3 inputs.");if(3===e.length&&e[1].dims===e[2].dims)throw Error("x-scale and x-zero-point must have the same shape.");if(3===e.length&&e[0].dataType!==e[2].dataType)throw Error("x and x-zero-point must have the same data type.");if(6===e[0].dataType&&e.length>2)throw Error("In the case of dequantizing int32 there is no zero point.");if(0!==e[1].dims.length&&1!==e[1].dims.length&&e[1].dims.length!==e[0].dims.length)throw Error("scale input must be a scalar, a 1D tensor, or have the same rank as the input tensor.");if(e.length>2){if(e[0].dataType!==e[2].dataType)throw Error("x and x-zero-point must have the same data type.");if(e[1].dims.length!==e[2].dims.length)throw Error("scale and zero-point inputs must have the same rank.");if(!e[1].dims.map((t,r)=>t===e[2].dims[r]).reduce((e,t)=>e&&t,!0))throw Error("scale and zero-point inputs must have the same shape.")}if(t.blockSize>0){if(0===e[1].dims.length||1===e[1].dims.length&&1===e[1].dims[0])throw Error("blockSize must be set only for block quantization.");if(!e[1].dims.map((r,i)=>i===t.axis||r===e[0].dims[i]).reduce((e,t)=>e&&t,!0))throw Error("For block qunatization, scale input shape to match the input shape except for the axis");if(e[1].dims.length!==e[0].dims.length)throw Error("For block qunatization the scale input rank must be the same as the x rank.");let r=e[0].dims[t.axis],i=e[1].dims[t.axis];if(t.blockSize<Math.ceil(r/i)||t.blockSize>Math.ceil(r/(i-1)-1))throw Error("blockSize must be with in the range [ceil(dI / Si), ceil(dI / (Si - 1) - 1)].")}})(e.inputs,t),e.compute((r=e.inputs,i=t,a=e2.normalizeAxis(i.axis,r[0].dims.length),s=3===(n=r[0].dataType),o=r[0].dims,u=r[1].dataType,l=e2.size(o),p=(d=3===n||2===n)?[Math.ceil(e2.size(r[0].dims)/4)]:r[0].dims,c=r[1].dims,f=(h=r.length>2?r[2]:void 0)?d?[Math.ceil(e2.size(h.dims)/4)]:h.dims:void 0,g=!1==(m=0===c.length||1===c.length&&1===c[0])&&1===c.length,y=tS(l),b=(_=m&&(!d||4===y))?y:1,$=tA("input",d?12:n,p.length,_&&!d?y:1),v=tA("scale",u,c.length),w=h?tA("zero_point",d?12:n,f.length):void 0,x=tO("output",u,o.length,b),k=[$,v],w&&k.push(w),S=[p,c],h&&S.push(f),T=[{type:12,data:l/b},{type:12,data:a},{type:12,data:i.blockSize},...tk(...S,o)],{name:"DequantizeLinear",shaderCache:{hint:i.cacheKey,inputDependencies:w?["rank","rank","rank"]:["rank","rank"]},getShaderSource:e=>`
      ${e.registerUniforms([{name:"output_size",type:"u32"},{name:"axis",type:"u32"},{name:"block_size",type:"u32"}]).declareVariables(...k,x)}
      ${e.mainStart()}
          ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
          let output_indices = ${x.offsetToIndices("global_idx")};

          // Set input x
          ${d?`
            let input = ${$.getByOffset("global_idx / 4")};
            let x_vec = ${s?"unpack4xI8(input)":"unpack4xU8(input)"};
            let x_value = ${1===b?"x_vec[global_idx % 4]":"x_vec"};`:`let x_value = ${$.getByOffset("global_idx")};`};

          // Set scale input
          ${m?`let scale_value= ${v.getByOffset("0")}`:g?`
            let scale_index = ${x.indicesGet("output_indices","uniforms.axis")};
            let scale_value= ${v.getByOffset("scale_index")};`:`
            var scale_indices: ${v.type.indices} = output_indices;
            let index = ${v.indicesGet("scale_indices","uniforms.axis")} / uniforms.block_size;
            ${v.indicesSet("scale_indices","uniforms.axis","index")};
            let scale_value= ${v.getByIndices("scale_indices")};`};

          // Set zero-point input
          ${w?m?d?`
                let zero_point_input = ${w.getByOffset("0")};
                let zero_point_vec =  ${s?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value= zero_point_vec[0]`:`let zero_point_value = ${w.getByOffset("0")}`:g?d?`
                let zero_point_index = ${x.indicesGet("output_indices","uniforms.axis")};
                let zero_point_input = ${w.getByOffset("zero_point_index / 4")};
                let zero_point_vec =  ${s?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value = zero_point_vec[zero_point_index % 4]`:`
                let zero_point_index = ${x.indicesGet("output_indices","uniforms.axis")};
                let zero_point_value = ${w.getByOffset("zero_point_index")};`:d?`
                let zero_point_offset = ${v.indicesToOffset("scale_indices")};
                let zero_point_input = ${w.getByOffset("zero_point_offset / 4")};
                let zero_point_vec = ${s?"unpack4xI8(zero_point_input)":"unpack4xU8(zero_point_input)"};
                let zero_point_value = zero_point_vec[zero_point_offset % 4];`:`let zero_point_value = ${w.getByIndices("scale_indices")};`:`let zero_point_value = ${d?s?"i32":"u32":$.type.value}(0);`};
      // Compute and write output
      ${x.setByOffset("global_idx",`${x.type.value}(x_value - zero_point_value) * scale_value`)};
      }`,getRunData:()=>({outputs:[{dims:o,dataType:u}],dispatchGroup:{x:Math.ceil(l/b/64),y:1,z:1},programUniforms:T})}))},aQ=e=>tb({axis:e.axis,blockSize:e.blockSize})}),sn=M(()=>{"use strict";en(),nf(),nk(),aX=e=>{var t,r,i,a;let n,s,o,u=0,l=0,d=0;6===e.inputs[0].dataType?(u=e.inputs[0].getInt32Array()[0],l=e.inputs[1].getInt32Array()[0],d=e.inputs[2].getInt32Array()[0]):1===e.inputs[0].dataType&&(u=e.inputs[0].getFloat32Array()[0],l=e.inputs[1].getFloat32Array()[0],d=e.inputs[2].getFloat32Array()[0]),h.webgpu.validateInputContent&&((e,t,r)=>{if(e===t||e<t&&r<0||e>t&&r>0)throw Error("Range these inputs' contents are invalid.")})(u,l,d),e.compute((t=u,r=l,i=d,a=e.inputs[0].dataType,s=[n=Math.abs(Math.ceil((r-t)/i))],o=[{type:12,data:n},{type:a,data:t},{type:a,data:i},...tk(s)],{name:"Range",shaderCache:{hint:`${a}`},getShaderSource:e=>{let t=tO("output",a,s.length),r=t.type.value;return`
        ${e.registerUniforms([{name:"outputSize",type:"u32"},{name:"start",type:r},{name:"delta",type:r}]).declareVariables(t)}
        ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
        output[global_idx] = uniforms.start + ${r}(global_idx) * uniforms.delta;
      }`},getRunData:()=>({outputs:[{dims:s,dataType:a}],dispatchGroup:{x:Math.ceil(n/64)},programUniforms:o})}),{inputs:[]})}}),ss=M(()=>{"use strict";nf(),ny(),nx(),nk(),aY=(e,t)=>`${1===e?`
    let element_count_dim = uniforms.output_strides;
    let dim_value = uniforms.output_shape;`:`
    let element_count_dim = uniforms.output_strides[${t?"i - indices_start":"i"}];
    let dim_value = uniforms.output_shape[${t?"i - indices_start":"i"} + uniforms.last_index_dimension];`}
    
    if (index >= 0) {
      if (index >= i32(dim_value)) {
        index = i32(dim_value - 1);
      }
    } else {
      if (index < -i32(dim_value)) {
        index = 0;
      } else {
        index += i32(dim_value);
      }
    }
    data_offset += u32((u32(index) * element_count_dim));`,aJ=(e,t,r)=>`for (var i = 0u; i < uniforms.num_updates_elements; i++) {
        let value = updates[uniforms.num_updates_elements * ${r?"global_idx":"idx"} + i];
        ${((e,t,r,i)=>{if("none"!==e&&"i32"!==i&&"u32"!==i&&"f32"!==i)throw Error(`Input ${i} is not supported with reduction ${e}.`);let a=`{
                var oldValue = 0;
                loop {
                  let newValueF32 =`,n=`;
                  let newValue = bitcast<i32>(newValueF32);
                  let res = atomicCompareExchangeWeak(&${t}, oldValue, newValue);
                  if res.exchanged {
                    break;
                  }
                  oldValue = res.old_value;
                }
              }`;switch(e){case"none":return`${t}=${r};`;case"add":return"i32"===i||"u32"===i?`atomicAdd(&${t}, bitcast<${i}>(${r}));`:`
              ${a}bitcast<${i}>(oldValue) + (${r})${n}`;case"max":return"i32"===i||"u32"===i?`atomicMax(&${t}, bitcast<${i}>(${r}));`:`
                ${a}max(bitcast<f32>(oldValue), (${r}))${n}`;case"min":return"i32"===i||"u32"===i?`atomicMin(&${t}, bitcast<${i}>(${r}));`:`${a}min(bitcast<${i}>(oldValue), (${r}))${n}`;case"mul":return`${a}(bitcast<${i}>(oldValue) * (${r}))${n}`;default:throw Error(`Reduction ${e} is not supported.`)}})(e.reduction,"output[data_offset + i]","value",t)}
      }`,a0=e=>tb({reduction:e.reduction}),a2=(e,t)=>{var r,i;let a,n,s,o,u,l,d;e.compute((r=e.inputs,i=t,a=r[0].dims,n=r[1].dims,s=Math.ceil(e2.size(n)/1),o=n[n.length-1],u=e2.sizeFromDimension(a,o),l=e2.sizeFromDimension(n,0)/o,d=[{type:12,data:s},{type:12,data:o},{type:12,data:u},...tk(r[1].dims,r[2].dims,a)],{name:"ScatterND",shaderCache:{hint:`${i.cacheKey}_${i.reduction}`,inputDependencies:["rank","rank"]},getRunData:()=>({outputs:[{dims:a,dataType:r[0].dataType}],dispatchGroup:{x:Math.ceil(s/64)},programUniforms:d}),getShaderSource:e=>{let t=tA("indices",r[1].dataType,r[1].dims.length),n=tA("updates",r[2].dataType,r[2].dims.length,1),s="none"!==i.reduction&&""!==i.reduction?tR("output",r[0].dataType,a.length):tO("output",r[0].dataType,a.length,1);return`
      ${e.registerUniform("output_size","u32").registerUniform("last_index_dimension","u32").registerUniform("num_updates_elements","u32").declareVariables(t,n,s)}
      ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
  var hasDuplicates = false;
  if (${"none"===i.reduction}) {
    for (var i = 0; i < ${l}; i = i + 1) {
      for (var j = i + 1; j < ${l}; j = j + 1) {
        var index_i = i32(indices[i].x);
        var index_j = i32(indices[j].x);
        if (index_i == index_j) {
          hasDuplicates = true;
          break;
        }
      }
      if (hasDuplicates) {
        break;
      }
    }
  }

  if (${"none"===i.reduction} && hasDuplicates) {
    if (global_idx != 0u) {
      return;
    }
    // Process each index-update pair individually when duplicates exist
    for (var idx = 0u; idx < ${l}u; idx++) {
      var data_offset = 0u;
      for (var i = 0u; i < uniforms.last_index_dimension; i++) {
        var index = i32(indices[idx * uniforms.last_index_dimension + i].x);
        ${aY(a.length,!1)}
      }
      ${aJ(i,s.type.value,!1)}
    }
    return;
  }

  var data_offset = 0u;
  var indices_start = uniforms.last_index_dimension * global_idx;
  var indices_end = indices_start + uniforms.last_index_dimension;
  for (var i = indices_start; i < indices_end; i++) {
    var index = i32(indices[i].x);
    ${aY(a.length,!0)}
  }
  ${aJ(i,s.type.value,!0)}
  }`}}),{inputs:[e.inputs[1],e.inputs[2]],outputs:[]})}}),so=M(()=>{"use strict";nf(),ny(),nx(),nk(),a1=(e,t,r,i)=>`
  // The whole part and the fractional part are calculated separately due to inaccuracy of floating
  // point division. As an example, f32(21) / f32(7) may evaluate to 2.99... instead of 3, causing an
  // offset-by-one error later in floor().
  let big = (${e}) * (${t});
  let whole = ${i}(big / (${r}));
  let fract = ${i}(big % (${r})) / ${i}(${r});
  return whole + fract;
`,a3=(e,t,r,i)=>e.rank>i?`
    ${e.indicesSet("input_indices",t,"channel")};
    ${e.indicesSet("input_indices",r,"batch")};
`:"",a4=(e,t)=>{var r,i,a,n,s,o,u,l,d,p,c,h;let f,m,g,y,_,b,$,v,w,x,k,S,T,I,E,C,z=[],A=[],O=[],R=new Uint32Array(f=e.customDataBuffer,f.byteOffset,1)[0];if(0!==t.antialias)throw Error("Only default value (0) for Antialias attribute is supported");((e,t,r,i,a,n)=>{let[s,o,u]=r>10?[1,2,3]:[-1,e.length>1?1:-1,-1],l=e[0].dims.length;if(s>0&&e.length>s&&e[s].dims.length>0)e[s].getFloat32Array().forEach(e=>n.push(e));else if("tf_crop_and_resize"===t.coordinateTransformMode)throw Error("Resize requires RoI input to be specified when coordinateTransformMode is tfCropAndResize");if(o>0&&e.length>o&&1===e[o].dims.length&&e[o].dims[0]>0){var d,p,c;let a;if(e[o].getFloat32Array().forEach(e=>i.push(e)),0!==i.length&&i.length!==l&&r>=18&&i.length!==t.axes.length)throw Error("Resize requires scales input size to be same as input rank or axes size for opset 18 and up");((e,t)=>{if(e.every(e=>e>0||(()=>{throw Error("Resize requires scales input values to be positive")})),e.length>0){if("linear"===t.mode){if(2!==e.length&&3!==e.length&&(4!==e.length||1!==e[0]||1!==e[1])&&(4!==e.length||1!==e[0]||1!==e[3])&&(5!==e.length||1!==e[0]||1!==e[1]))throw Error(`For linear mode, Resize requires scales to be 2D, 3D, 4D with either two outermost or one innermost and
            one outermost scale values equal to 1, or 5D with two outermost scale values equal to 1`)}else if("cubic"===t.mode&&2!==e.length&&(4!==e.length||1!==e[0]||1!==e[1])&&(4!==e.length||1!==e[0]||1!==e[3]))throw Error("Resize requires scales input size to be 2 or 4 for cubic mode")}})(i,t),t.axes.length>0&&(d=i,p=t.axes,c=l,p.every(e=>e>=0&&e<c||(()=>{throw Error("Resize requires axes input values to be positive and less than rank")})),a=Array(c).fill(1),p.forEach((e,t)=>a[e]=d[t]),a).forEach((e,t)=>i[t]=e)}if(u>0&&e.length>u&&1===e[u].dims.length&&e[u].dims[0]>0&&(e[u].getBigInt64Array().forEach(e=>a.push(Number(e))),0!==a.length&&a.length!==l&&r>=18&&a.length!==t.axes.length))throw Error("Resize requires sizes input size to be same as input rank or axes size for opset 18 and up");if(t.axes.length>0){if(0!==i.length&&i.length!==t.axes.length)throw Error('Resize requires "scales" input size to be of axes rank when axes attributes is specified');if(0!==a.length&&a.length!==t.axes.length)throw Error('Resize requires "sizes" input size to be of rank axes rank when axes attributes is specified')}if("u">typeof i&&"u">typeof a&&i.length>0&&a.length>l)throw Error("Resize requires only of scales or sizes to be specified")})(e.inputs,t,R,z,A,O),e.compute((r=e.inputs[0],i=t,a=R,n=z,s=A,o=O,y=r.dims,_=(u=o,l=i.axes,m=Array(d=y.length).fill(0).concat(Array(d).fill(1)),g=0===u.length?m:u.slice(),l.length>0?(l.forEach((e,t)=>{m[e]=g[t],m[t+d]=g[l.length+t]}),m):g),b=((e,t,r,i)=>{let a=[];if(r.length>0)if(i.length>0){if(e.forEach(e=>a.push(e)),Math.max(...i)>e.length)throw Error("axes is out of bound");i.forEach((e,t)=>a[e]=r[t])}else r.forEach(e=>a.push(e));else{if(0===t.length)throw Error("Resize requires either scales or sizes.");a=e.map((e,r)=>Math.round(e*t[r]))}return a})(y,n,s,i.axes),$=n.slice(),0===n.length&&($=y.map((e,t)=>0===e?1:b[t]/e),"stretch"!==i.keepAspectRatioPolicy&&(p=y,c=$,h=i,v=(()=>{switch(h.keepAspectRatioPolicy){case"not_larger":return h.axes.length>0?Math.min(...h.axes.map(e=>c[e]),Number.MAX_VALUE):Math.min(...c,Number.MAX_VALUE);case"not_smaller":return h.axes.length>0?Math.max(...h.axes.map(e=>c[e]),5e-324):Math.max(...c,5e-324);default:throw Error(`Keep aspect ratio policy ${h.keepAspectRatioPolicy} is not supported`)}})(),c.fill(1,0,c.length),w=p.slice(),h.axes.length>0?(h.axes.forEach(e=>c[e]=v),h.axes.forEach(e=>w[e]=Math.round(p[e]*c[e]))):(c.fill(v,0,c.length),w.forEach((e,t)=>w[t]=Math.round(e*c[t]))),b=w)),x=tO("output",r.dataType,b.length),k=tA("input",r.dataType,y.length),S=e2.size(b),T=y.length===b.length&&y.every((e,t)=>e===b[t]),I="tf_crop_and_resize"===i.coordinateTransformMode,E=i.extrapolationValue,C=k.type.value,{name:"Resize",shaderCache:{hint:`${i.cacheKey}|${a}|${$.length>0?"cubic"===i.mode?$:$.length:""}|${s.length>0?s:""}|${_.length>0?_:""}|${T}|${"nearest"===i.mode?y.length:y}`,inputDependencies:["rank"]},getShaderSource:e=>{let t,r;return`
      ${T?"":`
      ${t=i.coordinateTransformMode,r=C,`fn getOriginalCoordinateFromResizedCoordinate(xResized: u32, xScale: f32, lengthResized: u32,
     lengthOriginal: u32, roiStart: f32, roiEnd: f32) -> ${r} { `+(()=>{switch(t){case"asymmetric":return`
          if (xScale < 1.0 || floor(xScale) != xScale) {
            return ${r}(xResized) / ${r}(xScale);
          } else {
            ${a1("xResized","lengthOriginal","lengthResized",r)}
          }
        `;case"pytorch_half_pixel":return`if (lengthResized > 1) {
                    return (${r}(xResized) + 0.5) / ${r}(xScale) - 0.5;
                  } else {
                    return 0.0;
                  }`;case"tf_half_pixel_for_nn":return`return (${r}(xResized) + 0.5) / ${r}(xScale);`;case"align_corners":return`if (lengthResized == 1) {
                    return 0.0;
                  } else {
                    ${a1("xResized","lengthOriginal - 1","lengthResized - 1",r)}
                  }`;case"tf_crop_and_resize":return`if (lengthResized > 1) {
                    return ${r}(roiStart) * ${r}(lengthOriginal - 1) +
                        (${r}(xResized) * ${r}(roiEnd - roiStart) * ${r}(lengthOriginal - 1)) /
                        ${r}(lengthResized - 1);
                  } else {
                    return 0.5 * ${r}(roiStart + roiEnd) * ${r}(lengthOriginal - 1);
                  }`;case"half_pixel_symmetric":return`const outputWidth = ${r}xScale * ${r}(lengthResized);
                  const adjustment = ${r}(lengthResized) / outputWidth;
                  const center = ${r}(lengthOriginal) / 2;
                  const offset = center * (1 - adjustment);
                  return offset + ((${r}(xResized) + 0.5) / ${r}(xScale)) - 0.5;`;case"half_pixel":return`return ((${r}(xResized) + 0.5) / ${r}(xScale)) - 0.5;`;default:throw Error(`Coordinate transform mode ${t} is not supported`)}})()+"}"};
      ${(()=>{switch(i.mode){case"nearest":let e,t,r,n,s,o,u,l,d,p,c,h;return`
              ${e=k,t=y,`
    fn checkInputIndices(input_indices: ${e.type.indices}) -> bool {
      for (var i:u32 = 0; i < ${t.length}; i++) {
        var input_index = ${e.indicesGet("input_indices","i")};
        if (input_index < 0 || input_index >= ${tC("uniforms.input_shape","i",t.length)}) {
          return false;
        }
      }
      return true;
    }`};
              ${r=i.nearestMode,n=a,s=C,`fn getNearestPixelFromOriginal(xOriginal: ${s}, isDownSample: bool) -> ${s} {`+(()=>{switch(r){case"round_prefer_ceil":return"if (fract(xOriginal) == 0.5) {             return ceil(xOriginal);           } else {             return round(xOriginal);           }";case"floor":return"return floor(xOriginal);";case"ceil":return"return ceil(xOriginal);";case"round_prefer_floor":return"if (fract(xOriginal) == 0.5) {                     return floor(xOriginal);                   } else {                     return round(xOriginal);                   }";default:if(n<11)return"if (isDownSample)                     {                       return ceil(xOriginal);                     } else {                       return xOriginal;                     }";throw Error(`Nearest mode ${r} is not supported`)}})()+"}"};
              ${o=k,u=x,l=y,d=b,p=$.length,c=_.length,h=I,`
    fn calculateInputIndicesFromOutputIndices(output_indices: ${u.type.indices}) -> ${o.type.indices} {
      var input_indices: ${o.type.indices};
      for (var i:u32 = 0; i < ${d.length}; i++) {
        var output_index = ${u.indicesGet("output_indices","i")};
        var input_index: u32;
        var scale = ${tC("uniforms.scales","i",p)};
        if (scale == 1.0) {
          input_index = output_index;
        } else {
          var roi_low = ${tC("uniforms.roi","i",c)};
          var roi_hi = ${tC("uniforms.roi",`i + ${l.length}`,c)};
          var input_shape_i = ${tC("uniforms.input_shape","i",l.length)};
          var output_shape_i = ${tC("uniforms.output_shape","i",d.length)};
          var original_idx = getOriginalCoordinateFromResizedCoordinate(output_index, scale, output_shape_i,
                                                                        input_shape_i, roi_low, roi_hi);
          if (!${h} || (original_idx >= 0 && original_idx < ${u.type.value}(input_shape_i))) {
            if (original_idx < 0) {
              input_index = 0;
            } else if (original_idx > ${u.type.value}(input_shape_i - 1)) {
              input_index = input_shape_i - 1;
            } else {
              input_index = u32(getNearestPixelFromOriginal(original_idx, scale < 1));
            }
          } else {
            input_index = u32(original_idx);
          }
        }
        ${o.indicesSet("input_indices","i","input_index")}
      }
      return input_indices;
    }`};
              `;case"linear":let f,m,g,v,w;return`
              ${f=x,m=y,g=b,v=$.length,w=_.length,`
    fn calculateOriginalIndicesFromOutputIndices(output_indices: ${f.type.indices}) -> array<${f.type.value}, ${g.length}> {
      var original_indices: array<${f.type.value}, ${g.length}>;
      for (var i:u32 = 0; i < ${g.length}; i++) {
        var output_index = ${f.indicesGet("output_indices","i")};
        var scale = ${tC("uniforms.scales","i",v)};
        var roi_low = ${tC("uniforms.roi","i",w)};
        var roi_hi = ${tC("uniforms.roi",`i + ${m.length}`,w)};
        if (scale == 1.0) {
          original_indices[i] = ${f.type.value}(output_index);
        } else {
          var input_shape_i = ${tC("uniforms.input_shape","i",m.length)};
          var output_shape_i = ${tC("uniforms.output_shape","i",g.length)};
          original_indices[i] = getOriginalCoordinateFromResizedCoordinate(output_index, scale, output_shape_i,
                                                                           input_shape_i, roi_low, roi_hi);
        }
      }
      return original_indices;
    }`};
              ${(()=>{if(2===y.length||4===y.length)return`${((e,t,r,i,a)=>{let[n,s,o,u]=2===r.length?[-1,0,1,-1]:[0,2,3,1],l=e.type.value;return`
    fn getInputValue(batch: u32, channel: u32, row: u32, col: u32) -> ${l} {
      var input_indices: ${e.type.indices};
      ${e.indicesSet("input_indices",s,`max(0, min(row, ${r[s]} - 1))`)};
      ${e.indicesSet("input_indices",o,`max(0, min(col, ${r[o]} - 1))`)};
      ${a3(e,u,n,2)}
      return ${e.getByIndices("input_indices")};
    }

    fn bilinearInterpolation(output_indices: ${t.type.indices}) -> ${l} {
      var originalIndices = calculateOriginalIndicesFromOutputIndices(output_indices);
      var row:${l} = originalIndices[${s}];
      var col:${l} = originalIndices[${o}];
      ${i?`if (row < 0 || row > (${r[s]} - 1) || col < 0 || col > (${r[o]} - 1)) {
        return ${a};
      }`:""};
      row = max(0, min(row, ${r[s]} - 1));
      col = max(0, min(col, ${r[o]} - 1));
      var row1: u32 = u32(row);
      var col1: u32 = u32(col);
      var row2: u32 = u32(row + 1);
      var col2: u32 = u32(col + 1);
      var channel: u32 = ${r.length>2?`u32(originalIndices[${u}])`:"0"};
      var batch: u32 =  ${r.length>2?`u32(originalIndices[${n}])`:"0"};
      var x11: ${l} = getInputValue(batch, channel, row1, col1);
      var x12: ${l} = getInputValue(batch, channel, row1, col2);
      var x21: ${l} = getInputValue(batch, channel, row2, col1);
      var x22: ${l} = getInputValue(batch, channel, row2, col2);
      var dx1: ${l} = abs(row - ${l}(row1));
      var dx2: ${l} = abs(${l}(row2) - row);
      var dy1: ${l} = abs(col - ${l}(col1));
      var dy2: ${l} = abs(${l}(col2) - col);
      if (row1 == row2) {
        dx1 = 0.5;
        dx2 = 0.5;
      }
      if (col1 == col2) {
        dy1 = 0.5;
        dy2 = 0.5;
      }
      return (x11 * dx2 * dy2 + x12 * dx2 * dy1 + x21 * dx1 * dy2 + x22 * dx1 * dy1);
    }`})(k,x,y,I,E)}`;if(3===y.length||5===y.length)return`${((e,t,r,i,a)=>{let[n,s,o,u,l]=3===r.length?[-1,0,1,2,-1]:[0,2,3,4,1],d=e.type.value;return`
    fn getInputValue(batch: u32, channel: u32, depth:u32, height: u32, width: u32) -> ${d} {
      var input_indices: ${e.type.indices};
      ${e.indicesSet("input_indices",s,`max(0, min(depth, ${r[s]} - 1))`)};
      ${e.indicesSet("input_indices",o,`max(0, min(height, ${r[o]} - 1))`)};
      ${e.indicesSet("input_indices",u,`max(0, min(width, ${r[u]} - 1))`)};
      ${a3(e,l,n,3)}
      return ${e.getByIndices("input_indices")};
    }

    fn trilinearInterpolation(output_indices: ${t.type.indices}) -> ${d} {
      var originalIndices = calculateOriginalIndicesFromOutputIndices(output_indices);
      var depth:${d} = originalIndices[${s}];
      var height:${d} = originalIndices[${o}];
      var width:${d} = originalIndices[${u}];
      ${i?`if (depth < 0 || depth > (${r[s]} - 1) || height < 0 || height > (${r[o]} - 1) || width < 0 || (width > ${r[u]} - 1)) {
      return ${a};
        }`:""};

    depth = max(0, min(depth, ${r[s]} - 1));
      height = max(0, min(height, ${r[o]} - 1));
      width = max(0, min(width, ${r[u]} - 1));
      var depth1: u32 = u32(depth);
      var height1: u32 = u32(height);
      var width1: u32 = u32(width);
      var depth2: u32 = u32(depth + 1);
      var height2: u32 = u32(height + 1);
      var width2: u32 = u32(width + 1);
      var channel: u32 = ${r.length>3?`u32(originalIndices[${l}])`:"0"};
      var batch: u32 =  ${r.length>3?`u32(originalIndices[${n}])`:"0"};

      var x111: ${d} = getInputValue(batch, channel, depth1, height1, width1);
      var x112: ${d} = getInputValue(batch, channel, depth1, height1, width2);
      var x121: ${d} = getInputValue(batch, channel, depth1, height2, width1);
      var x122: ${d} = getInputValue(batch, channel, depth1, height2, width2);
      var x211: ${d} = getInputValue(batch, channel, depth2, height1, width1);
      var x212: ${d} = getInputValue(batch, channel, depth2, height1, width2);
      var x221: ${d} = getInputValue(batch, channel, depth2, height2, width1);
      var x222: ${d} = getInputValue(batch, channel, depth2, height2, width2);
      var dx1: ${d} = abs(depth - ${d}(depth1));
      var dx2: ${d} = abs(${d}(depth2) - depth);
      var dy1: ${d} = abs(height - ${d}(height1));
      var dy2: ${d} = abs(${d}(height2) - height);
      var dz1: ${d} = abs(width - ${d}(width1));
      var dz2: ${d} = abs(${d}(width2) - width);
      if (depth1 == depth2) {
        dx1 = 0.5;
        dx2 = 0.5;
      }
      if (height1 == height2) {
        dy1 = 0.5;
        dy2 = 0.5;
      }
      if (width1 == width2) {
        dz1 = 0.5;
        dz2 = 0.5;
      }
      return (x111 * dx2 * dy2 * dz2 + x112 * dx2 * dy2 * dz1 + x121 * dx2 * dy1 *dz2 + x122 * dx2 * dy1 * dz1 +
              x211 * dx1 * dy2 * dz2 + x212 * dx1 * dy2 * dz1 + x221 * dx1 * dy1 *dz2 + x222 * dx1 * dy1 * dz1);
    }`})(k,x,y,I,E)}`;throw Error("Linear mode only supports input dims 2, 3, 4 and 5 are supported in linear mode.")})()};
            `;case"cubic":return`
            ${(()=>{if(2===y.length||4===y.length)return`${((e,t,r,i,a,n,s,o,u,l)=>{let[d,p]=2===r.length?[0,1]:[2,3],c=e.type.value,h=s=>{let p=s===d?"row":"col";return`
      fn ${p}CubicInterpolation(input_indices: ${e.type.indices}, output_indices: ${t.type.indices}) -> ${c} {
        var output_index = ${t.indicesGet("output_indices",s)};
        var originalIdx: ${c} = getOriginalCoordinateFromResizedCoordinate(output_index, ${a[s]},
        ${i[s]}, ${r[s]}, ${n[s]}, ${n[s]} + ${r.length});
        var fractOriginalIdx: ${c} = originalIdx - floor(originalIdx);
        var coefs = getCubicInterpolationCoefs(fractOriginalIdx);

        if (${o} && (originalIdx < 0 || originalIdx > (${r[s]} - 1))) {
          return ${u};
        }
        var data: array<${c}, 4> = array<${c}, 4>(0.0, 0.0, 0.0, 0.0);
        for (var i: i32 = -1; i < 3; i++) {
          var ${p}: ${c} = originalIdx + ${c}(i);
          if (${p} < 0 || ${p} >= ${r[s]}) {
            ${l?`coefs[i + 1] = 0.0;
                        continue;`:o?`return ${u};`:`${p} = max(0, min(${p}, ${r[s]} - 1));`};
          }
        var input_indices_copy: ${e.type.indices} = input_indices;
          ${e.indicesSet("input_indices_copy",s,`u32(${p})`)};
          data[i + 1] = ${s===d?e.getByIndices("input_indices_copy"):"rowCubicInterpolation(input_indices_copy, output_indices)"};
        }
        return cubicInterpolation1D(data, coefs);
      }`};return`
    ${h(d)};
    ${h(p)};
  fn getCubicInterpolationCoefs(s: ${c}) -> array<${c}, 4> {
    var absS = abs(s);
    var coeffs: array<${c}, 4> = array<${c}, 4>(0.0, 0.0, 0.0, 0.0);
    var oneMinusAbsS: ${c} = 1.0 - absS;
    var twoMinusAbsS: ${c} = 2.0 - absS;
    var onePlusAbsS: ${c} = 1.0 + absS;
    coeffs[0] = ((${s} * onePlusAbsS - 5 * ${s}) * onePlusAbsS + 8 * ${s}) * onePlusAbsS - 4 * ${s};
    coeffs[1] = ((${s} + 2) * absS - (${s} + 3)) * absS * absS + 1;
    coeffs[2] = ((${s} + 2) * oneMinusAbsS - (${s} + 3)) * oneMinusAbsS * oneMinusAbsS + 1;
    coeffs[3] = ((${s} * twoMinusAbsS - 5 * ${s}) * twoMinusAbsS + 8 * ${s}) * twoMinusAbsS - 4 * ${s};
    return coeffs;
  }

  fn cubicInterpolation1D(x: array<${c}, 4>, coefs: array<${c}, 4>) -> ${c} {
    var coefsSum: ${c} = coefs[0] + coefs[1] + coefs[2] + coefs[3];
    return (x[0] * coefs[0] + x[1] * coefs[1]+ x[2] * coefs[2]+ x[3] * coefs[3]) / coefsSum;
  }

  fn bicubicInterpolation(output_indices: ${t.type.indices}) -> ${c} {
    var input_indices: ${e.type.indices} = output_indices;
    return colCubicInterpolation(input_indices, output_indices);
  }
    `})(k,x,y,b,$,_,i.cubicCoeffA,I,i.extrapolationValue,i.excludeOutside)}`;throw Error("Cubic mode only supports input dims 2 and 4 are supported in linear mode.")})()};
            `;default:throw Error("Invalid resize mode")}})()};
      `}
      ${e.registerUniform("output_size","u32").registerUniform("scales","f32",$.length).registerUniform("roi","f32",_.length).declareVariables(k,x)}
      ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
        ${T?"output[global_idx] = input[global_idx];":`
        let output_indices = ${x.offsetToIndices("global_idx")};
        var input_indices: ${k.type.indices};
        ${(()=>{switch(i.mode){case"nearest":return`input_indices = calculateInputIndicesFromOutputIndices(output_indices);
                if (checkInputIndices(input_indices)) {
                  output[global_idx] = ${k.getByIndices("input_indices")};
                } else {
                  output[global_idx] = ${i.extrapolationValue};
                }`;case"linear":return`output[global_idx] = ${2===y.length||4===y.length?"bilinearInterpolation":"trilinearInterpolation"}(output_indices);`;case"cubic":return"output[global_idx] = bicubicInterpolation(output_indices);";default:throw Error(`Unsupported resize mode: ${i.mode}`)}})()};
`}
      }`},getRunData:()=>({outputs:[{dims:b,dataType:r.dataType}],dispatchGroup:{x:Math.ceil(S/64)},programUniforms:[{type:12,data:S},{type:1,data:$},{type:1,data:_},...tk(y,b)]})}),{inputs:[0]})},a6=e=>{let t=e.antialias,r=e.axes,i=e.coordinateTransformMode,a=e.cubicCoeffA,n=0!==e.excludeOutside,s=e.extrapolationValue,o=e.keepAspectRatioPolicy,u=e.mode,l=""===e.nearestMode?"simple":e.nearestMode;return tb({antialias:t,axes:r,coordinateTransformMode:i,cubicCoeffA:a,excludeOutside:n,extrapolationValue:s,keepAspectRatioPolicy:o,mode:u,nearestMode:l})}}),su=M(()=>{"use strict";nf(),ny(),nk(),a8=(e,t)=>{var r,i,a,n;let s,o,u,l,d,p,c,h,f,m,g,y,_;(e=>{if(!e||e.length<3)throw Error("layerNorm requires at least 3 inputs.");let t=e[0],r=e[1],i=e[2];if(t.dataType!==r.dataType||t.dataType!==i.dataType)throw Error("All inputs must have the same data type");if(3!==t.dims.length&&2!==t.dims.length)throw Error("Input must be 2D or 3D");if(3!==r.dims.length&&2!==r.dims.length)throw Error("Skip must be 2D or 3D");let a=t.dims[t.dims.length-1],n=t.dims[t.dims.length-2];if(r.dims[r.dims.length-1]!==a)throw Error("Skip must have the same hidden size as input");if(r.dims[r.dims.length-2]!==n)throw Error("Skip must have the same sequence length as input");if(1!==i.dims.length)throw Error("Gamma must be 1D");if(i.dims[i.dims.length-1]!==a)throw Error("Gamma must have the same hidden size as input");if(e.length>3){let t=e[3];if(1!==t.dims.length)throw Error("Beta must be 1D");if(t.dims[t.dims.length-1]!==a)throw Error("Beta must have the same hidden size as input")}if(e.length>4){let t=e[4];if(1!==t.dims.length)throw Error("Bias must be 1D");if(t.dims[t.dims.length-1]!==a)throw Error("Bias must have the same hidden size as input")}})(e.inputs);let b=[0];e.outputCount>1&&b.push(-3),e.outputCount>2&&b.push(-3),e.outputCount>3&&b.push(3),e.compute((r=e.inputs,i=t,a=e.outputCount,n=!1,s=i.simplified,o=r[0].dims,u=e2.size(o),l=o.slice(-1)[0],d=n?o.slice(0,-1).concat(1):[],p=!s&&r.length>3,c=r.length>4,h=n&&a>1,f=n&&a>2,m=a>3,y=[{type:12,data:u},{type:12,data:g=tS(l)},{type:12,data:l},{type:1,data:i.epsilon}],_=[{dims:o,dataType:r[0].dataType}],a>1&&_.push({dims:d,dataType:1}),a>2&&_.push({dims:d,dataType:1}),a>3&&_.push({dims:o,dataType:r[0].dataType}),{name:"SkipLayerNormalization",shaderCache:{hint:`${g};${h};${f};${m}`,inputDependencies:r.map((e,t)=>"type")},getShaderSource:e=>{let t=[tA("x",r[0].dataType,r[0].dims,g),tA("skip",r[1].dataType,r[1].dims,g),tA("gamma",r[2].dataType,r[2].dims,g)];p&&t.push(tA("beta",r[3].dataType,r[3].dims,g)),c&&t.push(tA("bias",r[4].dataType,r[4].dims,g)),t.push(tO("output",r[0].dataType,o,g)),h&&t.push(tO("mean_output",1,d)),f&&t.push(tO("inv_std_output",1,d)),m&&t.push(tO("input_skip_bias_sum",r[0].dataType,o,g));let i=tw(r[0].dataType),a=tw(1,g);return`

      ${e.registerUniforms([{name:"output_size",type:"u32"},{name:"components",type:"u32"},{name:"hidden_size",type:"u32"},{name:"epsilon",type:"f32"}]).declareVariables(...t)}
      var<workgroup> sum_shared : array<${a}, 64>;
      var<workgroup> sum_squared_shared : array<${a}, 64>;

      ${e.mainStart([64,1,1])}
        let ix = local_id.x;
        let iy = global_id.x / 64;

        let hidden_size_vectorized: u32 = uniforms.hidden_size / uniforms.components;
        var stride = hidden_size_vectorized / 64;
        let offset = ix * stride + iy * hidden_size_vectorized;
        let offset1d = stride * ix;
        if (ix == 63) {
          stride = hidden_size_vectorized - stride * ix;
        }
        for (var i: u32 = 0; i < stride; i++) {
          let skip_value = skip[offset + i];
          let bias_value = ${c?"bias[offset1d + i]":i+"(0.0)"};
          let input_value = x[offset + i];
          let value = input_value + skip_value + bias_value;
          ${m?"input_skip_bias_sum[offset + i] = value;":""}
          output[offset + i] = value;
          let f32_value = ${tI(i,g,"value")};
          sum_shared[ix] += f32_value;
          sum_squared_shared[ix] += f32_value * f32_value;
        }
        workgroupBarrier();

        var reduce_size : u32 = 64;
        for (var curr_size = reduce_size >> 1;  curr_size > 0; curr_size = reduce_size >> 1) {
          reduce_size = curr_size + (reduce_size & 1);
          if (ix < curr_size) {
            sum_shared[ix] += sum_shared[ix + reduce_size];
            sum_squared_shared[ix] += sum_squared_shared[ix + reduce_size];
          }
          workgroupBarrier();
        }

        let sum = sum_shared[0];
        let square_sum = sum_squared_shared[0];
        let mean = ${tE("sum",g)} / f32(uniforms.hidden_size);
        let inv_std_dev = inverseSqrt(${tE("square_sum",g)} / f32(uniforms.hidden_size) ${s?"":"- mean * mean"} + uniforms.epsilon);
        ${h?"mean_output[global_idx] = mean;":""}
        ${f?"inv_std_output[global_idx] = inv_std_dev;":""}

        for (var i: u32 = 0; i < stride; i++) {
          output[offset + i] = (output[offset + i] ${s?"":`- ${i}(mean)`}) *
            ${i}(inv_std_dev) * gamma[offset1d + i]
            ${p?"+ beta[offset1d + i]":""};
        }
      }`},getRunData:()=>({outputs:_,dispatchGroup:{x:Math.ceil(u/l)},programUniforms:y})}),{outputs:b})}}),sl=M(()=>{"use strict";nf(),ny(),nx(),nk(),a5=(e,t)=>{let r=[];if(e.length>t)if(7===e[t].dataType)e[t].getBigInt64Array().forEach(e=>r.push(Number(e)));else if(6===e[t].dataType)e[t].getInt32Array().forEach(e=>r.push(Number(e)));else throw Error(`Input ${t} must be an array of int32 or int64`);return r},a7=(e,t,r,i,a)=>{let n=e;return e<0&&(n+=r[i[t]]),a[t]<0?Math.max(0,Math.min(n,r[i[t]]-1)):Math.max(0,Math.min(n,r[i[t]]))},a9=(e,t)=>{var r=e.inputs,i=t;if(!r||r.length<1)throw Error("too few inputs");if(0!==i.axes.length){if(i.axes.length!==i.starts.length||i.axes.length!==i.ends.length)throw Error("axes, starts and ends must have the same length")}else if(i.starts.length!==i.ends.length)throw Error("starts and ends must have the same length");r.slice(1).forEach((e,t)=>{if(6!==r[t+1].dataType&&7!==r[t+1].dataType)throw Error(`Input ${t} must be an array of int32 or int64`)});let a=((e,t)=>{if(!(e.length>1))return t;{let t=a5(e,1),r=a5(e,2),i=a5(e,3);return 0===i.length&&(i=[...Array(e[0].dims.length).keys()]),tb({starts:t,ends:r,axes:i})}})(e.inputs,t);e.compute(((e,t)=>{let r=e[0].dims,i=e2.size(r),a=t.axes.length>0?e2.normalizeAxes(t.axes,r.length):[...Array(r.length).keys()],n=a5(e,4);n.forEach(e=>0!==e||(()=>{throw Error("step cannot be 0")})),0===n.length&&(n=Array(a.length).fill(1));let s=t.starts.map((e,t)=>a7(e,t,r,a,n)),o=t.ends.map((e,t)=>a7(e,t,r,a,n));if(a.length!==s.length||a.length!==o.length)throw Error("start, ends and axes should have the same number of elements");if(a.length!==r.length)for(let e=0;e<r.length;++e)a.includes(e)||(s.splice(e,0,0),o.splice(e,0,r[e]),n.splice(e,0,1));let u=n.map(e=>Math.sign(e));n.forEach((e,t,r)=>{if(e<0){let i=(o[t]-s[t])/e,a=s[t],u=a+i*n[t];s[t]=u,o[t]=a,r[t]=-e}});let l=r.slice(0);a.forEach((e,t)=>{l[e]=Math.ceil((o[e]-s[e])/n[e])});let d={dims:l,dataType:e[0].dataType},p=tO("output",e[0].dataType,l.length),c=tA("input",e[0].dataType,e[0].dims.length),h=e2.size(l),f=[{name:"outputSize",type:"u32"},{name:"starts",type:"u32",length:s.length},{name:"signs",type:"i32",length:u.length},{name:"steps",type:"u32",length:n.length}],m=[{type:12,data:h},{type:12,data:s},{type:6,data:u},{type:12,data:n},...tk(e[0].dims,l)];return{name:"Slice",shaderCache:{hint:`${u.length}_${s.length}_${n.length}`,inputDependencies:["rank"]},getShaderSource:e=>{let t,i,a;return`
      ${e.registerUniforms(f).declareVariables(c,p)}
        ${t=c,i=p,a=r,`fn calculateInputIndices(output_indices: ${i.type.indices}) -> ${t.type.indices} {
          var input_indices: ${t.type.indices};
          var carry = 0u;
          for (var i = ${a.length}; i >= 0; i--) {
            let input_shape_i = ${tC("uniforms.input_shape","i",a.length)};
            let steps_i = ${tC("uniforms.steps","i",a.length)};
            let signs_i = ${tC("uniforms.signs","i",a.length)};
            let starts_i = ${tC("uniforms.starts","i",a.length)};
            var output_index = ${i.indicesGet("output_indices","i")};
            var input_index = output_index * steps_i + starts_i + carry;
            carry = input_index / input_shape_i;
            input_index = input_index % input_shape_i;
            if (signs_i < 0) {
              input_index = input_shape_i - input_index - 1u + starts_i;
            }
            ${t.indicesSet("input_indices","i","input_index")};
          }
          return input_indices;
      }`}
        ${e.mainStart()}
          ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.outputSize")}
          let output_indices = ${p.offsetToIndices("global_idx")};
          let input_indices = calculateInputIndices(output_indices);
          ${p.setByOffset("global_idx",c.getByIndices("input_indices"))}
      }`},getRunData:()=>({outputs:[d],dispatchGroup:{x:Math.ceil(i/64)},programUniforms:m})}})(e.inputs,a),{inputs:[0]})},ne=e=>{let t=e.starts,r=e.ends,i=e.axes;return tb({starts:t,ends:r,axes:i})}}),sd=M(()=>{"use strict";nf(),ny(),nx(),nS(),nk(),nt=(e,t)=>{var r,i;let a,n,s,o,u,l,d,p,c,h,f,m,g,y,_,b,$,v,w;(e=>{if(!e||1!==e.length)throw Error("Softmax op requires 1 input.")})(e.inputs),r=e,i=t,n=(a=r.inputs[0]).dims,s=e2.size(n),o=n.length,l=(u=e2.normalizeAxis(i.axis,o))<n.length-1,p=[],l?((p=Array.from({length:o},(e,t)=>t))[u]=o-1,p[o-1]=u,d=r.compute(tP(a,p),{inputs:[a],outputs:[-1]})[0]):d=a,f=s/(h=(c=d.dims)[o-1]),m=tS(h),g=h/m,y=64,1===f&&(y=256),_=tA("x",d.dataType,d.dims,m),b=tO("result",d.dataType,d.dims,m),$=_.type.value,v="f32"===tw(d.dataType)?`var threadMax = ${$}(-3.402823e+38f);`:`var threadMax = ${$}(-65504.0h);`,w=r.compute({name:"Softmax",shaderCache:{hint:`${m};${y}`,inputDependencies:["type"]},getRunData:()=>({outputs:[{dims:c,dataType:d.dataType}],dispatchGroup:{x:f},programUniforms:[{type:6,data:g}]}),getShaderSource:e=>{let t;return`
      var<workgroup> rowMaxShared : ${$};
      var<workgroup> rowSumShared : ${$};
      var<workgroup> threadShared : array<${$}, ${y}>;

      fn getValue(row: i32, col: i32, row_stride: i32) -> ${$} {
        let index = row * row_stride + col;
        return x[index];
      }

      fn setValue(row: i32, col: i32, row_stride: i32, value: ${$}) {
        let index = row * row_stride + col;
        result[index] = value;
      }
      ${e.registerUniform("packedCols","i32").declareVariables(_,b)}
      ${e.mainStart(y)}
        let gindex = i32(global_idx);
        let lindex = i32(local_idx);
        const wg = ${y};
        let row = gindex / wg;
        let cols = uniforms.packedCols;
        let row_stride : i32 = uniforms.packedCols;

        // find the rows max
        ${v}
        for (var col = lindex; col < cols; col += wg) {
          let value = getValue(row, col, row_stride);
          threadMax = max(threadMax, value);
        }
        if (lindex < cols) {
          threadShared[lindex] = threadMax;
        }
        workgroupBarrier();

        var reduceSize = min(cols, wg);
        for (var currSize = reduceSize >> 1;  currSize > 0; currSize = reduceSize >> 1) {
          reduceSize = currSize + (reduceSize & 1);
          if (lindex < currSize) {
            threadShared[lindex] = max(threadShared[lindex], threadShared[lindex + reduceSize]);
          }
          workgroupBarrier();
        }
        if (lindex == 0) {
          rowMaxShared = ${$}(${t="threadShared[0]",4===m?`max(max(${t}.x, ${t}.y), max(${t}.z, ${t}.w))`:2===m?`max(${t}.x, ${t}.y)`:3===m?`max(max(${t}.x, ${t}.y), ${t}.z)`:t});
        }
        workgroupBarrier();

        // find the rows sum
        var threadSum = ${$}(0.0);
        for (var col = lindex; col < cols; col += wg) {
          let subExp = exp(getValue(row, col, row_stride) - rowMaxShared);
          threadSum += subExp;
        }
        threadShared[lindex] = threadSum;
        workgroupBarrier();

        for (var currSize = wg >> 1;  currSize > 0; currSize = currSize >> 1) {
          if (lindex < currSize) {
            threadShared[lindex] = threadShared[lindex] + threadShared[lindex + currSize];
          }
          workgroupBarrier();
        }
        if (lindex == 0) {
          rowSumShared = ${$}(${tE("threadShared[0]",m)});
        }
        workgroupBarrier();

        // calculate final value for each element in the row
        for (var col = lindex; col < cols; col += wg) {
          let value = exp(getValue(row, col, row_stride) - rowMaxShared) / rowSumShared;
          setValue(row, col, row_stride, value);
        }
      }`}},{inputs:[d],outputs:[l?-1:0]})[0],l&&r.compute(tP(w,p),{inputs:[w]})},nr=e=>tb({axis:e.axis})}),sp=M(()=>{"use strict";nf(),ny(),nk(),ni=e=>Array.from(e.getBigInt64Array(),Number),na=e=>{var t;let r,i,a,n,s,o,u;(e=>{if(!e||2!==e.length)throw Error("Tile requires 2 inputs.");if(1!==e[0].dataType&&10!==e[0].dataType&&6!==e[0].dataType&&12!==e[0].dataType)throw Error("Tile only support float, float16, int32, and uint32 data types");if(7!==e[1].dataType)throw Error("Tile `repeats` input should be of int64 data type");if(1!==e[1].dims.length)throw Error("Tile `repeats` input should be 1-D");if(ni(e[1]).length!==e[0].dims.length)throw Error("Tile `repeats` input should have same number of elements as rank of input data tensor")})(e.inputs),e.compute((r=(t=e.inputs)[0].dims,a=((e,t)=>{let r=[];for(let i=0;i<e.length;++i)r.push(e[i]*t[i]);return r})(r,i=(void 0)??ni(t[1])),n=e2.size(a),s=t[0].dataType,o=tA("input",s,r.length),u=tO("output",s,a.length),{name:"Tile",shaderCache:{hint:`${i}`,inputDependencies:["rank"]},getRunData:()=>({outputs:[{dims:a,dataType:t[0].dataType}],dispatchGroup:{x:Math.ceil(n/64)},programUniforms:[{type:12,data:n},...tk(t[0].dims,a)]}),getShaderSource:e=>`
      const inputShape = ${o.indices(...r)};
      ${e.registerUniform("output_size","u32").declareVariables(o,u)}
      ${e.mainStart()}
      ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.output_size")}
      let output_indices = ${u.offsetToIndices("global_idx")};
      var input_indices: ${o.type.indices};
      for (var i = 0; i < ${r.length}; i++) {
        let input_dim_i = ${o.indicesGet("uniforms.input_shape","i")};
        let input_dim_value = ${u.indicesGet("output_indices","i")}  % input_dim_i;

        ${o.indicesSet("input_indices","i","input_dim_value")}
      }
      ${u.setByOffset("global_idx",o.getByIndices("input_indices"))}
    }`}),{inputs:[0]})}}),sc=M(()=>{"use strict";nf(),ny(),nk(),nn=e=>{e.compute((e=>{let t=e[1].dims,r=e[2].dims,i=e[0].dims,a=e[1].dataType,n=!(e2.areEqual(t,r)&&e2.areEqual(r,i)),s=t,o=e2.size(t);if(n){let e=e0.calcShape(e0.calcShape(t,r,!1),i,!1);if(!e)throw Error("Can't perform where op on the given tensors");s=e,o=e2.size(s)}let u=Math.ceil(o/4);return{name:"Where",shaderCache:{inputDependencies:["rank","rank","rank"]},getShaderSource:t=>((e,t,r,i,a)=>{let n=tO("output_data",a,r.length,4),s=tA("a_data",t[1].dataType,t[1].dims.length,4),o=tA("b_data",t[2].dataType,t[2].dims.length,4),u=tA("c_data",t[0].dataType,t[0].dims.length,4),l,d=(e,t,r)=>`select(${t}, ${e}, ${r})`;if(i){let e=(e,t,r="")=>{let i=`a_data[index_a${t}][component_a${t}]`,a=`b_data[index_b${t}][component_b${t}]`,l=`bool(c_data[index_c${t}] & (0xffu << (component_c${t} * 8)))`;return`
            let output_indices${t} = ${n.offsetToIndices(`global_idx * 4u + ${t}u`)};
            let offset_a${t} = ${s.broadcastedIndicesToOffset(`output_indices${t}`,n)};
            let offset_b${t} = ${o.broadcastedIndicesToOffset(`output_indices${t}`,n)};
            let offset_c${t} = ${u.broadcastedIndicesToOffset(`output_indices${t}`,n)};
            let index_a${t} = offset_a${t} / 4u;
            let index_b${t} = offset_b${t} / 4u;
            let index_c${t} = offset_c${t} / 4u;
            let component_a${t} = offset_a${t} % 4u;
            let component_b${t} = offset_b${t} % 4u;
            let component_c${t} = offset_c${t} % 4u;
            ${e}[${t}] = ${r}(${d(i,a,l)});
          `};l=9===a?`
            var data = vec4<u32>(0);
            ${e("data",0,"u32")}
            ${e("data",1,"u32")}
            ${e("data",2,"u32")}
            ${e("data",3,"u32")}
            output_data[global_idx] = dot(vec4<u32>(0x1, 0x100, 0x10000, 0x1000000), vec4<u32>(data));`:`
            ${e("output_data[global_idx]",0)}
            ${e("output_data[global_idx]",1)}
            ${e("output_data[global_idx]",2)}
            ${e("output_data[global_idx]",3)}
          `}else l=n.setByOffset("global_idx",d(s.getByOffset("global_idx"),o.getByOffset("global_idx"),u.getByOffset("global_idx")));return`
        ${e.registerUniform("vec_size","u32").declareVariables(u,s,o,n)}
        ${e.mainStart()}
        ${e.guardAgainstOutOfBoundsWorkgroupSizes("uniforms.vec_size")}
        ${l}
      }`})(t,e,s,n,a),getRunData:()=>({outputs:[{dims:s,dataType:a}],dispatchGroup:{x:Math.ceil(o/64/4)},programUniforms:[{type:12,data:u},...tk(i,t,r,s)]})}})(e.inputs))}}),sh=M(()=>{"use strict";nE(),nC(),nz(),nA(),nR(),nB(),nN(),nG(),nF(),nj(),nK(),nZ(),nQ(),nX(),nY(),nJ(),n0(),n2(),n1(),n3(),n5(),n7(),n9(),se(),st(),n4(),sr(),si(),sa(),sn(),ss(),nI(),so(),n8(),su(),sl(),sd(),n6(),sp(),nS(),nO(),sc(),ns=new Map([["Abs",[r_]],["Acos",[rb]],["Acosh",[r$]],["Add",[r5]],["ArgMax",[rd,rp]],["ArgMin",[rl,rp]],["Asin",[rv]],["Asinh",[rw]],["Atan",[rx]],["Atanh",[rk]],["Attention",[rf]],["AveragePool",[aq,aU]],["BatchNormalization",[rm]],["BiasAdd",[rg]],["BiasSplitGelu",[r6]],["Cast",[rT,rS]],["Ceil",[rE]],["Clip",[rI]],["Concat",[iu,il]],["Conv",[iD,iB]],["ConvTranspose",[iV,iW]],["Cos",[rC]],["Cosh",[rz]],["CumSum",[iG,iH]],["DepthToSpace",[iF,ij]],["DequantizeLinear",[aZ,aQ]],["Div",[r7]],["Einsum",[i0,i2]],["Elu",[rO,rA]],["Equal",[r9]],["Erf",[rB]],["Exp",[rN]],["Expand",[i3]],["FastGelu",[i4]],["Floor",[rD]],["FusedConv",[iD,iB]],["Gather",[i8,i6]],["GatherElements",[ar,at]],["GatherBlockQuantized",[i9,ae]],["GatherND",[i5,i7]],["Gelu",[rM]],["Gemm",[aa,ai]],["GlobalAveragePool",[aV,aL]],["GlobalMaxPool",[aK,aj]],["Greater",[ii]],["GreaterOrEqual",[is]],["GridSample",[ad,ap]],["GroupQueryAttention",[ak]],["HardSigmoid",[rH,rG]],["InstanceNormalization",[aT]],["LayerNormalization",[aI]],["LeakyRelu",[rP,rA]],["Less",[ia]],["LessOrEqual",[io]],["Log",[r1]],["MatMul",[aE]],["MatMulNBits",[aC,az]],["MaxPool",[aH,aF]],["Mul",[ie]],["MultiHeadAttention",[ag,ah]],["Neg",[rq]],["Not",[rU]],["Pad",[aA]],["Pow",[it]],["QuickGelu",[r4,rA]],["Range",[aX]],["Reciprocal",[rW]],["ReduceMin",[ri]],["ReduceMean",[t7]],["ReduceMax",[rr]],["ReduceSum",[rn]],["ReduceProd",[ra]],["ReduceL1",[t9]],["ReduceL2",[re]],["ReduceLogSum",[ro]],["ReduceLogSumExp",[rt]],["ReduceSumSquare",[rs]],["Relu",[rL]],["Resize",[a4,a6]],["RotaryEmbedding",[av]],["ScatterND",[a2,a0]],["Sigmoid",[rV]],["Sin",[rF]],["Sinh",[rj]],["Slice",[a9,ne]],["SkipLayerNormalization",[a8]],["Split",[a_,ab]],["Sqrt",[rK]],["Softmax",[nt,nr]],["Sub",[ir]],["Tan",[rZ]],["Tanh",[rX]],["ThresholdedRelu",[r2,rA]],["Tile",[na]],["Transpose",[tU,tq]],["Where",[nn]]])}),sf=M(()=>{"use strict";en(),ng(),nk(),no=class{constructor(e){this.backend=e,this.repo=new Map,this.attributesBound=!1}getArtifact(e){return this.repo.get(e)}setArtifact(e,t){this.repo.set(e,t)}run(e,t,r,i,a){O(e.programInfo.name);let n=this.backend.device,s=this.backend.getComputePassEncoder();this.backend.writeTimestamp(2*this.backend.pendingDispatchNumber);let o=[];for(let e of t)o.push({binding:o.length,resource:{buffer:e.buffer}});for(let e of r)o.push({binding:o.length,resource:{buffer:e.buffer}});a&&o.push({binding:o.length,resource:a});let u=n.createBindGroup({layout:e.computePipeline.getBindGroupLayout(0),entries:o,label:e.programInfo.name});if("capturing"===this.backend.sessionStatus){let t={kernelId:this.backend.currentKernelId,computePipeline:e.computePipeline,bindGroup:u,dispatchGroup:i};this.backend.capturedCommandList.get(this.backend.currentSessionId).push(t)}s.setPipeline(e.computePipeline),s.setBindGroup(0,u),s.dispatchWorkgroups(...i),this.backend.writeTimestamp(2*this.backend.pendingDispatchNumber+1),this.backend.pendingDispatchNumber++,(this.backend.pendingDispatchNumber>=this.backend.maxDispatchNumber||"at-passes"===this.backend.queryType)&&this.backend.endComputePass(),this.backend.pendingDispatchNumber>=this.backend.maxDispatchNumber&&this.backend.flush(),R(e.programInfo.name)}dispose(){}build(e,t){O(e.name);let r=this.backend.device,i=[];[{feature:"shader-f16",extension:"f16"},{feature:"subgroups",extension:"subgroups"}].forEach(e=>{r.features.has(e.feature)&&i.push(`enable ${e.extension};`)});let a=tD(t,this.backend.device.limits),n=e.getShaderSource(a),s=`${i.join(`
`)}
${a.additionalImplementations}
${n}`,o=r.createShaderModule({code:s,label:e.name});eY("verbose",()=>`[WebGPU] ${e.name} shader code: ${s}`);let u=r.createComputePipeline({compute:{module:o,entryPoint:"main"},layout:"auto",label:e.name});return R(e.name),{programInfo:e,computePipeline:u,uniformVariablesInfo:a.variablesInfo}}normalizeDispatchGroupSize(e){let t="number"==typeof e?e:e.x,r="number"==typeof e?1:e.y||1,i="number"==typeof e?1:e.z||1,a=this.backend.device.limits.maxComputeWorkgroupsPerDimension;if(t<=a&&r<=a&&i<=a)return[t,r,i];let n=t*r*i,s=Math.ceil(Math.sqrt(n));if(!(s>a))return[s,s,1];if((s=Math.ceil(Math.cbrt(n)))>a)throw Error("Total dispatch size exceeds WebGPU maximum.");return[s,s,s]}}}),sm={};P(sm,{WebGpuBackend:()=>sy});var sg,sy,s_=M(()=>{"use strict";en(),nf(),ng(),n_(),nw(),sh(),sf(),sg=class{constructor(e){e&&(this.architecture=e.architecture,this.vendor=e.vendor)}isArchitecture(e){return this.architecture===e}isVendor(e){return this.vendor===e}},sy=class{constructor(){this.currentSessionId=null,this.currentKernelId=null,this.commandEncoder=null,this.computePassEncoder=null,this.maxDispatchNumber=16,this.pendingDispatchNumber=0,this.pendingKernels=[],this.pendingQueries=new Map,this.sessionStatus="default",this.capturedCommandList=new Map,this.capturedPendingKernels=new Map,this.sessionExternalDataMapping=new Map}get currentKernelCustomData(){if(null===this.currentKernelId)throw Error("currentKernelCustomData(): currentKernelId is null. (should not happen)");let e=this.kernelCustomData.get(this.currentKernelId);return e||(e={},this.kernelCustomData.set(this.currentKernelId,e)),e}async initialize(e,t){this.env=e;let r=[],i={requiredLimits:{maxComputeWorkgroupStorageSize:t.limits.maxComputeWorkgroupStorageSize,maxComputeWorkgroupsPerDimension:t.limits.maxComputeWorkgroupsPerDimension,maxStorageBufferBindingSize:t.limits.maxStorageBufferBindingSize,maxBufferSize:t.limits.maxBufferSize,maxComputeInvocationsPerWorkgroup:t.limits.maxComputeInvocationsPerWorkgroup,maxComputeWorkgroupSizeX:t.limits.maxComputeWorkgroupSizeX,maxComputeWorkgroupSizeY:t.limits.maxComputeWorkgroupSizeY,maxComputeWorkgroupSizeZ:t.limits.maxComputeWorkgroupSizeZ},requiredFeatures:r},a=e=>t.features.has(e)&&r.push(e)&&!0;a("chromium-experimental-timestamp-query-inside-passes")||a("timestamp-query"),a("shader-f16"),a("subgroups"),this.device=await t.requestDevice(i),this.adapterInfo=new sg(t.info||await t.requestAdapterInfo()),this.gpuDataManager=ty(this),this.programManager=new no(this),this.kernels=new Map,this.kernelPersistentData=new Map,this.kernelCustomData=new Map,eX(e.logLevel,!!e.debug),this.device.onuncapturederror=e=>{e.error instanceof GPUValidationError&&console.error(`An uncaught WebGPU validation error was raised: ${e.error.message}`)},Object.defineProperty(this.env.webgpu,"device",{value:this.device,writable:!1,enumerable:!0,configurable:!1}),Object.defineProperty(this.env.webgpu,"adapter",{value:t,writable:!1,enumerable:!0,configurable:!1}),this.setQueryType()}dispose(){"u">typeof this.querySet&&this.querySet.destroy(),this.gpuDataManager.dispose()}getCommandEncoder(){return this.commandEncoder||(this.commandEncoder=this.device.createCommandEncoder()),this.commandEncoder}getComputePassEncoder(){if(!this.computePassEncoder){let e=this.getCommandEncoder(),t={};"at-passes"===this.queryType&&(t.timestampWrites={querySet:this.querySet,beginningOfPassWriteIndex:2*this.pendingDispatchNumber,endOfPassWriteIndex:2*this.pendingDispatchNumber+1}),this.computePassEncoder=e.beginComputePass(t)}return this.computePassEncoder}endComputePass(){this.computePassEncoder&&(this.computePassEncoder.end(),this.computePassEncoder=null)}flush(){let e;this.commandEncoder&&(O(),this.endComputePass(),"none"!==this.queryType&&(this.commandEncoder.resolveQuerySet(this.querySet,0,2*this.pendingDispatchNumber,this.queryResolveBuffer,0),e=this.device.createBuffer({size:2*this.pendingDispatchNumber*8,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST}),this.pendingQueries.set(e,this.pendingKernels),this.pendingKernels=[],this.commandEncoder.copyBufferToBuffer(this.queryResolveBuffer,0,e,0,2*this.pendingDispatchNumber*8)),this.device.queue.submit([this.commandEncoder.finish()]),this.gpuDataManager.refreshPendingBuffers(),this.commandEncoder=null,this.pendingDispatchNumber=0,"none"!==this.queryType&&e.mapAsync(GPUMapMode.READ).then(()=>{let t=new BigUint64Array(e.getMappedRange()),r=this.pendingQueries.get(e);for(let e=0;e<t.length/2;e++){let i=r[e],a=i.kernelId,n=this.kernels.get(a),s=n.kernelType,o=n.kernelName,u=i.programName,l=i.inputTensorViews,d=i.outputTensorViews,p=t[2*e],c=t[2*e+1];typeof this.queryTimeBase>"u"&&(this.queryTimeBase=p);let h=Number(p-this.queryTimeBase),f=Number(c-this.queryTimeBase);if(!Number.isSafeInteger(h)||!Number.isSafeInteger(f))throw RangeError("incorrect timestamp range");if(this.env.webgpu.profiling?.ondata)this.env.webgpu.profiling.ondata({version:1,inputsMetadata:l.map(e=>({dims:e.dims,dataType:eq(e.dataType)})),outputsMetadata:d.map(e=>({dims:e.dims,dataType:eq(e.dataType)})),kernelId:a,kernelType:s,kernelName:o,programName:u,startTime:h,endTime:f});else{let e="";l.forEach((t,r)=>{e+=`input[${r}]: [${t.dims}] | ${eq(t.dataType)}, `});let t="";d.forEach((e,r)=>{t+=`output[${r}]: [${e.dims}] | ${eq(e.dataType)}, `}),console.log(`[profiling] kernel "${a}|${s}|${o}|${u}" ${e}${t}execution time: ${f-h} ns`)}z("GPU",`${u}::${p}::${c}`)}e.unmap(),this.pendingQueries.delete(e)}),R())}run(e,t,r,i,a,n){var s,o,u;let l,d;O(e.name);let p=[];for(let e=0;e<t.length;++e){let r=t[e].data;if(0===r)continue;let i=this.gpuDataManager.get(r);if(!i)throw Error(`no GPU data for input: ${r}`);p.push(i)}let{outputs:c,dispatchGroup:h,programUniforms:f}=e.getRunData(t),m=0===r.length?c.map((e,t)=>t):r;if(m.length!==c.length)throw Error(`Output size ${m.length} must be equal to ${c.length}.`);let g=[],y=[];for(let e=0;e<c.length;++e){if(!Number.isInteger(m[e])||m[e]<-3||m[e]>=n)throw Error(`Invalid output index: ${m[e]}`);if(-3===m[e])continue;let t=-1===m[e],r=-2===m[e],s=t||r?a(c[e].dataType,c[e].dims):i(m[e],c[e].dataType,c[e].dims);if(g.push(s),0===s.data)continue;let o=this.gpuDataManager.get(s.data);if(!o)throw Error(`no GPU data for output: ${s.data}`);if(t&&this.temporaryData.push(o),r){let e=this.kernelPersistentData.get(this.currentKernelId);e||(e=[],this.kernelPersistentData.set(this.currentKernelId,e)),e.push(o)}y.push(o)}if(p.length!==t.length||y.length!==g.length){if(0===y.length)return R(e.name),g;throw Error(`Program ${e.name} has zero-sized tensor(s) in inputs or outputs. This is not supported now.`)}if(f){let e=0,t=[];f.forEach(r=>{let i="number"==typeof r.data?[r.data]:r.data;if(0===i.length)return;let a=10===r.type?2:4,n,s;10===r.type?(s=i.length>4?16:i.length>2?8:i.length*a,n=i.length>4?16:a*i.length):(s=i.length<=2?i.length*a:16,n=16),e=Math.ceil(e/s)*s,t.push(e);let o=10===r.type?8:4;e+=i.length>4?Math.ceil(i.length/o)*n:i.length*a});let r=new ArrayBuffer(e=16*Math.ceil(e/16));f.forEach((e,i)=>{let a=t[i],n="number"==typeof e.data?[e.data]:e.data;if(6===e.type)new Int32Array(r,a,n.length).set(n);else if(12===e.type)new Uint32Array(r,a,n.length).set(n);else if(10===e.type)new Uint16Array(r,a,n.length).set(n);else if(1===e.type)new Float32Array(r,a,n.length).set(n);else throw Error(`Unsupported uniform type: ${eq(e.type)}`)});let i=this.gpuDataManager.create(e,GPUBufferUsage.COPY_DST|GPUBufferUsage.UNIFORM);this.device.queue.writeBuffer(i.buffer,0,r,0,e),this.gpuDataManager.release(i.id),l={offset:0,size:e,buffer:i.buffer}}let _=this.programManager.normalizeDispatchGroupSize(h),b=(s=e,o=t,u=1===_[1]&&1===_[2],d=s.name,s.shaderCache?.hint&&(d+="["+s.shaderCache.hint+"]"),d+=":"+u+`:${((e,t)=>{if(t.length!==e.length)throw Error(`inputDependencies length ${t.length} is not equal to inputTensors length ${e.length}.`);let r=[];for(let i=0;i<e.length;++i){let a=e[i].dataType;switch(t[i]){case"none":r.push("");break;case"type":r.push(`${a}`);break;case"rank":{let t=e[i].dims.length;r.push(`${a};${t}`);break}case"dims":{let t=e[i].dims.join(",");r.push(`${a};${t}`);break}default:throw Error(`unsupported input dependency: ${t[i]}`)}}return r.join("|")})(o,s.shaderCache?.inputDependencies??Array(o.length).fill("dims"))}`),$=this.programManager.getArtifact(b);if($||($=this.programManager.build(e,_),this.programManager.setArtifact(b,$),eY("info",()=>`[artifact] key: ${b}, programName: ${e.name}`)),f&&$.uniformVariablesInfo){if(f.length!==$.uniformVariablesInfo.length)throw Error(`Uniform variables count mismatch: expect ${$.uniformVariablesInfo.length}, got ${f.length} in program "${$.programInfo.name}".`);for(let e=0;e<f.length;e++){let t=f[e],r=t.type,i="number"==typeof t.data?1:t.data.length,[a,n]=$.uniformVariablesInfo[e];if(r!==a||i!==n)throw Error(`Uniform variable ${e} mismatch: expect type ${a} with size ${n}, got type ${r} with size ${i} in program "${$.programInfo.name}".`)}}if(eY("info",()=>`[ProgramManager] run "${e.name}" (key=${b}) with ${_[0]}x${_[1]}x${_[2]}`),"none"!==this.queryType||"capturing"===this.sessionStatus){let e={kernelId:this.currentKernelId,programName:$.programInfo.name,inputTensorViews:t,outputTensorViews:g};this.pendingKernels.push(e),"capturing"===this.sessionStatus&&this.capturedPendingKernels.get(this.currentSessionId).push(e)}return this.programManager.run($,p,y,_,l),R(e.name),g}upload(e,t){this.gpuDataManager.upload(e,t)}memcpy(e,t){this.gpuDataManager.memcpy(e,t)}async download(e,t){await this.gpuDataManager.download(e,t)}alloc(e){return this.gpuDataManager.create(e).id}free(e){return this.gpuDataManager.release(e)}createKernel(e,t,r,i){let a=ns.get(e);if(!a)throw Error(`kernel not implemented: ${e}`);let n={kernelType:e,kernelName:i,kernelEntry:a[0],attributes:[a[1],r]};this.kernels.set(t,n)}releaseKernel(e){let t=this.kernelPersistentData.get(e);if(t){for(let e of t)this.gpuDataManager.release(e.id);this.kernelPersistentData.delete(e)}this.kernelCustomData.delete(e),this.kernels.delete(e)}computeKernel(e,t,r){let i=this.kernels.get(e);if(!i)throw Error(`kernel not created: ${e}`);let a=i.kernelType,n=i.kernelName,s=i.kernelEntry,o=i.attributes;if(null!==this.currentKernelId)throw Error(`kernel "[${a}] ${n}" is not allowed to be called recursively`);this.currentKernelId=e,o[0]&&(o[1]=o[0](o[1]),o[0]=void 0),eY("info",()=>`[WebGPU] Start to run kernel "[${a}] ${n}"...`);let u=this.env.debug;this.temporaryData=[];try{return u&&this.device.pushErrorScope("validation"),s(t,o[1]),0}catch(e){return r.push(Promise.resolve(`[WebGPU] Kernel "[${a}] ${n}" failed. ${e}`)),1}finally{for(let e of(u&&r.push(this.device.popErrorScope().then(e=>e?`GPU validation error for kernel "[${a}] ${n}": ${e.message}`:null)),this.temporaryData))this.gpuDataManager.release(e.id);this.temporaryData=[],this.currentKernelId=null}}registerBuffer(e,t,r,i){let a=this.sessionExternalDataMapping.get(e);a||(a=new Map,this.sessionExternalDataMapping.set(e,a));let n=a.get(t),s=this.gpuDataManager.registerExternalBuffer(r,i,n);return a.set(t,[s,r]),s}unregisterBuffers(e){let t=this.sessionExternalDataMapping.get(e);t&&(t.forEach(e=>this.gpuDataManager.unregisterExternalBuffer(e[0])),this.sessionExternalDataMapping.delete(e))}getBuffer(e){let t=this.gpuDataManager.get(e);if(!t)throw Error(`no GPU data for buffer: ${e}`);return t.buffer}createDownloader(e,t,r){return async()=>{let i=await tm(this,e,t);return e8(i.buffer,r)}}writeTimestamp(e){"inside-passes"===this.queryType&&this.computePassEncoder.writeTimestamp(this.querySet,e)}setQueryType(){this.queryType="none",(this.env.webgpu.profiling?.mode==="default"||(typeof this.env.trace>"u"?this.env.wasm.trace:this.env.trace))&&(this.device.features.has("chromium-experimental-timestamp-query-inside-passes")?this.queryType="inside-passes":this.device.features.has("timestamp-query")&&(this.queryType="at-passes"),"none"!==this.queryType&&typeof this.querySet>"u"&&(this.querySet=this.device.createQuerySet({type:"timestamp",count:2*this.maxDispatchNumber}),this.queryResolveBuffer=this.device.createBuffer({size:2*this.maxDispatchNumber*8,usage:GPUBufferUsage.COPY_SRC|GPUBufferUsage.QUERY_RESOLVE})))}captureBegin(){eY("info","captureBegin"),this.capturedCommandList.get(this.currentSessionId)||this.capturedCommandList.set(this.currentSessionId,[]),this.capturedPendingKernels.get(this.currentSessionId)||this.capturedPendingKernels.set(this.currentSessionId,[]),this.flush(),this.sessionStatus="capturing"}captureEnd(){eY("info","captureEnd"),this.flush(),this.sessionStatus="default"}replay(){eY("info","replay"),this.sessionStatus="replaying";let e=this.capturedCommandList.get(this.currentSessionId),t=this.capturedPendingKernels.get(this.currentSessionId),r=e.length;this.pendingKernels=[];for(let i=0;i<r;i++){let r=this.getComputePassEncoder(),a=e[i];this.writeTimestamp(2*this.pendingDispatchNumber),r.setPipeline(a.computePipeline),r.setBindGroup(0,a.bindGroup),r.dispatchWorkgroups(...a.dispatchGroup),this.writeTimestamp(2*this.pendingDispatchNumber+1),this.pendingDispatchNumber++,"none"!==this.queryType&&this.pendingKernels.push(t[i]),(this.pendingDispatchNumber>=this.maxDispatchNumber||"at-passes"===this.queryType)&&this.endComputePass(),this.pendingDispatchNumber>=this.maxDispatchNumber&&this.flush()}this.flush(),this.sessionStatus="default"}onCreateSession(){this.gpuDataManager.onCreateSession()}onReleaseSession(e){this.unregisterBuffers(e),this.capturedCommandList.has(e)&&this.capturedCommandList.delete(e),this.capturedPendingKernels.has(e)&&this.capturedPendingKernels.delete(e),this.gpuDataManager.onReleaseSession(e)}onRunStart(e){this.currentSessionId=e,this.setQueryType()}}}),sb={};P(sb,{init:()=>sw});var s$,sv,sw,sx,sk,sS,sT,sI,sE,sC,sz,sA,sO,sR,sB,sN,sD,sM,sP,sU,sq,sW,sL,sV,sG,sH,sF,sj,sK,sZ,sQ,sX,sY,sJ,s0,s2=M(()=>{"use strict";nf(),ng(),ny(),n$(),s$=class e{constructor(e,t,r,i){this.module=e,this.dataType=t,this.data=r,this.dims=i}getFloat32Array(){if(1!==this.dataType)throw Error("Invalid data type");let e=e2.size(this.dims);return 0===e?new Float32Array:new Float32Array(this.module.HEAP8.buffer,this.data,e)}getBigInt64Array(){if(7!==this.dataType)throw Error("Invalid data type");let e=e2.size(this.dims);return 0===e?new BigInt64Array:new BigInt64Array(this.module.HEAP8.buffer,this.data,e)}getInt32Array(){if(6!==this.dataType)throw Error("Invalid data type");let e=e2.size(this.dims);return 0===e?new Int32Array:new Int32Array(this.module.HEAP8.buffer,this.data,e)}getUint16Array(){if(10!==this.dataType&&4!==this.dataType)throw Error("Invalid data type");let e=e2.size(this.dims);return 0===e?new Uint16Array:new Uint16Array(this.module.HEAP8.buffer,this.data,e)}reshape(t){if(e2.size(t)!==e2.size(this.dims))throw Error("Invalid new shape");return new e(this.module,this.dataType,this.data,t)}},sv=class{constructor(e,t,r){this.module=e,this.backend=t,this.customDataOffset=0,this.customDataSize=0,this.adapterInfo=t.adapterInfo;let i=e.PTR_SIZE,a=r/e.PTR_SIZE,n=4===i?"i32":"i64";this.opKernelContext=Number(e.getValue(i*a++,n));let s=Number(e.getValue(i*a++,n));this.outputCount=Number(e.getValue(i*a++,n)),this.customDataOffset=Number(e.getValue(i*a++,"*")),this.customDataSize=Number(e.getValue(i*a++,n));let o=[];for(let t=0;t<s;t++){let t=Number(e.getValue(i*a++,n)),r=Number(e.getValue(i*a++,"*")),s=Number(e.getValue(i*a++,n)),u=[];for(let t=0;t<s;t++)u.push(Number(e.getValue(i*a++,n)));o.push(new s$(e,t,r,u))}this.inputs=o}get kernelCustomData(){return this.backend.currentKernelCustomData}get customDataBuffer(){return this.module.HEAPU8.subarray(this.customDataOffset,this.customDataOffset+this.customDataSize)}compute(e,t){let r=t?.inputs?.map(e=>"number"==typeof e?this.inputs[e]:e)??this.inputs,i=t?.outputs??[],a=(e,t,r)=>new s$(this.module,t,this.output(e,r),r),n=(e,t)=>{let r=eW(e,t);if(!r)throw Error(`Unsupported data type: ${e}`);let i=r>0?this.backend.gpuDataManager.create(r).id:0;return new s$(this.module,e,i,t)};return this.backend.run(e,r,i,a,n,this.outputCount)}output(e,t){let r=this.module.stackSave();try{let r=this.module.PTR_SIZE,i=4===r?"i32":"i64",a=this.module.stackAlloc((1+t.length)*r);this.module.setValue(a,t.length,i);for(let e=0;e<t.length;e++)this.module.setValue(a+r*(e+1),t[e],i);return this.module._JsepOutput(this.opKernelContext,e,a)}catch(r){throw Error(`Failed to generate kernel's output[${e}] with dims [${t}]. If you are running with pre-allocated output, please make sure the output type/dims are correct. Error: ${r}`)}finally{this.module.stackRestore(r)}}},sw=async(e,t,r,i)=>{let a=t.jsepInit;if(!a)throw Error("Failed to initialize JSEP. The WebAssembly module is not built with JSEP support.");if("webgpu"===e){let e=new(s_(),U(sm)).WebGpuBackend;await e.initialize(r,i),a("webgpu",[e,t=>e.alloc(Number(t)),t=>e.free(t),(r,i,a,n=!1)=>{if(n)eY("verbose",()=>`[WebGPU] jsepCopyGpuToGpu: src=${Number(r)}, dst=${Number(i)}, size=${Number(a)}`),e.memcpy(Number(r),Number(i));else{eY("verbose",()=>`[WebGPU] jsepCopyCpuToGpu: dataOffset=${Number(r)}, gpuDataId=${Number(i)}, size=${Number(a)}`);let n=t.HEAPU8.subarray(Number(r>>>0),Number(r>>>0)+Number(a));e.upload(Number(i),n)}},async(r,i,a)=>{eY("verbose",()=>`[WebGPU] jsepCopyGpuToCpu: gpuDataId=${r}, dataOffset=${i}, size=${a}`),await e.download(Number(r),()=>t.HEAPU8.subarray(Number(i)>>>0,Number(i+a)>>>0))},(r,i,a)=>e.createKernel(r,Number(i),a,t.UTF8ToString(t._JsepGetNodeName(Number(i)))),t=>e.releaseKernel(t),(r,i,a,n)=>{eY("verbose",()=>`[WebGPU] jsepRun: sessionHandle=${a}, kernel=${r}, contextDataOffset=${i}`);let s=new sv(t,e,Number(i));return e.computeKernel(Number(r),s,n)},()=>e.captureBegin(),()=>e.captureEnd(),()=>e.replay()])}else{let e=new tl(r);a("webnn",[e,()=>e.reserveTensorId(),t=>e.releaseTensorId(t),async(t,r,i,a,n)=>e.ensureTensor(t,r,i,a,n),(t,r)=>{e.uploadTensor(t,r)},async(t,r)=>e.downloadTensor(t,r)])}}}),s1=M(()=>{"use strict";nc(),nh(),nf(),nd(),np(),nm(),sx=async e=>{var t,r;t=e.wasm.numThreads,r=eV(e.logLevel),0!==eA()._OrtInit(t,r)&&eB("Can't initialize onnxruntime.")},sk=async(e,t)=>{eA().asyncInit?.();{let r=(s2(),U(sb)).init;if("webgpu"===t){if(typeof navigator>"u"||!navigator.gpu)throw Error("WebGPU is not supported in current environment");let t=e.webgpu.adapter;if(t){if("object"!=typeof t.limits||"object"!=typeof t.features||"function"!=typeof t.requestDevice)throw Error("Invalid GPU adapter set in `env.webgpu.adapter`. It must be a GPUAdapter object.")}else{let r=e.webgpu.powerPreference;if(void 0!==r&&"low-power"!==r&&"high-performance"!==r)throw Error(`Invalid powerPreference setting: "${r}"`);let i=e.webgpu.forceFallbackAdapter;if(void 0!==i&&"boolean"!=typeof i)throw Error(`Invalid forceFallbackAdapter setting: "${i}"`);if(!(t=await navigator.gpu.requestAdapter({powerPreference:r,forceFallbackAdapter:i})))throw Error('Failed to get GPU adapter. You may need to enable flag "--enable-unsafe-webgpu" if you are using Chrome.')}await r("webgpu",eA(),e,t)}if("webnn"===t){if(typeof navigator>"u"||!navigator.ml)throw Error("WebNN is not supported in current environment");await r("webnn",eA(),e)}}},sS=new Map,sT=(e,t)=>{let r=eA(),i=r.stackSave(),a=0;try{let i=r.PTR_SIZE,n=r.stackAlloc(2*i);0!==r._OrtGetInputOutputMetadata(e,t,n,n+i)&&eB("Can't get session input/output metadata.");let s=Number(r.getValue(n,"*"));a=Number(r.getValue(n+i,"*"));let o=r.HEAP32[a/4];if(0===o)return[s,0];let u=r.HEAPU32[a/4+1],l=[];for(let e=0;e<u;e++){let t=Number(r.getValue(a+8+e*i,"*"));l.push(0!==t?r.UTF8ToString(t):Number(r.getValue(a+8+(e+u)*i,"*")))}return[s,o,l]}finally{r.stackRestore(i),0!==a&&r._OrtFree(a)}},sI=e=>{let t=eA(),r=t._malloc(e.byteLength);if(0===r)throw Error(`Can't create a session. failed to allocate a buffer of size ${e.byteLength}.`);return t.HEAPU8.set(e,r),[r,e.byteLength]},sE=async(e,t)=>{let r,i,a=eA();Array.isArray(e)?[r,i]=e:e.buffer===a.HEAPU8.buffer?[r,i]=[e.byteOffset,e.byteLength]:[r,i]=sI(e);let n=0,s=0,o=0,u=[],l=[],d=[];try{if([s,u]=await eP(t),t?.externalData&&a.mountExternalData){let e=[];for(let r of t.externalData){let t="string"==typeof r?r:r.path;e.push(ej("string"==typeof r?r:r.data).then(e=>{a.mountExternalData(t,e)}))}await Promise.all(e)}for(let e of t?.executionProviders??[])if(("string"==typeof e?e:e.name)==="webnn"){if(a.shouldTransferToMLTensor=!1,"string"!=typeof e){let t=e?.context,r=e?.gpuDevice,i=e?.deviceType,n=e?.powerPreference;t?a.currentContext=t:r?a.currentContext=await a.webnnCreateMLContext(r):a.currentContext=await a.webnnCreateMLContext({deviceType:i,powerPreference:n})}else a.currentContext=await a.webnnCreateMLContext();break}n=await a._OrtCreateSession(r,i,s),a.webgpuOnCreateSession?.(n),0===n&&eB("Can't create a session."),a.jsepOnCreateSession?.(),a.currentContext&&(a.webnnRegisterMLContext(n,a.currentContext),a.currentContext=void 0,a.shouldTransferToMLTensor=!0);let[e,p]=(e=>{let t=eA(),r=t.stackSave();try{let r=t.PTR_SIZE,i=t.stackAlloc(2*r);0!==t._OrtGetInputOutputCount(e,i,i+r)&&eB("Can't get session input/output count.");let a=4===r?"i32":"i64";return[Number(t.getValue(i,a)),Number(t.getValue(i+r,a))]}finally{t.stackRestore(r)}})(n),c=!!t?.enableGraphCapture,h=[],f=[],m=[],g=[],y=[];for(let t=0;t<e;t++){let[e,r,i]=sT(n,t);0===e&&eB("Can't get an input name."),l.push(e);let s=a.UTF8ToString(e);h.push(s),m.push(0===r?{name:s,isTensor:!1}:{name:s,isTensor:!0,type:eq(r),shape:i})}for(let r=0;r<p;r++){let[i,s,o]=sT(n,r+e);0===i&&eB("Can't get an output name."),d.push(i);let u=a.UTF8ToString(i);f.push(u),g.push(0===s?{name:u,isTensor:!1}:{name:u,isTensor:!0,type:eq(s),shape:o});{if(c&&t?.preferredOutputLocation===void 0){y.push("gpu-buffer");continue}let e="string"==typeof t?.preferredOutputLocation?t.preferredOutputLocation:t?.preferredOutputLocation?.[u]??"cpu",r=a.webnnIsGraphOutput;if("cpu"===e&&r&&r(n,u)){y.push("ml-tensor-cpu-output");continue}if("cpu"!==e&&"cpu-pinned"!==e&&"gpu-buffer"!==e&&"ml-tensor"!==e)throw Error(`Not supported preferred output location: ${e}.`);if(c&&"gpu-buffer"!==e)throw Error(`Not supported preferred output location: ${e}. Only 'gpu-buffer' location is supported when enableGraphCapture is true.`);y.push(e)}}let _=null;return y.some(e=>"gpu-buffer"===e||"ml-tensor"===e||"ml-tensor-cpu-output"===e)&&(o=a._OrtCreateBinding(n),0===o&&eB("Can't create IO binding."),_={handle:o,outputPreferredLocations:y,outputPreferredLocationsEncoded:y.map(e=>"ml-tensor-cpu-output"===e?"ml-tensor":e).map(e=>eF(e))}),sS.set(n,[n,l,d,_,c,!1]),[n,h,f,m,g]}catch(e){throw l.forEach(e=>a._OrtFree(e)),d.forEach(e=>a._OrtFree(e)),0!==o&&0!==a._OrtReleaseBinding(o)&&eB("Can't release IO binding."),0!==n&&0!==a._OrtReleaseSession(n)&&eB("Can't release session."),e}finally{a._free(r),0!==s&&0!==a._OrtReleaseSessionOptions(s)&&eB("Can't release session options."),u.forEach(e=>a._free(e)),a.unmountExternalData?.()}},sC=e=>{let t=eA(),r=sS.get(e);if(!r)throw Error(`cannot release session. invalid session id: ${e}`);let[i,a,n,s,o]=r;s&&(o&&0!==t._OrtClearBoundOutputs(s.handle)&&eB("Can't clear bound outputs."),0!==t._OrtReleaseBinding(s.handle)&&eB("Can't release IO binding.")),t.jsepOnReleaseSession?.(e),t.webnnOnReleaseSession?.(e),t.webgpuOnReleaseSession?.(e),a.forEach(e=>t._OrtFree(e)),n.forEach(e=>t._OrtFree(e)),0!==t._OrtReleaseSession(i)&&eB("Can't release session."),sS.delete(e)},sz=async(e,t,r,i,a,n,s=!1)=>{if(!e)return void t.push(0);let o=eA(),u=o.PTR_SIZE,l=e[0],d=e[1],p=e[3],c=p,h,f;if("string"===l&&("gpu-buffer"===p||"ml-tensor"===p))throw Error("String tensor is not supported on GPU.");if(s&&"gpu-buffer"!==p)throw Error(`External buffer must be provided for input/output index ${n} when enableGraphCapture is true.`);if("gpu-buffer"===p){let t=e[2].gpuBuffer;f=eW(eU(l),d);{let e=o.jsepRegisterBuffer;if(!e)throw Error('Tensor location "gpu-buffer" is not supported without using WebGPU.');h=e(i,n,t,f)}}else if("ml-tensor"===p){let t=e[2].mlTensor;f=eW(eU(l),d);let r=o.webnnRegisterMLTensor;if(!r)throw Error('Tensor location "ml-tensor" is not supported without using WebNN.');h=r(i,t,eU(l),d)}else{let t=e[2];if(Array.isArray(t)){f=u*t.length,h=o._malloc(f),r.push(h);for(let e=0;e<t.length;e++){if("string"!=typeof t[e])throw TypeError(`tensor data at index ${e} is not a string`);o.setValue(h+e*u,eO(t[e],r),"*")}}else{let e=o.webnnIsGraphInput,n=o.webnnIsGraphOutput;if("string"!==l&&e&&n){let s=o.UTF8ToString(a);if(e(i,s)||n(i,s)){let e=eU(l);f=eW(e,d),c="ml-tensor";let r=o.webnnCreateTemporaryTensor,a=o.webnnUploadTensor;if(!r||!a)throw Error('Tensor location "ml-tensor" is not supported without using WebNN.');let n=await r(i,e,d);a(n,new Uint8Array(t.buffer,t.byteOffset,t.byteLength)),h=n}else f=t.byteLength,h=o._malloc(f),r.push(h),o.HEAPU8.set(new Uint8Array(t.buffer,t.byteOffset,f),h)}else f=t.byteLength,h=o._malloc(f),r.push(h),o.HEAPU8.set(new Uint8Array(t.buffer,t.byteOffset,f),h)}}let m=o.stackSave(),g=o.stackAlloc(4*d.length);try{d.forEach((e,t)=>o.setValue(g+t*u,e,4===u?"i32":"i64"));let e=o._OrtCreateTensor(eU(l),h,f,g,d.length,eF(c));0===e&&eB(`Can't create tensor for input/output. session=${i}, index=${n}.`),t.push(e)}finally{o.stackRestore(m)}},sA=async(e,t,r,i,a,n)=>{let s=eA(),o=s.PTR_SIZE,u=sS.get(e);if(!u)throw Error(`cannot run inference. invalid session id: ${e}`);let l=u[0],d=u[1],p=u[2],c=u[3],h=u[4],f=u[5],m=t.length,g=i.length,y=0,_=[],b=[],$=[],v=[],w=s.stackSave(),x=s.stackAlloc(m*o),k=s.stackAlloc(m*o),S=s.stackAlloc(g*o),T=s.stackAlloc(g*o);try{let u;[y,_]=eN(n);for(let i=0;i<m;i++)await sz(r[i],b,v,e,d[t[i]],t[i],h);for(let t=0;t<g;t++)await sz(a[t],$,v,e,p[i[t]],m+i[t],h);for(let e=0;e<m;e++)s.setValue(x+e*o,b[e],"*"),s.setValue(k+e*o,d[t[e]],"*");for(let e=0;e<g;e++)s.setValue(S+e*o,$[e],"*"),s.setValue(T+e*o,p[i[e]],"*");if(c&&!f){let{handle:r,outputPreferredLocations:n,outputPreferredLocationsEncoded:o}=c;if(d.length!==m)throw Error(`input count from feeds (${m}) is expected to be always equal to model's input count (${d.length}).`);for(let i=0;i<m;i++){let a=t[i];await s._OrtBindInput(r,d[a],b[i])!==0&&eB(`Can't bind input[${i}] for session=${e}.`)}for(let t=0;t<g;t++){let u=i[t];a[t]?.[3]?0!==s._OrtBindOutput(r,p[u],$[t],0)&&eB(`Can't bind pre-allocated output[${t}] for session=${e}.`):0!==s._OrtBindOutput(r,p[u],0,o[u])&&eB(`Can't bind output[${t}] to ${n[t]} for session=${e}.`)}sS.set(e,[l,d,p,c,h,!0])}s.jsepOnRunStart?.(l),s.webnnOnRunStart?.(l),u=c?await s._OrtRunWithBinding(l,c.handle,g,S,y):await s._OrtRun(l,k,x,m,T,g,S,y),0!==u&&eB("failed to call OrtRun().");let w=[],I=[];for(let t=0;t<g;t++){let r=Number(s.getValue(S+t*o,"*"));if(r===$[t]){w.push(a[t]);continue}let n=s.stackSave(),u=s.stackAlloc(4*o),l=!1,d,p=0;try{0!==s._OrtGetTensorData(r,u,u+o,u+2*o,u+3*o)&&eB(`Can't access output tensor data on index ${t}.`);let a=4===o?"i32":"i64",n=Number(s.getValue(u,a));p=s.getValue(u+o,"*");let h=s.getValue(u+2*o,"*"),f=Number(s.getValue(u+3*o,a)),m=[];for(let e=0;e<f;e++)m.push(Number(s.getValue(h+e*o,a)));0!==s._OrtFree(h)&&eB("Can't free memory for tensor dims.");let g=m.reduce((e,t)=>e*t,1);d=eq(n);let y=c?.outputPreferredLocations[i[t]];if("string"===d){if("gpu-buffer"===y||"ml-tensor"===y)throw Error("String tensor is not supported on GPU.");let e=[];for(let t=0;t<g;t++){let r=s.getValue(p+t*o,"*"),i=s.getValue(p+(t+1)*o,"*"),a=t===g-1?void 0:i-r;e.push(s.UTF8ToString(r,a))}w.push([d,m,e,"cpu"])}else if("gpu-buffer"===y&&g>0){let e=s.jsepGetBuffer;if(!e)throw Error('preferredLocation "gpu-buffer" is not supported without using WebGPU.');let t=e(p),i=eW(n,g);if(void 0===i||!eG(d))throw Error(`Unsupported data type: ${d}`);l=!0,w.push([d,m,{gpuBuffer:t,download:s.jsepCreateDownloader(t,i,d),dispose:()=>{0!==s._OrtReleaseTensor(r)&&eB("Can't release tensor.")}},"gpu-buffer"])}else if("ml-tensor"===y&&g>0){let t=s.webnnEnsureTensor,i=s.webnnIsGraphInputOutputTypeSupported;if(!t||!i)throw Error('preferredLocation "ml-tensor" is not supported without using WebNN.');if(void 0===eW(n,g)||!eH(d))throw Error(`Unsupported data type: ${d}`);if(!i(e,d,!1))throw Error(`preferredLocation "ml-tensor" for ${d} output is not supported by current WebNN Context.`);let a=await t(e,p,n,m,!1);l=!0,w.push([d,m,{mlTensor:a,download:s.webnnCreateMLTensorDownloader(p,d),dispose:()=>{s.webnnReleaseTensorId(p),s._OrtReleaseTensor(r)}},"ml-tensor"])}else if("ml-tensor-cpu-output"===y&&g>0){let e=s.webnnCreateMLTensorDownloader(p,d)(),t=w.length;l=!0,I.push((async()=>{let i=[t,await e];return s.webnnReleaseTensorId(p),s._OrtReleaseTensor(r),i})()),w.push([d,m,[],"cpu"])}else{let e=new(eL(d))(g);new Uint8Array(e.buffer,e.byteOffset,e.byteLength).set(s.HEAPU8.subarray(p,p+e.byteLength)),w.push([d,m,e,"cpu"])}}finally{s.stackRestore(n),"string"===d&&p&&s._free(p),l||s._OrtReleaseTensor(r)}}for(let[t,r]of(c&&!h&&(0!==s._OrtClearBoundOutputs(c.handle)&&eB("Can't clear bound outputs."),sS.set(e,[l,d,p,c,h,!1])),await Promise.all(I)))w[t][2]=r;return w}finally{s.webnnOnRunEnd?.(l),s.stackRestore(w),b.forEach(e=>s._OrtReleaseTensor(e)),$.forEach(e=>s._OrtReleaseTensor(e)),v.forEach(e=>s._free(e)),0!==y&&s._OrtReleaseRunOptions(y),_.forEach(e=>s._free(e))}},sO=e=>{let t=eA(),r=sS.get(e);if(!r)throw Error("invalid session id");let i=r[0],a=t._OrtEndProfiling(i);0===a&&eB("Can't get an profile file name."),t._OrtFree(a)},sR=e=>{let t=[];for(let r of e){let e=r[2];!Array.isArray(e)&&"buffer"in e&&t.push(e.buffer)}return t}}),s3=M(()=>{"use strict";en(),s1(),nd(),nl(),sB=()=>!!h.wasm.proxy&&"u">typeof document,sD=!1,sM=!1,sP=!1,sW=new Map,sL=(e,t)=>{let r=sW.get(e);r?r.push(t):sW.set(e,[t])},sV=()=>{if(sD||!sM||sP||!sN)throw Error("worker not ready")},sG=e=>{switch(e.data.type){case"init-wasm":sD=!1,e.data.err?(sP=!0,sq[1](e.data.err)):(sM=!0,sq[0]()),sU&&(URL.revokeObjectURL(sU),sU=void 0);break;case"init-ep":case"copy-from":case"create":case"release":case"run":case"end-profiling":{let t=sW.get(e.data.type);e.data.err?t.shift()[1](e.data.err):t.shift()[0](e.data.out)}}},sH=async()=>{if(!sM){if(sD)throw Error("multiple calls to 'initWasm()' detected.");if(sP)throw Error("previous call to 'initWasm()' failed.");if(sD=!0,sB())return new Promise((e,t)=>{sN?.terminate(),ex().then(([r,i])=>{try{(sN=i).onerror=e=>t(e),sN.onmessage=sG,sq=[e,t];let a={type:"init-wasm",in:h};!a.in.wasm.wasmPaths&&(r||eg)&&(a.in.wasm.wasmPaths={wasm:new URL("ort-wasm-simd-threaded.jsep.wasm",import.meta.url).href}),sN.postMessage(a),sU=r}catch(e){t(e)}},t)});try{await ez(h.wasm),await sx(h),sM=!0}catch(e){throw sP=!0,e}finally{sD=!1}}},sF=async e=>{if(sB())return sV(),new Promise((t,r)=>{sL("init-ep",[t,r]);let i={type:"init-ep",in:{epName:e,env:h}};sN.postMessage(i)});await sk(h,e)},sj=async e=>sB()?(sV(),new Promise((t,r)=>{sL("copy-from",[t,r]),sN.postMessage({type:"copy-from",in:{buffer:e}},[e.buffer])})):sI(e),sK=async(e,t)=>{if(!sB())return sE(e,t);if(t?.preferredOutputLocation)throw Error('session option "preferredOutputLocation" is not supported for proxy.');return sV(),new Promise((r,i)=>{sL("create",[r,i]);let a={type:"create",in:{model:e,options:{...t}}},n=[];e instanceof Uint8Array&&n.push(e.buffer),sN.postMessage(a,n)})},sZ=async e=>{if(sB())return sV(),new Promise((t,r)=>{sL("release",[t,r]),sN.postMessage({type:"release",in:e})});sC(e)},sQ=async(e,t,r,i,a,n)=>{if(!sB())return sA(e,t,r,i,a,n);if(r.some(e=>"cpu"!==e[3]))throw Error("input tensor on GPU is not supported for proxy.");if(a.some(e=>e))throw Error("pre-allocated output tensor is not supported for proxy.");return sV(),new Promise((a,s)=>{sL("run",[a,s]),sN.postMessage({type:"run",in:{sessionId:e,inputIndices:t,inputs:r,outputIndices:i,options:n}},sR(r))})},sX=async e=>{if(sB())return sV(),new Promise((t,r)=>{sL("end-profiling",[t,r]),sN.postMessage({type:"end-profiling",in:e})});sO(e)}}),s4=M(()=>{"use strict";en(),s3(),nf(),es(),nm(),sY=(e,t)=>{switch(e.location){case"cpu":return[e.type,e.dims,e.data,"cpu"];case"gpu-buffer":return[e.type,e.dims,{gpuBuffer:e.gpuBuffer},"gpu-buffer"];case"ml-tensor":return[e.type,e.dims,{mlTensor:e.mlTensor},"ml-tensor"];default:throw Error(`invalid data location: ${e.location} for ${t()}`)}},sJ=e=>{switch(e[3]){case"cpu":return new C(e[0],e[2],e[1]);case"gpu-buffer":{let t=e[0];if(!eG(t))throw Error(`not supported data type: ${t} for deserializing GPU tensor`);let{gpuBuffer:r,download:i,dispose:a}=e[2];return C.fromGpuBuffer(r,{dataType:t,dims:e[1],download:i,dispose:a})}case"ml-tensor":{let t=e[0];if(!eH(t))throw Error(`not supported data type: ${t} for deserializing MLTensor tensor`);let{mlTensor:r,download:i,dispose:a}=e[2];return C.fromMLTensor(r,{dataType:t,dims:e[1],download:i,dispose:a})}default:throw Error(`invalid data location: ${e[3]}`)}},s0=class{async fetchModelAndCopyToWasmMemory(e){return sj(await ej(e))}async loadModel(e,t){let r;O(),r="string"==typeof e?await this.fetchModelAndCopyToWasmMemory(e):e,[this.sessionId,this.inputNames,this.outputNames,this.inputMetadata,this.outputMetadata]=await sK(r,t),R()}async dispose(){return sZ(this.sessionId)}async run(e,t,r){O();let i=[],a=[];Object.entries(e).forEach(e=>{let t=e[0],r=e[1],n=this.inputNames.indexOf(t);if(-1===n)throw Error(`invalid input '${t}'`);i.push(r),a.push(n)});let n=[],s=[];Object.entries(t).forEach(e=>{let t=e[0],r=e[1],i=this.outputNames.indexOf(t);if(-1===i)throw Error(`invalid output '${t}'`);n.push(r),s.push(i)});let o=i.map((e,t)=>sY(e,()=>`input "${this.inputNames[a[t]]}"`)),u=n.map((e,t)=>e?sY(e,()=>`output "${this.outputNames[s[t]]}"`):null),l=await sQ(this.sessionId,a,o,s,u,r),d={};for(let e=0;e<l.length;e++)d[this.outputNames[s[e]]]=n[e]??sJ(l[e]);return R(),d}startProfiling(){}endProfiling(){sX(this.sessionId)}}}),s6={};P(s6,{OnnxruntimeWebAssemblyBackend:()=>s5,initializeFlags:()=>s8,wasmBackend:()=>s7});var s8,s5,s7,s9=M(()=>{"use strict";en(),s3(),s4(),s8=()=>{("number"!=typeof h.wasm.initTimeout||h.wasm.initTimeout<0)&&(h.wasm.initTimeout=0);let e=h.wasm.simd;if("boolean"!=typeof e&&void 0!==e&&"fixed"!==e&&"relaxed"!==e&&(console.warn(`Property "env.wasm.simd" is set to unknown value "${e}". Reset it to \`false\` and ignore SIMD feature checking.`),h.wasm.simd=!1),"boolean"!=typeof h.wasm.proxy&&(h.wasm.proxy=!1),"boolean"!=typeof h.wasm.trace&&(h.wasm.trace=!1),"number"!=typeof h.wasm.numThreads||!Number.isInteger(h.wasm.numThreads)||h.wasm.numThreads<=0)if("u">typeof self&&!self.crossOriginIsolated)h.wasm.numThreads=1;else{let e=typeof navigator>"u"?D("node:os").cpus().length:navigator.hardwareConcurrency;h.wasm.numThreads=Math.min(4,Math.ceil((e||1)/2))}},s7=new(s5=class{async init(e){s8(),await sH(),await sF(e)}async createInferenceSessionHandler(e,t){let r=new s0;return await r.loadModel(e,t),r}})});en(),en(),en();var oe=ea;{let e=(s9(),U(s6)).wasmBackend;o("webgpu",e,5),o("webnn",e,5),o("cpu",e,10),o("wasm",e,10)}Object.defineProperty(h.versions,"web",{value:"1.22.0",enumerable:!0});export{N as InferenceSession,z as TRACE,O as TRACE_FUNC_BEGIN,R as TRACE_FUNC_END,C as Tensor,oe as default,h as env,o as registerBackend};