1:"$Sreact.fragment"
2:"static/chunks/7196-05706c26c03ba4af.js"
3:"static/chunks/6609-d828c87ffe266439.js"
4:"static/chunks/5086-9c162bf5d0c4147a.js"
5:"static/chunks/887-261029c65615bbb4.js"
6:"static/chunks/app/layout-5bebfc80f3b4ebaf.js"
7:I[27124,["7196","$2","6609","$3","5086","$4","887","$5","7177","$6"],"Providers"]
8:I[57121,[],""]
9:"static/chunks/9743-99742a98ccd9abef.js"
a:"static/chunks/5772-84fc671245532328.js"
b:"static/chunks/8742-7c6f5a99dc235cc3.js"
c:"static/chunks/9834-c4589c2c9ee3a423.js"
d:"static/chunks/5598-d88d9133d4fdd6b6.js"
e:"static/chunks/app/error-ed80cd2472c472f0.js"
f:I[17267,["9743","$9","5772","$a","8742","$b","9834","$c","5598","$d","8039","$e"],"default"]
10:I[74581,[],""]
11:"static/chunks/app/unauthorized-b2b57b79866b95b0.js"
12:I[99834,["9743","$9","5772","$a","8742","$b","9834","$c","5598","$d","2413","$11"],"Header"]
13:I[98500,["9743","$9","5772","$a","8742","$b","9834","$c","5598","$d","2413","$11"],""]
14:I[5598,["9743","$9","5772","$a","8742","$b","9834","$c","5598","$d","2413","$11"],"Footer"]
:HL["/_next/static/css/6abbbe9f7a384c77.css","style"]
1b:X
1f:X
1f:C
20:[["children",{"s":"__PAGE__","h":160,"d":{"r":"$L21","p":"$@22","v":null,"s":"$1b"}}]]
1c:[["children",{"s":"pacific-cross-health-brochure","h":96,"d":{"r":"$L1d","p":"$@1e","v":"$1f","s":"$1b"},"c":"$Q20"}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/6abbbe9f7a384c77.css","precedence":"next"}]],["$","html",null,{"lang":"en","suppressHydrationWarning":true,"children":[["$","head",null,{"children":[["$","link",null,{"rel":"apple-touch-icon","sizes":"180x180","href":"/apple-touch-icon.png"}],["$","link",null,{"rel":"icon","type":"image/png","sizes":"32x32","href":"/favicon-32x32.png"}],["$","link",null,{"rel":"icon","type":"image/png","sizes":"16x16","href":"/favicon-16x16.png"}],["$","link",null,{"rel":"manifest","href":"/site.webmanifest"}]]}],["$","body",null,{"className":"min-h-dvh bg-[#fcfdfb] text-[#183d2c] antialiased dark:bg-[#1c1e1e] dark:text-[#f4f5f2]","children":["$","$L7",null,{"children":["$","$L8",null,{"parallelRouterKey":"children","error":"$f","errorStyles":[],"errorScripts":null,"template":["$","$L10",null,{}],"notFound":[["$","div",null,{"className":"flex min-h-dvh flex-col bg-[var(--canvas)] text-[var(--text-main)]","children":[["$","a",null,{"href":"#main","className":"sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:inline-flex focus:min-h-11 focus:items-center focus:rounded-md focus:bg-[#006838] focus:px-5 focus:py-2.5 focus:text-sm focus:font-semibold focus:text-white focus:outline-2 focus:outline-offset-2 focus:outline-white","children":"Skip to content"}],["$","$L12",null,{"agentCode":"ckO6uNx2O6","productsLabel":"Products"}],["$","main",null,{"id":"main","className":"flex-1","tabIndex":-1,"children":["$","div",null,{"className":"mx-auto flex w-full max-w-2xl flex-col items-center px-5 py-16 text-center sm:px-8 sm:py-20","children":[["$","p",null,{"className":"text-[clamp(6rem,16vw,10rem)] leading-none font-semibold tracking-tight text-[#006838] dark:text-[#d0e3c8]","children":404}],["$","h1",null,{"className":"mt-6 text-3xl font-semibold tracking-tight text-[#183d2c] sm:text-4xl dark:text-[#f4f5f2]","children":"Looks like a wrong turn."}],["$","p",null,{"className":"mt-4 max-w-md text-base leading-relaxed text-[#333333] dark:text-[#c4c7c5]","children":"We can’t find the page you’re looking for. It may have moved, or the link may be out of date."}],["$","div",null,{"className":"mt-8 flex w-full flex-col gap-3 sm:w-auto sm:flex-row sm:justify-center","children":[["$","$L13",null,{"href":"/ckO6uNx2O6/travel-insurance","className":"btn-primary","children":"Back to home"}],["$","a",null,{"href":"#error-support","className":"btn-secondary","children":"Get in touch"}]]}],["$","p",null,{"id":"error-support","className":"mt-8 text-sm leading-relaxed text-[#808080] dark:text-[#b2b7b4]","children":["Need a hand?"," ",["$","a",null,{"href":"mailto:sales@ifrcinsurance.com","className":"inline-flex min-h-8 items-center rounded-sm font-semibold text-[#006838] underline-offset-4 hover:underline focus-visible:outline-2 focus-visible:outline-[#006838] dark:text-[#d0e3c8] dark:hover:text-white dark:focus-visible:outline-white","children":"Our team is here to help."}]]}]]}]}],["$","$L14",null,{"agentCode":"ckO6uNx2O6"}]]}],[]],"forbidden":[["$","div",null,{"className":"flex min-h-dvh flex-col bg-[var(--canvas)] text-[var(--text-main)]","children":[["$","a",null,{"href":"#main","className":"sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:inline-flex focus:min-h-11 focus:items-center focus:rounded-md focus:bg-[#006838] focus:px-5 focus:py-2.5 focus:text-sm focus:font-semibold focus:text-white focus:outline-2 focus:outline-offset-2 focus:outline-white","children":"Skip to content"}],["$","$L12",null,{"agentCode":"ckO6uNx2O6","productsLabel":"Products"}],["$","main",null,{"id":"main","className":"flex-1","tabIndex":-1,"children":["$","div",null,{"className":"mx-auto flex w-full max-w-2xl flex-col items-center px-5 py-16 text-center sm:px-8 sm:py-20","children":[["$","p",null,{"className":"text-[clamp(6rem,16vw,10rem)] leading-none font-semibold tracking-tight text-[#006838] dark:text-[#d0e3c8]","children":403}],["$","h1",null,{"className":"mt-6 text-3xl font-semibold tracking-tight text-[#183d2c] sm:text-4xl dark:text-[#f4f5f2]","children":"This page isn’t available to you."}],"$L15","$L16","$L17"]}]}],"$L18"]}],[]],"unauthorized":"$L19"}]}]}]]}]]}],"p":"$@1a","v":null,"s":"$1b"},"c":"$Q1c"},"h":{"r":"$L23","p":"$@24","v":null,"s":"$1b"}},"a":"$@25","u":"$@26","b":"0kWzor95AEI6QAVYeYDS3"}
27:I[61304,[],"ClientPageRoot"]
28:"static/chunks/app/pacific-cross-health-brochure/page-62d66be5ac96d38f.js"
29:I[78079,["9743","$9","3211","$28"],"default"]
2c:I[90484,[],"OutletBoundary"]
2d:"$Sreact.suspense"
2f:"ViewportBoundary"
30:I[90484,[],"$2f"]
31:"MetadataBoundary"
32:I[90484,[],"$31"]
33:I[86869,[],"IconMark"]
15:["$","p",null,{"className":"mt-4 max-w-md text-base leading-relaxed text-[#333333] dark:text-[#c4c7c5]","children":"You don’t have permission to open this page. Return home, or contact our team if you need help."}]
16:["$","div",null,{"className":"mt-8 flex w-full flex-col gap-3 sm:w-auto sm:flex-row sm:justify-center","children":[["$","$L13",null,{"href":"/ckO6uNx2O6/travel-insurance","className":"btn-primary","children":"Back to home"}],["$","a",null,{"href":"#error-support","className":"btn-secondary","children":"Get in touch"}]]}]
17:["$","p",null,{"id":"error-support","className":"mt-8 text-sm leading-relaxed text-[#808080] dark:text-[#b2b7b4]","children":["Need a hand?"," ",["$","a",null,{"href":"mailto:sales@ifrcinsurance.com","className":"inline-flex min-h-8 items-center rounded-sm font-semibold text-[#006838] underline-offset-4 hover:underline focus-visible:outline-2 focus-visible:outline-[#006838] dark:text-[#d0e3c8] dark:hover:text-white dark:focus-visible:outline-white","children":"Our team is here to help."}]]}]
18:["$","$L14",null,{"agentCode":"ckO6uNx2O6"}]
19:[["$","div",null,{"className":"flex min-h-dvh flex-col bg-[var(--canvas)] text-[var(--text-main)]","children":[["$","a",null,{"href":"#main","className":"sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:inline-flex focus:min-h-11 focus:items-center focus:rounded-md focus:bg-[#006838] focus:px-5 focus:py-2.5 focus:text-sm focus:font-semibold focus:text-white focus:outline-2 focus:outline-offset-2 focus:outline-white","children":"Skip to content"}],["$","$L12",null,{"agentCode":"ckO6uNx2O6","productsLabel":"Products"}],["$","main",null,{"id":"main","className":"flex-1","tabIndex":-1,"children":["$","div",null,{"className":"mx-auto flex w-full max-w-2xl flex-col items-center px-5 py-16 text-center sm:px-8 sm:py-20","children":[["$","p",null,{"className":"text-[clamp(6rem,16vw,10rem)] leading-none font-semibold tracking-tight text-[#006838] dark:text-[#d0e3c8]","children":401}],["$","h1",null,{"className":"mt-6 text-3xl font-semibold tracking-tight text-[#183d2c] sm:text-4xl dark:text-[#f4f5f2]","children":"Please sign in to continue."}],["$","p",null,{"className":"mt-4 max-w-md text-base leading-relaxed text-[#333333] dark:text-[#c4c7c5]","children":"You need to be signed in to open this page. Return home to find the right place to get started."}],["$","div",null,{"className":"mt-8 flex w-full flex-col gap-3 sm:w-auto sm:flex-row sm:justify-center","children":[["$","$L13",null,{"href":"/ckO6uNx2O6/travel-insurance","className":"btn-primary","children":"Back to home"}],["$","a",null,{"href":"#error-support","className":"btn-secondary","children":"Get in touch"}]]}],["$","p",null,{"id":"error-support","className":"mt-8 text-sm leading-relaxed text-[#808080] dark:text-[#b2b7b4]","children":["Need a hand?"," ",["$","a",null,{"href":"mailto:sales@ifrcinsurance.com","className":"inline-flex min-h-8 items-center rounded-sm font-semibold text-[#006838] underline-offset-4 hover:underline focus-visible:outline-2 focus-visible:outline-[#006838] dark:text-[#d0e3c8] dark:hover:text-white dark:focus-visible:outline-white","children":"Our team is here to help."}]]}]]}]}],["$","$L14",null,{"agentCode":"ckO6uNx2O6"}]]}],[]]
1d:["$","$1","c",{"children":[null,["$","$L8",null,{"parallelRouterKey":"children","template":["$","$L10",null,{}]}]]}]
21:["$","$1","c",{"children":[["$","$L27",null,{"Component":"$29","serverProvidedParams":{"searchParams":{},"params":{},"promises":["$@2a","$@2b"]}}],null,["$","$L2c",null,{"children":["$","$2d",null,{"name":"Next.MetadataOutlet","children":"$@2e"}]}]]}]
23:["$","$1","h",{"children":[null,["$","$L30",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L32",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$2d",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"One Insurance — Travel Protection"}],["$","meta","1",{"name":"description","content":"Fast, comprehensive travel insurance coverage with instant quotes and policy issuance."}],["$","link","2",{"rel":"manifest","href":"/site.webmanifest"}],["$","link","3",{"rel":"icon","href":"/favicon.ico?f5e18e924f675669","type":"image/x-icon","sizes":"16x16"}],["$","link","4",{"rel":"icon","href":"/favicon.ico"}],["$","link","5",{"rel":"icon","href":"/favicon-16x16.png","sizes":"16x16","type":"image/png"}],["$","link","6",{"rel":"icon","href":"/favicon-32x32.png","sizes":"32x32","type":"image/png"}],["$","link","7",{"rel":"icon","href":"/android-chrome-192x192.png","sizes":"192x192","type":"image/png"}],["$","link","8",{"rel":"icon","href":"/android-chrome-512x512.png","sizes":"512x512","type":"image/png"}],["$","link","9",{"rel":"apple-touch-icon","href":"/apple-touch-icon.png","sizes":"180x180","type":"image/png"}],["$","$L33","10",{}]]}]}],null]}],null]}]
2a:{}
2b:"$21:props:children:0:props:serverProvidedParams:params"
2e:null
26:true
1b:300
1b:C
25:0
1e:"$undefined"
24:"$undefined"
22:"$undefined"
1a:"$undefined"
